MONGO_URL="mongodb+srv://crowdference:qgs.MNG.4nt0n10@cluster0-i6jy7.mongodb.net/crowdference?retryWrites=true"

MONGO_OPLOG_URL="mongodb+srv://crowdference:qgs.MNG.4nt0n10@cluster0-i6jy7.mongodb.net/local?retryWrites=true"

servidores=(root@online2.hacknlove.org)


PORTA=15901
PORTB=15902
ROOT_URL=https://crowdference.org/

NGINX=.cosas/nginx.conf

nombre=crowdference.org
METEOR_SETTINGS=./settings.json
