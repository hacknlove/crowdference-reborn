MONGO_URL="mongodb://hcknlv:Xxp63ITRTimToSwR@cluster0-shard-00-00-ydnfa.mongodb.net:27017,cluster0-shard-00-01-ydnfa.mongodb.net:27017,cluster0-shard-00-02-ydnfa.mongodb.net:27017/crowdference?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin"

MONGO_OPLOG_URL="mongodb://hcknlv:Xxp63ITRTimToSwR@cluster0-shard-00-00-ydnfa.mongodb.net:27017,cluster0-shard-00-01-ydnfa.mongodb.net:27017,cluster0-shard-00-02-ydnfa.mongodb.net:27017/local?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin"

servidores=(root@online2.hacknlove.org)


PORTA=15901
PORTB=15902
ROOT_URL=https://crowdference.org

NGINX=.cosas/nginx.conf

nombre=crowdference.org
METEOR_SETTINGS=./settings.json
