(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"hacknlove:ventanas":{"server.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/hacknlove_ventanas/server.js                                          //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
module.export({
  ventanas: () => ventanas
});
let onPageLoad;
module.link("meteor/server-render", {
  onPageLoad(v) {
    onPageLoad = v;
  }

}, 0);
let readUrl, limpiarUrl, createUrl;
module.link("./common.js", {
  readUrl(v) {
    readUrl = v;
  },

  limpiarUrl(v) {
    limpiarUrl = v;
  },

  createUrl(v) {
    createUrl = v;
  }

}, 1);
let UrlPatern;
module.link("url-pattern", {
  default(v) {
    UrlPatern = v;
  }

}, 2);
const urls = [];
const ventanas = {
  use(url, callback) {
    urls.push([new UrlPatern(url, ventanas.options.urlPaternOptions), callback]);
  },

  createUrl(payload) {
    return createUrl(payload, ventanas);
  },

  limpiarUrl(payload) {
    return limpiarUrl(payload, ventanas);
  },

  readUrl(payload) {
    return readUrl(payload, ventanas);
  },

  options: {
    query: 'v',
    timeout: 350,
    debounce: 500,
    UrlPaternOptions: {
      segmentValueCharset: 'a-zA-Z0-9-_~%.'
    },
    jwt: {
      algorithm: 'none',
      key: undefined
    }
  }
};
onPageLoad(sink => {
  var match;
  var callback;
  const path = sink.request.url.path.split('?');
  urls.some(function (url) {
    match = url[0].match(path[0]);

    if (!match) {
      return;
    }

    callback = url[1];
    return true;
  });

  if (!match) {
    return;
  }

  callback(sink, match, ventanas.readUrl(path[1]));
});
////////////////////////////////////////////////////////////////////////////////////

},"common.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/hacknlove_ventanas/common.js                                          //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
module.export({
  readUrl: () => readUrl,
  createUrl: () => createUrl
});
let jwt;
module.link("jsonwebtoken", {
  default(v) {
    jwt = v;
  }

}, 0);

const qs = require('qs');

function readUrl(url, ventanas) {
  url = qs.parse(url);
  var array = [];
  array.query = url;

  if (!url[ventanas.options.query]) {
    return array;
  }

  try {
    url = jwt.verify(url[ventanas.options.query], ventanas.options.jwt.key).v;
    array = Object.keys(url).map(function (_id) {
      url[_id]._id = _id;
      return url[_id];
    });
    array.query = url;
    return array;
  } catch (e) {
    return array;
  }
}

function createUrl(array, ventanas) {
  const payload = {};
  array.forEach(function (v) {
    const _id = v._id;
    delete v._id;
    payload[_id] = v;
  });
  return jwt.sign({
    v: payload
  }, ventanas.options.jwt.key, {
    algorithm: ventanas.options.jwt.algorithm
  });
}
////////////////////////////////////////////////////////////////////////////////////

},"node_modules":{"jsonwebtoken":{"package.json":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// node_modules/meteor/hacknlove_ventanas/node_modules/jsonwebtoken/package.json  //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
module.exports = {
  "name": "jsonwebtoken",
  "version": "8.5.1",
  "main": "index.js"
};

////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// node_modules/meteor/hacknlove_ventanas/node_modules/jsonwebtoken/index.js      //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
module.useNode();
////////////////////////////////////////////////////////////////////////////////////

}},"qs":{"package.json":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// node_modules/meteor/hacknlove_ventanas/node_modules/qs/package.json            //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
module.exports = {
  "name": "qs",
  "version": "6.5.0",
  "main": "lib/index.js"
};

////////////////////////////////////////////////////////////////////////////////////

},"lib":{"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// node_modules/meteor/hacknlove_ventanas/node_modules/qs/lib/index.js            //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
module.useNode();
////////////////////////////////////////////////////////////////////////////////////

}}},"url-pattern":{"package.json":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// node_modules/meteor/hacknlove_ventanas/node_modules/url-pattern/package.json   //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
module.exports = {
  "name": "url-pattern",
  "version": "1.0.3",
  "main": "lib/url-pattern"
};

////////////////////////////////////////////////////////////////////////////////////

},"lib":{"url-pattern.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// node_modules/meteor/hacknlove_ventanas/node_modules/url-pattern/lib/url-patter //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
module.useNode();
////////////////////////////////////////////////////////////////////////////////////

}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/hacknlove:ventanas/server.js");

/* Exports */
Package._define("hacknlove:ventanas", exports);

})();

//# sourceURL=meteor://💻app/packages/hacknlove_ventanas.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvaGFja25sb3ZlOnZlbnRhbmFzL3NlcnZlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvaGFja25sb3ZlOnZlbnRhbmFzL2NvbW1vbi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJ2ZW50YW5hcyIsIm9uUGFnZUxvYWQiLCJsaW5rIiwidiIsInJlYWRVcmwiLCJsaW1waWFyVXJsIiwiY3JlYXRlVXJsIiwiVXJsUGF0ZXJuIiwiZGVmYXVsdCIsInVybHMiLCJ1c2UiLCJ1cmwiLCJjYWxsYmFjayIsInB1c2giLCJvcHRpb25zIiwidXJsUGF0ZXJuT3B0aW9ucyIsInBheWxvYWQiLCJxdWVyeSIsInRpbWVvdXQiLCJkZWJvdW5jZSIsIlVybFBhdGVybk9wdGlvbnMiLCJzZWdtZW50VmFsdWVDaGFyc2V0Iiwiand0IiwiYWxnb3JpdGhtIiwia2V5IiwidW5kZWZpbmVkIiwic2luayIsIm1hdGNoIiwicGF0aCIsInJlcXVlc3QiLCJzcGxpdCIsInNvbWUiLCJxcyIsInJlcXVpcmUiLCJwYXJzZSIsImFycmF5IiwidmVyaWZ5IiwiT2JqZWN0Iiwia2V5cyIsIm1hcCIsIl9pZCIsImUiLCJmb3JFYWNoIiwic2lnbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxVQUFRLEVBQUMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUlDLFVBQUo7QUFBZUgsTUFBTSxDQUFDSSxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQ0QsWUFBVSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsY0FBVSxHQUFDRSxDQUFYO0FBQWE7O0FBQTVCLENBQW5DLEVBQWlFLENBQWpFO0FBQW9FLElBQUlDLE9BQUosRUFBWUMsVUFBWixFQUF1QkMsU0FBdkI7QUFBaUNSLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsU0FBTyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsV0FBTyxHQUFDRCxDQUFSO0FBQVUsR0FBdEI7O0FBQXVCRSxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYSxHQUFsRDs7QUFBbURHLFdBQVMsQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNHLGFBQVMsR0FBQ0gsQ0FBVjtBQUFZOztBQUE1RSxDQUExQixFQUF3RyxDQUF4RztBQUEyRyxJQUFJSSxTQUFKO0FBQWNULE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ00sU0FBTyxDQUFDTCxDQUFELEVBQUc7QUFBQ0ksYUFBUyxHQUFDSixDQUFWO0FBQVk7O0FBQXhCLENBQTFCLEVBQW9ELENBQXBEO0FBSXBSLE1BQU1NLElBQUksR0FBRyxFQUFiO0FBRU8sTUFBTVQsUUFBUSxHQUFHO0FBQ3RCVSxLQUFHLENBQUVDLEdBQUYsRUFBT0MsUUFBUCxFQUFpQjtBQUNsQkgsUUFBSSxDQUFDSSxJQUFMLENBQVUsQ0FDUixJQUFJTixTQUFKLENBQWNJLEdBQWQsRUFBbUJYLFFBQVEsQ0FBQ2MsT0FBVCxDQUFpQkMsZ0JBQXBDLENBRFEsRUFFUkgsUUFGUSxDQUFWO0FBSUQsR0FOcUI7O0FBT3RCTixXQUFTLENBQUVVLE9BQUYsRUFBVztBQUNsQixXQUFPVixTQUFTLENBQUNVLE9BQUQsRUFBVWhCLFFBQVYsQ0FBaEI7QUFDRCxHQVRxQjs7QUFVdEJLLFlBQVUsQ0FBRVcsT0FBRixFQUFXO0FBQ25CLFdBQU9YLFVBQVUsQ0FBQ1csT0FBRCxFQUFVaEIsUUFBVixDQUFqQjtBQUNELEdBWnFCOztBQWF0QkksU0FBTyxDQUFFWSxPQUFGLEVBQVc7QUFDaEIsV0FBT1osT0FBTyxDQUFDWSxPQUFELEVBQVVoQixRQUFWLENBQWQ7QUFDRCxHQWZxQjs7QUFnQnRCYyxTQUFPLEVBQUU7QUFDUEcsU0FBSyxFQUFFLEdBREE7QUFFUEMsV0FBTyxFQUFFLEdBRkY7QUFHUEMsWUFBUSxFQUFFLEdBSEg7QUFJUEMsb0JBQWdCLEVBQUU7QUFDaEJDLHlCQUFtQixFQUFFO0FBREwsS0FKWDtBQU9QQyxPQUFHLEVBQUU7QUFDSEMsZUFBUyxFQUFFLE1BRFI7QUFFSEMsU0FBRyxFQUFFQztBQUZGO0FBUEU7QUFoQmEsQ0FBakI7QUE4QlB4QixVQUFVLENBQUN5QixJQUFJLElBQUk7QUFDakIsTUFBSUMsS0FBSjtBQUNBLE1BQUlmLFFBQUo7QUFDQSxRQUFNZ0IsSUFBSSxHQUFHRixJQUFJLENBQUNHLE9BQUwsQ0FBYWxCLEdBQWIsQ0FBaUJpQixJQUFqQixDQUFzQkUsS0FBdEIsQ0FBNEIsR0FBNUIsQ0FBYjtBQUNBckIsTUFBSSxDQUFDc0IsSUFBTCxDQUFVLFVBQVVwQixHQUFWLEVBQWU7QUFDdkJnQixTQUFLLEdBQUdoQixHQUFHLENBQUMsQ0FBRCxDQUFILENBQU9nQixLQUFQLENBQWFDLElBQUksQ0FBQyxDQUFELENBQWpCLENBQVI7O0FBQ0EsUUFBSSxDQUFDRCxLQUFMLEVBQVk7QUFDVjtBQUNEOztBQUNEZixZQUFRLEdBQUdELEdBQUcsQ0FBQyxDQUFELENBQWQ7QUFDQSxXQUFPLElBQVA7QUFDRCxHQVBEOztBQVFBLE1BQUksQ0FBQ2dCLEtBQUwsRUFBWTtBQUNWO0FBQ0Q7O0FBQ0RmLFVBQVEsQ0FBQ2MsSUFBRCxFQUFPQyxLQUFQLEVBQWMzQixRQUFRLENBQUNJLE9BQVQsQ0FBaUJ3QixJQUFJLENBQUMsQ0FBRCxDQUFyQixDQUFkLENBQVI7QUFDRCxDQWhCUyxDQUFWLEM7Ozs7Ozs7Ozs7O0FDcENBOUIsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0ssU0FBTyxFQUFDLE1BQUlBLE9BQWI7QUFBcUJFLFdBQVMsRUFBQyxNQUFJQTtBQUFuQyxDQUFkO0FBQTZELElBQUlnQixHQUFKO0FBQVF4QixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNNLFNBQU8sQ0FBQ0wsQ0FBRCxFQUFHO0FBQUNtQixPQUFHLEdBQUNuQixDQUFKO0FBQU07O0FBQWxCLENBQTNCLEVBQStDLENBQS9DOztBQUNyRSxNQUFNNkIsRUFBRSxHQUFHQyxPQUFPLENBQUMsSUFBRCxDQUFsQjs7QUFFTyxTQUFTN0IsT0FBVCxDQUFrQk8sR0FBbEIsRUFBdUJYLFFBQXZCLEVBQWlDO0FBQ3RDVyxLQUFHLEdBQUdxQixFQUFFLENBQUNFLEtBQUgsQ0FBU3ZCLEdBQVQsQ0FBTjtBQUNBLE1BQUl3QixLQUFLLEdBQUcsRUFBWjtBQUNBQSxPQUFLLENBQUNsQixLQUFOLEdBQWNOLEdBQWQ7O0FBQ0EsTUFBSSxDQUFDQSxHQUFHLENBQUNYLFFBQVEsQ0FBQ2MsT0FBVCxDQUFpQkcsS0FBbEIsQ0FBUixFQUFrQztBQUNoQyxXQUFPa0IsS0FBUDtBQUNEOztBQUNELE1BQUk7QUFDRnhCLE9BQUcsR0FBR1csR0FBRyxDQUFDYyxNQUFKLENBQVd6QixHQUFHLENBQUNYLFFBQVEsQ0FBQ2MsT0FBVCxDQUFpQkcsS0FBbEIsQ0FBZCxFQUF3Q2pCLFFBQVEsQ0FBQ2MsT0FBVCxDQUFpQlEsR0FBakIsQ0FBcUJFLEdBQTdELEVBQWtFckIsQ0FBeEU7QUFFQWdDLFNBQUssR0FBR0UsTUFBTSxDQUFDQyxJQUFQLENBQVkzQixHQUFaLEVBQWlCNEIsR0FBakIsQ0FBcUIsVUFBVUMsR0FBVixFQUFlO0FBQzFDN0IsU0FBRyxDQUFDNkIsR0FBRCxDQUFILENBQVNBLEdBQVQsR0FBZUEsR0FBZjtBQUNBLGFBQU83QixHQUFHLENBQUM2QixHQUFELENBQVY7QUFDRCxLQUhPLENBQVI7QUFJQUwsU0FBSyxDQUFDbEIsS0FBTixHQUFjTixHQUFkO0FBQ0EsV0FBT3dCLEtBQVA7QUFDRCxHQVRELENBU0UsT0FBT00sQ0FBUCxFQUFVO0FBQ1YsV0FBT04sS0FBUDtBQUNEO0FBQ0Y7O0FBRU0sU0FBUzdCLFNBQVQsQ0FBb0I2QixLQUFwQixFQUEyQm5DLFFBQTNCLEVBQXFDO0FBQzFDLFFBQU1nQixPQUFPLEdBQUcsRUFBaEI7QUFDQW1CLE9BQUssQ0FBQ08sT0FBTixDQUFjLFVBQVV2QyxDQUFWLEVBQWE7QUFDekIsVUFBTXFDLEdBQUcsR0FBR3JDLENBQUMsQ0FBQ3FDLEdBQWQ7QUFDQSxXQUFPckMsQ0FBQyxDQUFDcUMsR0FBVDtBQUNBeEIsV0FBTyxDQUFDd0IsR0FBRCxDQUFQLEdBQWVyQyxDQUFmO0FBQ0QsR0FKRDtBQUtBLFNBQU9tQixHQUFHLENBQUNxQixJQUFKLENBQVM7QUFDZHhDLEtBQUMsRUFBRWE7QUFEVyxHQUFULEVBRUpoQixRQUFRLENBQUNjLE9BQVQsQ0FBaUJRLEdBQWpCLENBQXFCRSxHQUZqQixFQUVzQjtBQUFFRCxhQUFTLEVBQUV2QixRQUFRLENBQUNjLE9BQVQsQ0FBaUJRLEdBQWpCLENBQXFCQztBQUFsQyxHQUZ0QixDQUFQO0FBR0QsQyIsImZpbGUiOiIvcGFja2FnZXMvaGFja25sb3ZlX3ZlbnRhbmFzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgb25QYWdlTG9hZCB9IGZyb20gJ21ldGVvci9zZXJ2ZXItcmVuZGVyJ1xuaW1wb3J0IHsgcmVhZFVybCwgbGltcGlhclVybCwgY3JlYXRlVXJsIH0gZnJvbSAnLi9jb21tb24uanMnXG5pbXBvcnQgVXJsUGF0ZXJuIGZyb20gJ3VybC1wYXR0ZXJuJ1xuXG5jb25zdCB1cmxzID0gW11cblxuZXhwb3J0IGNvbnN0IHZlbnRhbmFzID0ge1xuICB1c2UgKHVybCwgY2FsbGJhY2spIHtcbiAgICB1cmxzLnB1c2goW1xuICAgICAgbmV3IFVybFBhdGVybih1cmwsIHZlbnRhbmFzLm9wdGlvbnMudXJsUGF0ZXJuT3B0aW9ucyksXG4gICAgICBjYWxsYmFja1xuICAgIF0pXG4gIH0sXG4gIGNyZWF0ZVVybCAocGF5bG9hZCkge1xuICAgIHJldHVybiBjcmVhdGVVcmwocGF5bG9hZCwgdmVudGFuYXMpXG4gIH0sXG4gIGxpbXBpYXJVcmwgKHBheWxvYWQpIHtcbiAgICByZXR1cm4gbGltcGlhclVybChwYXlsb2FkLCB2ZW50YW5hcylcbiAgfSxcbiAgcmVhZFVybCAocGF5bG9hZCkge1xuICAgIHJldHVybiByZWFkVXJsKHBheWxvYWQsIHZlbnRhbmFzKVxuICB9LFxuICBvcHRpb25zOiB7XG4gICAgcXVlcnk6ICd2JyxcbiAgICB0aW1lb3V0OiAzNTAsXG4gICAgZGVib3VuY2U6IDUwMCxcbiAgICBVcmxQYXRlcm5PcHRpb25zOiB7XG4gICAgICBzZWdtZW50VmFsdWVDaGFyc2V0OiAnYS16QS1aMC05LV9+JS4nXG4gICAgfSxcbiAgICBqd3Q6IHtcbiAgICAgIGFsZ29yaXRobTogJ25vbmUnLFxuICAgICAga2V5OiB1bmRlZmluZWRcbiAgICB9XG4gIH1cbn1cblxub25QYWdlTG9hZChzaW5rID0+IHtcbiAgdmFyIG1hdGNoXG4gIHZhciBjYWxsYmFja1xuICBjb25zdCBwYXRoID0gc2luay5yZXF1ZXN0LnVybC5wYXRoLnNwbGl0KCc/JylcbiAgdXJscy5zb21lKGZ1bmN0aW9uICh1cmwpIHtcbiAgICBtYXRjaCA9IHVybFswXS5tYXRjaChwYXRoWzBdKVxuICAgIGlmICghbWF0Y2gpIHtcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBjYWxsYmFjayA9IHVybFsxXVxuICAgIHJldHVybiB0cnVlXG4gIH0pXG4gIGlmICghbWF0Y2gpIHtcbiAgICByZXR1cm5cbiAgfVxuICBjYWxsYmFjayhzaW5rLCBtYXRjaCwgdmVudGFuYXMucmVhZFVybChwYXRoWzFdKSlcbn0pXG4iLCJpbXBvcnQgand0IGZyb20gJ2pzb253ZWJ0b2tlbidcbmNvbnN0IHFzID0gcmVxdWlyZSgncXMnKVxuXG5leHBvcnQgZnVuY3Rpb24gcmVhZFVybCAodXJsLCB2ZW50YW5hcykge1xuICB1cmwgPSBxcy5wYXJzZSh1cmwpXG4gIHZhciBhcnJheSA9IFtdXG4gIGFycmF5LnF1ZXJ5ID0gdXJsXG4gIGlmICghdXJsW3ZlbnRhbmFzLm9wdGlvbnMucXVlcnldKSB7XG4gICAgcmV0dXJuIGFycmF5XG4gIH1cbiAgdHJ5IHtcbiAgICB1cmwgPSBqd3QudmVyaWZ5KHVybFt2ZW50YW5hcy5vcHRpb25zLnF1ZXJ5XSwgdmVudGFuYXMub3B0aW9ucy5qd3Qua2V5KS52XG5cbiAgICBhcnJheSA9IE9iamVjdC5rZXlzKHVybCkubWFwKGZ1bmN0aW9uIChfaWQpIHtcbiAgICAgIHVybFtfaWRdLl9pZCA9IF9pZFxuICAgICAgcmV0dXJuIHVybFtfaWRdXG4gICAgfSlcbiAgICBhcnJheS5xdWVyeSA9IHVybFxuICAgIHJldHVybiBhcnJheVxuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIGFycmF5XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVVybCAoYXJyYXksIHZlbnRhbmFzKSB7XG4gIGNvbnN0IHBheWxvYWQgPSB7fVxuICBhcnJheS5mb3JFYWNoKGZ1bmN0aW9uICh2KSB7XG4gICAgY29uc3QgX2lkID0gdi5faWRcbiAgICBkZWxldGUgdi5faWRcbiAgICBwYXlsb2FkW19pZF0gPSB2XG4gIH0pXG4gIHJldHVybiBqd3Quc2lnbih7XG4gICAgdjogcGF5bG9hZFxuICB9LCB2ZW50YW5hcy5vcHRpb25zLmp3dC5rZXksIHsgYWxnb3JpdGhtOiB2ZW50YW5hcy5vcHRpb25zLmp3dC5hbGdvcml0aG0gfSlcbn1cbiJdfQ==
