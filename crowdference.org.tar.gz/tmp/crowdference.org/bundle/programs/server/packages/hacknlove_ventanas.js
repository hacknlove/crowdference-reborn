(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"hacknlove:ventanas":{"server.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// packages/hacknlove_ventanas/server.js                                       //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.export({
  ventanas: () => ventanas
});
let onPageLoad;
module.link("meteor/server-render", {
  onPageLoad(v) {
    onPageLoad = v;
  }

}, 0);
let readUrl, limpiarUrl, createUrl;
module.link("./common.js", {
  readUrl(v) {
    readUrl = v;
  },

  limpiarUrl(v) {
    limpiarUrl = v;
  },

  createUrl(v) {
    createUrl = v;
  }

}, 1);
let UrlPaterrn;
module.link("url-pattern", {
  default(v) {
    UrlPaterrn = v;
  }

}, 2);
const urls = [];
const ventanas = {
  use(url, callback) {
    urls.push([new UrlPaterrn(url), callback]);
  },

  createUrl(payload) {
    return createUrl(payload, ventanas);
  },

  limpiarUrl(payload) {
    return limpiarUrl(payload, ventanas);
  },

  readUrl(payload) {
    return readUrl(payload, ventanas);
  },

  options: {
    query: 'v',
    timeout: 350,
    debounce: 500,
    jwt: {
      algorithm: 'none',
      key: undefined
    }
  }
};
onPageLoad(sink => {
  var match;
  var callback;
  const path = sink.request.url.path.split('?');
  urls.some(function (url) {
    match = url[0].match(path[0]);

    if (!match) {
      return;
    }

    callback = url[1];
    return true;
  });

  if (!match) {
    return;
  }

  callback(sink, match, ventanas.readUrl(path[1]));
});
/////////////////////////////////////////////////////////////////////////////////

},"common.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// packages/hacknlove_ventanas/common.js                                       //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.export({
  readUrl: () => readUrl,
  createUrl: () => createUrl
});
let jwt;
module.link("jsonwebtoken", {
  default(v) {
    jwt = v;
  }

}, 0);

const qs = require('qs');

function readUrl(url, ventanas) {
  url = qs.parse(url);
  var array = [];
  array.query = url;

  if (!url[ventanas.options.query]) {
    return array;
  }

  try {
    url = jwt.verify(url[ventanas.options.query], ventanas.options.jwt.key).v;
    array = Object.keys(url).map(function (_id) {
      url[_id]._id = _id;
      return url[_id];
    });
    array.query = url;
    return array;
  } catch (e) {
    return array;
  }
}

function createUrl(array, ventanas) {
  const payload = {};
  array.forEach(function (v) {
    const _id = v._id;
    delete v._id;
    payload[_id] = v;
  });
  return jwt.sign({
    v: payload
  }, ventanas.options.jwt.key, {
    algorithm: ventanas.options.jwt.algorithm
  });
}
/////////////////////////////////////////////////////////////////////////////////

},"node_modules":{"jsonwebtoken":{"package.json":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// node_modules/meteor/hacknlove_ventanas/node_modules/jsonwebtoken/package.js //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.exports = {
  "name": "jsonwebtoken",
  "version": "8.5.1",
  "main": "index.js"
};

/////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// node_modules/meteor/hacknlove_ventanas/node_modules/jsonwebtoken/index.js   //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////

}},"qs":{"package.json":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// node_modules/meteor/hacknlove_ventanas/node_modules/qs/package.json         //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.exports = {
  "name": "qs",
  "version": "6.5.0",
  "main": "lib/index.js"
};

/////////////////////////////////////////////////////////////////////////////////

},"lib":{"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// node_modules/meteor/hacknlove_ventanas/node_modules/qs/lib/index.js         //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////

}}},"url-pattern":{"package.json":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// node_modules/meteor/hacknlove_ventanas/node_modules/url-pattern/package.jso //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.exports = {
  "name": "url-pattern",
  "version": "1.0.3",
  "main": "lib/url-pattern"
};

/////////////////////////////////////////////////////////////////////////////////

},"lib":{"url-pattern.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// node_modules/meteor/hacknlove_ventanas/node_modules/url-pattern/lib/url-pat //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////

}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/hacknlove:ventanas/server.js");

/* Exports */
Package._define("hacknlove:ventanas", exports);

})();

//# sourceURL=meteor://💻app/packages/hacknlove_ventanas.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvaGFja25sb3ZlOnZlbnRhbmFzL3NlcnZlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvaGFja25sb3ZlOnZlbnRhbmFzL2NvbW1vbi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJ2ZW50YW5hcyIsIm9uUGFnZUxvYWQiLCJsaW5rIiwidiIsInJlYWRVcmwiLCJsaW1waWFyVXJsIiwiY3JlYXRlVXJsIiwiVXJsUGF0ZXJybiIsImRlZmF1bHQiLCJ1cmxzIiwidXNlIiwidXJsIiwiY2FsbGJhY2siLCJwdXNoIiwicGF5bG9hZCIsIm9wdGlvbnMiLCJxdWVyeSIsInRpbWVvdXQiLCJkZWJvdW5jZSIsImp3dCIsImFsZ29yaXRobSIsImtleSIsInVuZGVmaW5lZCIsInNpbmsiLCJtYXRjaCIsInBhdGgiLCJyZXF1ZXN0Iiwic3BsaXQiLCJzb21lIiwicXMiLCJyZXF1aXJlIiwicGFyc2UiLCJhcnJheSIsInZlcmlmeSIsIk9iamVjdCIsImtleXMiLCJtYXAiLCJfaWQiLCJlIiwiZm9yRWFjaCIsInNpZ24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsVUFBUSxFQUFDLE1BQUlBO0FBQWQsQ0FBZDtBQUF1QyxJQUFJQyxVQUFKO0FBQWVILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNELFlBQVUsQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLGNBQVUsR0FBQ0UsQ0FBWDtBQUFhOztBQUE1QixDQUFuQyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJQyxPQUFKLEVBQVlDLFVBQVosRUFBdUJDLFNBQXZCO0FBQWlDUixNQUFNLENBQUNJLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLFNBQU8sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFdBQU8sR0FBQ0QsQ0FBUjtBQUFVLEdBQXRCOztBQUF1QkUsWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWEsR0FBbEQ7O0FBQW1ERyxXQUFTLENBQUNILENBQUQsRUFBRztBQUFDRyxhQUFTLEdBQUNILENBQVY7QUFBWTs7QUFBNUUsQ0FBMUIsRUFBd0csQ0FBeEc7QUFBMkcsSUFBSUksVUFBSjtBQUFlVCxNQUFNLENBQUNJLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNNLFNBQU8sQ0FBQ0wsQ0FBRCxFQUFHO0FBQUNJLGNBQVUsR0FBQ0osQ0FBWDtBQUFhOztBQUF6QixDQUExQixFQUFxRCxDQUFyRDtBQUlyUixNQUFNTSxJQUFJLEdBQUcsRUFBYjtBQUVPLE1BQU1ULFFBQVEsR0FBRztBQUN0QlUsS0FBRyxDQUFFQyxHQUFGLEVBQU9DLFFBQVAsRUFBaUI7QUFDbEJILFFBQUksQ0FBQ0ksSUFBTCxDQUFVLENBQ1IsSUFBSU4sVUFBSixDQUFlSSxHQUFmLENBRFEsRUFFUkMsUUFGUSxDQUFWO0FBSUQsR0FOcUI7O0FBT3RCTixXQUFTLENBQUVRLE9BQUYsRUFBVztBQUNsQixXQUFPUixTQUFTLENBQUNRLE9BQUQsRUFBVWQsUUFBVixDQUFoQjtBQUNELEdBVHFCOztBQVV0QkssWUFBVSxDQUFFUyxPQUFGLEVBQVc7QUFDbkIsV0FBT1QsVUFBVSxDQUFDUyxPQUFELEVBQVVkLFFBQVYsQ0FBakI7QUFDRCxHQVpxQjs7QUFhdEJJLFNBQU8sQ0FBRVUsT0FBRixFQUFXO0FBQ2hCLFdBQU9WLE9BQU8sQ0FBQ1UsT0FBRCxFQUFVZCxRQUFWLENBQWQ7QUFDRCxHQWZxQjs7QUFnQnRCZSxTQUFPLEVBQUU7QUFDUEMsU0FBSyxFQUFFLEdBREE7QUFFUEMsV0FBTyxFQUFFLEdBRkY7QUFHUEMsWUFBUSxFQUFFLEdBSEg7QUFJUEMsT0FBRyxFQUFFO0FBQ0hDLGVBQVMsRUFBRSxNQURSO0FBRUhDLFNBQUcsRUFBRUM7QUFGRjtBQUpFO0FBaEJhLENBQWpCO0FBMkJQckIsVUFBVSxDQUFDc0IsSUFBSSxJQUFJO0FBQ2pCLE1BQUlDLEtBQUo7QUFDQSxNQUFJWixRQUFKO0FBQ0EsUUFBTWEsSUFBSSxHQUFHRixJQUFJLENBQUNHLE9BQUwsQ0FBYWYsR0FBYixDQUFpQmMsSUFBakIsQ0FBc0JFLEtBQXRCLENBQTRCLEdBQTVCLENBQWI7QUFDQWxCLE1BQUksQ0FBQ21CLElBQUwsQ0FBVSxVQUFVakIsR0FBVixFQUFlO0FBQ3ZCYSxTQUFLLEdBQUdiLEdBQUcsQ0FBQyxDQUFELENBQUgsQ0FBT2EsS0FBUCxDQUFhQyxJQUFJLENBQUMsQ0FBRCxDQUFqQixDQUFSOztBQUNBLFFBQUksQ0FBQ0QsS0FBTCxFQUFZO0FBQ1Y7QUFDRDs7QUFDRFosWUFBUSxHQUFHRCxHQUFHLENBQUMsQ0FBRCxDQUFkO0FBQ0EsV0FBTyxJQUFQO0FBQ0QsR0FQRDs7QUFRQSxNQUFJLENBQUNhLEtBQUwsRUFBWTtBQUNWO0FBQ0Q7O0FBQ0RaLFVBQVEsQ0FBQ1csSUFBRCxFQUFPQyxLQUFQLEVBQWN4QixRQUFRLENBQUNJLE9BQVQsQ0FBaUJxQixJQUFJLENBQUMsQ0FBRCxDQUFyQixDQUFkLENBQVI7QUFDRCxDQWhCUyxDQUFWLEM7Ozs7Ozs7Ozs7O0FDakNBM0IsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0ssU0FBTyxFQUFDLE1BQUlBLE9BQWI7QUFBcUJFLFdBQVMsRUFBQyxNQUFJQTtBQUFuQyxDQUFkO0FBQTZELElBQUlhLEdBQUo7QUFBUXJCLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ00sU0FBTyxDQUFDTCxDQUFELEVBQUc7QUFBQ2dCLE9BQUcsR0FBQ2hCLENBQUo7QUFBTTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7O0FBQ3JFLE1BQU0wQixFQUFFLEdBQUdDLE9BQU8sQ0FBQyxJQUFELENBQWxCOztBQUVPLFNBQVMxQixPQUFULENBQWtCTyxHQUFsQixFQUF1QlgsUUFBdkIsRUFBaUM7QUFDdENXLEtBQUcsR0FBR2tCLEVBQUUsQ0FBQ0UsS0FBSCxDQUFTcEIsR0FBVCxDQUFOO0FBQ0EsTUFBSXFCLEtBQUssR0FBRyxFQUFaO0FBQ0FBLE9BQUssQ0FBQ2hCLEtBQU4sR0FBY0wsR0FBZDs7QUFDQSxNQUFJLENBQUNBLEdBQUcsQ0FBQ1gsUUFBUSxDQUFDZSxPQUFULENBQWlCQyxLQUFsQixDQUFSLEVBQWtDO0FBQ2hDLFdBQU9nQixLQUFQO0FBQ0Q7O0FBQ0QsTUFBSTtBQUNGckIsT0FBRyxHQUFHUSxHQUFHLENBQUNjLE1BQUosQ0FBV3RCLEdBQUcsQ0FBQ1gsUUFBUSxDQUFDZSxPQUFULENBQWlCQyxLQUFsQixDQUFkLEVBQXdDaEIsUUFBUSxDQUFDZSxPQUFULENBQWlCSSxHQUFqQixDQUFxQkUsR0FBN0QsRUFBa0VsQixDQUF4RTtBQUVBNkIsU0FBSyxHQUFHRSxNQUFNLENBQUNDLElBQVAsQ0FBWXhCLEdBQVosRUFBaUJ5QixHQUFqQixDQUFxQixVQUFVQyxHQUFWLEVBQWU7QUFDMUMxQixTQUFHLENBQUMwQixHQUFELENBQUgsQ0FBU0EsR0FBVCxHQUFlQSxHQUFmO0FBQ0EsYUFBTzFCLEdBQUcsQ0FBQzBCLEdBQUQsQ0FBVjtBQUNELEtBSE8sQ0FBUjtBQUlBTCxTQUFLLENBQUNoQixLQUFOLEdBQWNMLEdBQWQ7QUFDQSxXQUFPcUIsS0FBUDtBQUNELEdBVEQsQ0FTRSxPQUFPTSxDQUFQLEVBQVU7QUFDVixXQUFPTixLQUFQO0FBQ0Q7QUFDRjs7QUFFTSxTQUFTMUIsU0FBVCxDQUFvQjBCLEtBQXBCLEVBQTJCaEMsUUFBM0IsRUFBcUM7QUFDMUMsUUFBTWMsT0FBTyxHQUFHLEVBQWhCO0FBQ0FrQixPQUFLLENBQUNPLE9BQU4sQ0FBYyxVQUFVcEMsQ0FBVixFQUFhO0FBQ3pCLFVBQU1rQyxHQUFHLEdBQUdsQyxDQUFDLENBQUNrQyxHQUFkO0FBQ0EsV0FBT2xDLENBQUMsQ0FBQ2tDLEdBQVQ7QUFDQXZCLFdBQU8sQ0FBQ3VCLEdBQUQsQ0FBUCxHQUFlbEMsQ0FBZjtBQUNELEdBSkQ7QUFLQSxTQUFPZ0IsR0FBRyxDQUFDcUIsSUFBSixDQUFTO0FBQ2RyQyxLQUFDLEVBQUVXO0FBRFcsR0FBVCxFQUVKZCxRQUFRLENBQUNlLE9BQVQsQ0FBaUJJLEdBQWpCLENBQXFCRSxHQUZqQixFQUVzQjtBQUFFRCxhQUFTLEVBQUVwQixRQUFRLENBQUNlLE9BQVQsQ0FBaUJJLEdBQWpCLENBQXFCQztBQUFsQyxHQUZ0QixDQUFQO0FBR0QsQyIsImZpbGUiOiIvcGFja2FnZXMvaGFja25sb3ZlX3ZlbnRhbmFzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgb25QYWdlTG9hZCB9IGZyb20gJ21ldGVvci9zZXJ2ZXItcmVuZGVyJ1xuaW1wb3J0IHsgcmVhZFVybCwgbGltcGlhclVybCwgY3JlYXRlVXJsIH0gZnJvbSAnLi9jb21tb24uanMnXG5pbXBvcnQgVXJsUGF0ZXJybiBmcm9tICd1cmwtcGF0dGVybidcblxuY29uc3QgdXJscyA9IFtdXG5cbmV4cG9ydCBjb25zdCB2ZW50YW5hcyA9IHtcbiAgdXNlICh1cmwsIGNhbGxiYWNrKSB7XG4gICAgdXJscy5wdXNoKFtcbiAgICAgIG5ldyBVcmxQYXRlcnJuKHVybCksXG4gICAgICBjYWxsYmFja1xuICAgIF0pXG4gIH0sXG4gIGNyZWF0ZVVybCAocGF5bG9hZCkge1xuICAgIHJldHVybiBjcmVhdGVVcmwocGF5bG9hZCwgdmVudGFuYXMpXG4gIH0sXG4gIGxpbXBpYXJVcmwgKHBheWxvYWQpIHtcbiAgICByZXR1cm4gbGltcGlhclVybChwYXlsb2FkLCB2ZW50YW5hcylcbiAgfSxcbiAgcmVhZFVybCAocGF5bG9hZCkge1xuICAgIHJldHVybiByZWFkVXJsKHBheWxvYWQsIHZlbnRhbmFzKVxuICB9LFxuICBvcHRpb25zOiB7XG4gICAgcXVlcnk6ICd2JyxcbiAgICB0aW1lb3V0OiAzNTAsXG4gICAgZGVib3VuY2U6IDUwMCxcbiAgICBqd3Q6IHtcbiAgICAgIGFsZ29yaXRobTogJ25vbmUnLFxuICAgICAga2V5OiB1bmRlZmluZWRcbiAgICB9XG4gIH1cbn1cblxub25QYWdlTG9hZChzaW5rID0+IHtcbiAgdmFyIG1hdGNoXG4gIHZhciBjYWxsYmFja1xuICBjb25zdCBwYXRoID0gc2luay5yZXF1ZXN0LnVybC5wYXRoLnNwbGl0KCc/JylcbiAgdXJscy5zb21lKGZ1bmN0aW9uICh1cmwpIHtcbiAgICBtYXRjaCA9IHVybFswXS5tYXRjaChwYXRoWzBdKVxuICAgIGlmICghbWF0Y2gpIHtcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBjYWxsYmFjayA9IHVybFsxXVxuICAgIHJldHVybiB0cnVlXG4gIH0pXG4gIGlmICghbWF0Y2gpIHtcbiAgICByZXR1cm5cbiAgfVxuICBjYWxsYmFjayhzaW5rLCBtYXRjaCwgdmVudGFuYXMucmVhZFVybChwYXRoWzFdKSlcbn0pXG4iLCJpbXBvcnQgand0IGZyb20gJ2pzb253ZWJ0b2tlbidcbmNvbnN0IHFzID0gcmVxdWlyZSgncXMnKVxuXG5leHBvcnQgZnVuY3Rpb24gcmVhZFVybCAodXJsLCB2ZW50YW5hcykge1xuICB1cmwgPSBxcy5wYXJzZSh1cmwpXG4gIHZhciBhcnJheSA9IFtdXG4gIGFycmF5LnF1ZXJ5ID0gdXJsXG4gIGlmICghdXJsW3ZlbnRhbmFzLm9wdGlvbnMucXVlcnldKSB7XG4gICAgcmV0dXJuIGFycmF5XG4gIH1cbiAgdHJ5IHtcbiAgICB1cmwgPSBqd3QudmVyaWZ5KHVybFt2ZW50YW5hcy5vcHRpb25zLnF1ZXJ5XSwgdmVudGFuYXMub3B0aW9ucy5qd3Qua2V5KS52XG5cbiAgICBhcnJheSA9IE9iamVjdC5rZXlzKHVybCkubWFwKGZ1bmN0aW9uIChfaWQpIHtcbiAgICAgIHVybFtfaWRdLl9pZCA9IF9pZFxuICAgICAgcmV0dXJuIHVybFtfaWRdXG4gICAgfSlcbiAgICBhcnJheS5xdWVyeSA9IHVybFxuICAgIHJldHVybiBhcnJheVxuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIGFycmF5XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVVybCAoYXJyYXksIHZlbnRhbmFzKSB7XG4gIGNvbnN0IHBheWxvYWQgPSB7fVxuICBhcnJheS5mb3JFYWNoKGZ1bmN0aW9uICh2KSB7XG4gICAgY29uc3QgX2lkID0gdi5faWRcbiAgICBkZWxldGUgdi5faWRcbiAgICBwYXlsb2FkW19pZF0gPSB2XG4gIH0pXG4gIHJldHVybiBqd3Quc2lnbih7XG4gICAgdjogcGF5bG9hZFxuICB9LCB2ZW50YW5hcy5vcHRpb25zLmp3dC5rZXksIHsgYWxnb3JpdGhtOiB2ZW50YW5hcy5vcHRpb25zLmp3dC5hbGdvcml0aG0gfSlcbn1cbiJdfQ==
