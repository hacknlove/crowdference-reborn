(function () {



/* Exports */
Package._define("frozeman:persistent-minimongo2");

})();
