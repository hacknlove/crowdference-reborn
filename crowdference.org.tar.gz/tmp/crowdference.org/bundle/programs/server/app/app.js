var require = meteorInstall({"common":{"baseDeDatos.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// common/baseDeDatos.js                                                                                  //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({
  clips: () => clips,
  posts: () => posts,
  misClips: () => misClips
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
const clips = new Mongo.Collection('clips');
const posts = new Mongo.Collection('posts');
var misClips;

if (Meteor.isClient) {
  module.runSetters(misClips = new Mongo.Collection(null));
  /* eslint-disable-next-line */

  new PersistentMinimongo2(misClips, 'misClips');
}

if (Meteor.isDevelopment) {
  global.misClips = misClips;
  global.clips = clips;
  global.posts = posts;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"varios.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// common/varios.js                                                                                       //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({
  tituloAUrl: () => tituloAUrl
});
const diacriticas = {
  á: 'a',
  é: 'e',
  í: 'i',
  ó: 'o',
  ú: 'u',
  ñ: 'n',
  ç: 'c'
};

const tituloAUrl = function tituloAUrl(titulo) {
  return (titulo || '').toLowerCase().replace(/[ ]/g, '-').replace(/[áéíúóüñ]/g, function (letra) {
    return diacriticas[letra];
  }).replace(/[^a-z0-9 _.-]/g, '');
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"clip.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/clip.js                                                                                         //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 1);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 2);
let salirValidacion, salir;
module.link("/server/comun", {
  salirValidacion(v) {
    salirValidacion = v;
  },

  salir(v) {
    salir = v;
  }

}, 3);
let tituloAUrl;
module.link("/common/varios", {
  tituloAUrl(v) {
    tituloAUrl = v;
  }

}, 4);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 5);
const validaciones = {
  revocar: Joi.object().keys({
    clipId: Joi.string().required(),
    seguridad: Joi.string().required(),
    llave: Joi.string().valid(['seguridad', 'secreto']).required()
  }),
  establecerStatus: Joi.object().keys({
    clipId: Joi.string().required(),
    postId: Joi.string().required(),
    secreto: Joi.string().required(),
    status: Joi.string().valid(['RECHAZADO', 'OCULTO', 'VISIBLE']).required()
  }),
  eliminarPost: Joi.object().keys({
    clipId: Joi.string().required(),
    postId: Joi.string().required(),
    secreto: Joi.string().required()
  }),
  clipPublish: Joi.object().keys({
    url: Joi.string().regex(/^[a-z-]+$/).required(),
    secreto: Joi.string()
  }),
  clipIdPublish: Joi.object().keys({
    clipId: Joi.string().required(),
    secreto: Joi.string().required()
  }),
  agregarLink: Joi.object().keys({
    url: Joi.string().regex(/^[a-z-]+$/).required(),
    link: Joi.string().required(),
    OG: Joi.object().required()
  }),
  titulo: Joi.string()
};
Meteor.methods({
  crearClip(titulo) {
    salirValidacion({
      data: titulo,
      schema: validaciones.titulo,
      debug: {
        donde: 'method crearClip'
      }
    });

    if (clips.find({
      titulo
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'titulo repetido');
    }

    const url = tituloAUrl(titulo);

    if (clips.find({
      url
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'url repetida');
    }

    const secreto = Random.secret();
    const seguridad = Random.secret();
    const clipId = clips.insert({
      creacion: new Date(),
      titulo,
      url,
      secreto,
      seguridad
    });
    return {
      clipId,
      secreto,
      seguridad
    };
  },

  agregarLink(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.agregarLink,
      debug: {
        donde: 'method agregarLink'
      }
    });
    const clip = clips.findOne({
      url: opciones.url
    }) || salir(404, 'Clip no encontrado', {
      donde: 'method agregarLink'
    });

    if (posts.findOne({
      clipId: clip._id,
      link: opciones.link
    })) {
      return;
    }

    posts.insert({
      clipId: clip._id,
      OG: opciones.OG,
      link: opciones.link,
      timestamp: new Date(),
      status: 'PENDIENTE',
      prioridad: 0
    });

    if (opciones.secreto) {
      clips.update({
        _id: clip._id
      }, {
        $inc: {
          posts: 1
        }
      });
    }
  },

  testTitulo(titulo) {
    salirValidacion({
      data: titulo,
      schema: validaciones.titulo,
      debug: {
        donde: 'method testTitulo'
      }
    }); // if (clips.find({
    //   titulo
    // }, {
    //   limit: 1
    // }).count()) {
    //   console.log('titulo repetido')
    //   throw new Meteor.Error(400, 'titulo repetido')
    // }

    const url = tituloAUrl(titulo);

    if (clips.find({
      url
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'url repetida');
    }
  },

  establecerStatus(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.establecerStatus,
      debug: {
        donde: 'method establecerStatus'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method establecerStatus'
    });
    clips.find({
      _id: opciones.clipId,
      secreto: opciones.secreto
    }).count() || salir(401, 'No tienes permiso para administrar el clip', {
      donde: 'method establecerStatus'
    });
    posts.find({
      _id: opciones.postId,
      clipId: opciones.clipId
    }).count() || salir(404, 'Post no encontrado');
    posts.update(opciones.postId, {
      $set: {
        status: opciones.status
      }
    });
  },

  eliminarPost(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.eliminarPost,
      debug: {
        donde: 'method establecerStatus'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method establecerStatus'
    });
    clips.find({
      _id: opciones.clipId,
      secreto: opciones.secreto
    }).count() || salir(401, 'No tienes permiso para administrar el clip', {
      donde: 'method establecerStatus'
    });
    posts.find({
      _id: opciones.postId,
      clipId: opciones.clipId
    }).count() || salir(404, 'Post no encontrado');
    posts.remove(opciones.postId);
  },

  revocar(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.revocar,
      debug: {
        donde: 'method revocar'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method revocar'
    });
    clips.find({
      _id: opciones.clipId,
      seguridad: opciones.seguridad
    }).count() || salir(400, 'No tienes permiso para revocar llaves', {
      donde: 'method revocar'
    });
    const llave = Random.secret();
    clips.update(opciones.clipId, {
      $set: {
        [opciones.llave]: llave
      }
    });
    return llave;
  }

});
Meteor.publish('clip', function (opciones) {
  salirValidacion({
    data: opciones,
    schema: validaciones.clipPublish,
    debug: {
      donde: 'publish clip'
    }
  });
  const clip = clips.findOne({
    url: opciones.url
  }) || salir(404, 'Clip no encontrado', {
    donde: 'publish clip'
  });
  opciones.secreto && clip.secreto !== opciones.secreto && salir(401, 'No tienes permiso', {
    donde: 'publish clip'
  });
  const postsQuery = {
    clipId: clip._id
  };

  if (!opciones.secreto) {
    postsQuery.status = 'VISIBLE';
  }

  return [clips.find(clip._id, {
    fields: {
      seguridad: 0,
      secreto: 0
    }
  }), posts.find(postsQuery)];
});
Meteor.publish('clipId', function (opciones) {
  salirValidacion({
    data: opciones,
    schema: validaciones.clipIdPublish,
    debug: {
      donde: 'publish clipId'
    }
  });
  return clips.find({
    _id: opciones.clipId,
    secreto: opciones.secreto
  }, {
    fields: {
      seguridad: 0,
      secreto: 0
    }
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comun.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/comun.js                                                                                        //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({
  salir: () => salir,
  salirValidacion: () => salirValidacion
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 1);

const salir = function salir(codigo, mensaje, debug) {
  if (debug) {
    console.log(codigo, mensaje);
    console.log(JSON.stringify(debug, null, 2));
  }

  throw new Meteor.Error(codigo, mensaje);
};

const salirValidacion = function (opciones) {
  const validacion = Joi.validate(opciones.data, opciones.schema);

  if (!validacion.error) {
    return;
  }

  opciones = Object.assign({
    codigo: 400,
    mensaje: validacion.error.details[0].message
  }, opciones);

  if (opciones.debug) {
    opciones.debug.details = validacion.error.details;
    opciones.debug._object = validacion.error._object;
  }

  salir(opciones.codigo, opciones.mensaje, opciones.debug);
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"externo.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/externo.js                                                                                      //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
let cheerio;
module.link("cheerio", {
  default(v) {
    cheerio = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 3);
let moment;
module.link("moment", {
  default(v) {
    moment = v;
  }

}, 4);
let ogs;
module.link("open-graph-scraper", {
  default(v) {
    ogs = v;
  }

}, 5);
const meteorOGS = Meteor.wrapAsync(function (opciones, callback) {
  ogs(opciones, function (e, r, h) {
    callback(e, [r, cheerio.load(h ? h.body : opciones.html)]);
  });
});
const rrss = {
  Instagram: {
    obtenerApoyos($, response) {
      response.data.crLikes = JSON.parse($('script[type="application/ld+json"]').html()).interactionStatistic.userInteractionCount;
      response.data.ogDescription = response.data.ogTitle.replace(/^.*?on Instagram: /, '');
      response.data.ogTitle = response.data.ogTitle.replace(/on Instagram:.*$/, '');
      return response;
    }

  },
  YouTube: {
    regex: /(^|=|\/)([0-9A-Za-z_-]{11})(\/|&|$|\?|#)/,

    obtenerApoyos($, response) {
      const youtube = response.data.ogUrl.match(rrss.YouTube.regex);

      if (!youtube) {
        return response;
      }

      const data = JSON.parse(HTTP.get(`https://www.googleapis.com/youtube/v3/videos?id=${youtube[2]}&key=${Meteor.settings.private.youtubeAPI}&part=statistics`).content).items[0].statistics;
      response.data.crLikes = data.likeCount - data.dislikeCount;
      return response;
    }

  },
  Twitter: {
    obtenerApoyos($, response) {
      var stats = $('ul.stats');
      const retweeted = (stats.find('.request-retweeted-popup').data() || {
        tweetStatCount: 0
      }).tweetStatCount * 1;
      const favorited = (stats.find('.request-favorited-popup').data() || {
        tweetStatCount: 0
      }).tweetStatCount * 1;
      response.data.crLikes = retweeted + favorited;
      response.data.ogTitle = response.data.ogTitle.replace(/on Twitter$/, '');
      return response;
    }

  },
  reddit: {
    obtenerApoyos($, response) {
      response.data.crLikes = parseInt(response.data.ogDescription.replace(/ .*$/, '').replace(/,/, ''));
      response.data.ogDescription = response.data.ogTitle.replace(/^.*?- /, '');
      response.data.ogTitle = response.data.ogTitle.replace(/ - .*$/, '');
      return response;
    }

  },
  Vimeo: {
    obtenerApoyos($, response) {
      const data = JSON.parse(HTTP.get(`${response.data.ogUrl}?action=load_stat_counts`, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:67.0) Gecko/20100101 Firefox/67.0',
          'Referer': response.data.ogUrl,
          'X-Requested-With': 'XMLHttpRequest'
        }
      }).content);
      response.data.crLikes = data.total_likes.raw;
      return response;
    }

  },
  '@meneame_net': {
    obtenerApoyos($, response) {
      const votos = parseInt($('#newswrap').find('.votes').find('a').text());
      response.data.crLikes = votos || 0;
      return response;
    }

  }
};

const actualizar = function actualizar(url) {
  var response;
  var html;
  var opciones;

  if (url.match(/https:\/\/www.facebook/)) {
    opciones = {
      html: HTTP.get(url, {
        headers: {
          'User-Agent': 'FeedFetcher-Google; (+http://www.google.com/feedfetcher.html)'
        }
      }).content
    };
  } else {
    opciones = {
      url
    };
  }

  [response, html] = meteorOGS(opciones);

  if (url.match(/https:\/\/www.facebook/)) {
    response.data.ogSiteName = 'Facebook';
  }

  if (rrss[response.data.ogSiteName || response.data.twitterSite]) {
    return rrss[response.data.ogSiteName || response.data.twitterSite].obtenerApoyos(html, response);
  }

  return response;
};

Meteor.methods({
  actualizarApoyos(clipId, forzar) {
    if (!forzar && clips.findOne({
      _id: clipId,
      actualizacion: {
        $gt: moment().subtract(1, 'hour').toDate()
      }
    })) {
      return;
    }

    var apoyos = 0;
    posts.find({
      clipId,
      status: 'VISIBLE'
    }).forEach(post => {
      const response = actualizar(post.link);
      posts.update({
        _id: post._id
      }, {
        $set: {
          OG: response.data
        }
      });
      apoyos += (response.data.crLikes || 0) * 1;
    });
    clips.update({
      _id: clipId
    }, {
      $set: {
        apoyos,
        actualizacion: new Date()
      }
    });
  },

  previsualizar(url) {
    return actualizar(url);
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"listas.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/listas.js                                                                                       //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 1);
let salirValidacion;
module.link("/server/comun", {
  salirValidacion(v) {
    salirValidacion = v;
  }

}, 2);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 3);
const validaciones = {
  primerPost: Joi.string()
};
Meteor.publish('ranking', function (pagina = 0) {
  return clips.find({
    posts: {
      $gt: 0
    }
  }, {
    fields: {
      secreto: 0,
      seguridad: 0
    },
    sort: {
      apoyos: -1
    },
    skip: 10 * pagina,
    limit: 10
  });
});
Meteor.publish('busqueda', function (busqueda, pagina = 0) {
  var regex = /(?:)/;

  try {
    regex = new RegExp(busqueda);
  } catch (e) {
    regex = /$^/;
  }

  return clips.find({
    titulo: regex,
    posts: {
      $gt: 0
    }
  }, {
    fields: {
      secreto: 0,
      seguridad: 0
    },
    sort: {
      apoyos: -1
    },
    skip: 10 * pagina,
    limit: 10
  });
});
Meteor.publish('primerPost', function (clipId) {
  salirValidacion({
    data: clipId,
    schema: validaciones.primerPost,
    debug: {
      donde: 'publish clip'
    }
  });
  return posts.find({
    clipId,
    status: 'VISIBLE'
  }, {
    sort: {
      prioridad: 1,
      timestamp: -1
    },
    limit: 1
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/common/baseDeDatos.js");
require("/common/varios.js");
require("/server/clip.js");
require("/server/comun.js");
require("/server/externo.js");
require("/server/listas.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29tbW9uL2Jhc2VEZURhdG9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb21tb24vdmFyaW9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY2xpcC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbXVuLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZXh0ZXJuby5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2xpc3Rhcy5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJjbGlwcyIsInBvc3RzIiwibWlzQ2xpcHMiLCJNb25nbyIsImxpbmsiLCJ2IiwiTWV0ZW9yIiwiQ29sbGVjdGlvbiIsImlzQ2xpZW50IiwiUGVyc2lzdGVudE1pbmltb25nbzIiLCJpc0RldmVsb3BtZW50IiwiZ2xvYmFsIiwidGl0dWxvQVVybCIsImRpYWNyaXRpY2FzIiwiw6EiLCLDqSIsIsOtIiwiw7MiLCLDuiIsIsOxIiwiw6ciLCJ0aXR1bG8iLCJ0b0xvd2VyQ2FzZSIsInJlcGxhY2UiLCJsZXRyYSIsIlJhbmRvbSIsInNhbGlyVmFsaWRhY2lvbiIsInNhbGlyIiwiSm9pIiwiZGVmYXVsdCIsInZhbGlkYWNpb25lcyIsInJldm9jYXIiLCJvYmplY3QiLCJrZXlzIiwiY2xpcElkIiwic3RyaW5nIiwicmVxdWlyZWQiLCJzZWd1cmlkYWQiLCJsbGF2ZSIsInZhbGlkIiwiZXN0YWJsZWNlclN0YXR1cyIsInBvc3RJZCIsInNlY3JldG8iLCJzdGF0dXMiLCJlbGltaW5hclBvc3QiLCJjbGlwUHVibGlzaCIsInVybCIsInJlZ2V4IiwiY2xpcElkUHVibGlzaCIsImFncmVnYXJMaW5rIiwiT0ciLCJtZXRob2RzIiwiY3JlYXJDbGlwIiwiZGF0YSIsInNjaGVtYSIsImRlYnVnIiwiZG9uZGUiLCJmaW5kIiwibGltaXQiLCJjb3VudCIsIkVycm9yIiwic2VjcmV0IiwiaW5zZXJ0IiwiY3JlYWNpb24iLCJEYXRlIiwib3BjaW9uZXMiLCJjbGlwIiwiZmluZE9uZSIsIl9pZCIsInRpbWVzdGFtcCIsInByaW9yaWRhZCIsInVwZGF0ZSIsIiRpbmMiLCJ0ZXN0VGl0dWxvIiwiJHNldCIsInJlbW92ZSIsInB1Ymxpc2giLCJwb3N0c1F1ZXJ5IiwiZmllbGRzIiwiY29kaWdvIiwibWVuc2FqZSIsImNvbnNvbGUiLCJsb2ciLCJKU09OIiwic3RyaW5naWZ5IiwidmFsaWRhY2lvbiIsInZhbGlkYXRlIiwiZXJyb3IiLCJPYmplY3QiLCJhc3NpZ24iLCJkZXRhaWxzIiwibWVzc2FnZSIsIl9vYmplY3QiLCJjaGVlcmlvIiwiSFRUUCIsIm1vbWVudCIsIm9ncyIsIm1ldGVvck9HUyIsIndyYXBBc3luYyIsImNhbGxiYWNrIiwiZSIsInIiLCJoIiwibG9hZCIsImJvZHkiLCJodG1sIiwicnJzcyIsIkluc3RhZ3JhbSIsIm9idGVuZXJBcG95b3MiLCIkIiwicmVzcG9uc2UiLCJjckxpa2VzIiwicGFyc2UiLCJpbnRlcmFjdGlvblN0YXRpc3RpYyIsInVzZXJJbnRlcmFjdGlvbkNvdW50Iiwib2dEZXNjcmlwdGlvbiIsIm9nVGl0bGUiLCJZb3VUdWJlIiwieW91dHViZSIsIm9nVXJsIiwibWF0Y2giLCJnZXQiLCJzZXR0aW5ncyIsInByaXZhdGUiLCJ5b3V0dWJlQVBJIiwiY29udGVudCIsIml0ZW1zIiwic3RhdGlzdGljcyIsImxpa2VDb3VudCIsImRpc2xpa2VDb3VudCIsIlR3aXR0ZXIiLCJzdGF0cyIsInJldHdlZXRlZCIsInR3ZWV0U3RhdENvdW50IiwiZmF2b3JpdGVkIiwicmVkZGl0IiwicGFyc2VJbnQiLCJWaW1lbyIsImhlYWRlcnMiLCJ0b3RhbF9saWtlcyIsInJhdyIsInZvdG9zIiwidGV4dCIsImFjdHVhbGl6YXIiLCJvZ1NpdGVOYW1lIiwidHdpdHRlclNpdGUiLCJhY3R1YWxpemFyQXBveW9zIiwiZm9yemFyIiwiYWN0dWFsaXphY2lvbiIsIiRndCIsInN1YnRyYWN0IiwidG9EYXRlIiwiYXBveW9zIiwiZm9yRWFjaCIsInBvc3QiLCJwcmV2aXN1YWxpemFyIiwicHJpbWVyUG9zdCIsInBhZ2luYSIsInNvcnQiLCJza2lwIiwiYnVzcXVlZGEiLCJSZWdFeHAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLE9BQUssRUFBQyxNQUFJQSxLQUFYO0FBQWlCQyxPQUFLLEVBQUMsTUFBSUEsS0FBM0I7QUFBaUNDLFVBQVEsRUFBQyxNQUFJQTtBQUE5QyxDQUFkO0FBQXVFLElBQUlDLEtBQUo7QUFBVUwsTUFBTSxDQUFDTSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRCxPQUFLLENBQUNFLENBQUQsRUFBRztBQUFDRixTQUFLLEdBQUNFLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUMsTUFBSjtBQUFXUixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUd2SSxNQUFNTCxLQUFLLEdBQUcsSUFBSUcsS0FBSyxDQUFDSSxVQUFWLENBQXFCLE9BQXJCLENBQWQ7QUFDQSxNQUFNTixLQUFLLEdBQUcsSUFBSUUsS0FBSyxDQUFDSSxVQUFWLENBQXFCLE9BQXJCLENBQWQ7QUFDQSxJQUFJTCxRQUFKOztBQUVQLElBQUlJLE1BQU0sQ0FBQ0UsUUFBWCxFQUFxQjtBQUNuQixvQkFBQU4sUUFBUSxHQUFHLElBQUlDLEtBQUssQ0FBQ0ksVUFBVixDQUFxQixJQUFyQixDQUFYO0FBQ0E7O0FBQ0EsTUFBSUUsb0JBQUosQ0FBeUJQLFFBQXpCLEVBQW1DLFVBQW5DO0FBQ0Q7O0FBRUQsSUFBSUksTUFBTSxDQUFDSSxhQUFYLEVBQTBCO0FBQ3hCQyxRQUFNLENBQUNULFFBQVAsR0FBa0JBLFFBQWxCO0FBQ0FTLFFBQU0sQ0FBQ1gsS0FBUCxHQUFlQSxLQUFmO0FBQ0FXLFFBQU0sQ0FBQ1YsS0FBUCxHQUFlQSxLQUFmO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUNqQkRILE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNhLFlBQVUsRUFBQyxNQUFJQTtBQUFoQixDQUFkO0FBQUEsTUFBTUMsV0FBVyxHQUFHO0FBQ2xCQyxHQUFDLEVBQUUsR0FEZTtBQUVsQkMsR0FBQyxFQUFFLEdBRmU7QUFHbEJDLEdBQUMsRUFBRSxHQUhlO0FBSWxCQyxHQUFDLEVBQUUsR0FKZTtBQUtsQkMsR0FBQyxFQUFFLEdBTGU7QUFNbEJDLEdBQUMsRUFBRSxHQU5lO0FBT2xCQyxHQUFDLEVBQUU7QUFQZSxDQUFwQjs7QUFVTyxNQUFNUixVQUFVLEdBQUcsU0FBU0EsVUFBVCxDQUFxQlMsTUFBckIsRUFBNkI7QUFDckQsU0FBTyxDQUFDQSxNQUFNLElBQUksRUFBWCxFQUFlQyxXQUFmLEdBQTZCQyxPQUE3QixDQUFxQyxNQUFyQyxFQUE2QyxHQUE3QyxFQUFrREEsT0FBbEQsQ0FBMEQsWUFBMUQsRUFBd0UsVUFBVUMsS0FBVixFQUFpQjtBQUM5RixXQUFPWCxXQUFXLENBQUNXLEtBQUQsQ0FBbEI7QUFDRCxHQUZNLEVBRUpELE9BRkksQ0FFSSxnQkFGSixFQUVzQixFQUZ0QixDQUFQO0FBR0QsQ0FKTSxDOzs7Ozs7Ozs7OztBQ1ZQLElBQUlqQixNQUFKO0FBQVdSLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlvQixNQUFKO0FBQVczQixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNxQixRQUFNLENBQUNwQixDQUFELEVBQUc7QUFBQ29CLFVBQU0sR0FBQ3BCLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUwsS0FBSixFQUFVQyxLQUFWO0FBQWdCSCxNQUFNLENBQUNNLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDSixPQUFLLENBQUNLLENBQUQsRUFBRztBQUFDTCxTQUFLLEdBQUNLLENBQU47QUFBUSxHQUFsQjs7QUFBbUJKLE9BQUssQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNKLFNBQUssR0FBQ0ksQ0FBTjtBQUFROztBQUFwQyxDQUFsQyxFQUF3RSxDQUF4RTtBQUEyRSxJQUFJcUIsZUFBSixFQUFvQkMsS0FBcEI7QUFBMEI3QixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNzQixpQkFBZSxDQUFDckIsQ0FBRCxFQUFHO0FBQUNxQixtQkFBZSxHQUFDckIsQ0FBaEI7QUFBa0IsR0FBdEM7O0FBQXVDc0IsT0FBSyxDQUFDdEIsQ0FBRCxFQUFHO0FBQUNzQixTQUFLLEdBQUN0QixDQUFOO0FBQVE7O0FBQXhELENBQTVCLEVBQXNGLENBQXRGO0FBQXlGLElBQUlPLFVBQUo7QUFBZWQsTUFBTSxDQUFDTSxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ1EsWUFBVSxDQUFDUCxDQUFELEVBQUc7QUFBQ08sY0FBVSxHQUFDUCxDQUFYO0FBQWE7O0FBQTVCLENBQTdCLEVBQTJELENBQTNEO0FBQThELElBQUl1QixHQUFKO0FBQVE5QixNQUFNLENBQUNNLElBQVAsQ0FBWSxLQUFaLEVBQWtCO0FBQUN5QixTQUFPLENBQUN4QixDQUFELEVBQUc7QUFBQ3VCLE9BQUcsR0FBQ3ZCLENBQUo7QUFBTTs7QUFBbEIsQ0FBbEIsRUFBc0MsQ0FBdEM7QUFRbmEsTUFBTXlCLFlBQVksR0FBRztBQUNuQkMsU0FBTyxFQUFFSCxHQUFHLENBQUNJLE1BQUosR0FBYUMsSUFBYixDQUFrQjtBQUN6QkMsVUFBTSxFQUFFTixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQURpQjtBQUV6QkMsYUFBUyxFQUFFVCxHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUZjO0FBR3pCRSxTQUFLLEVBQUVWLEdBQUcsQ0FBQ08sTUFBSixHQUFhSSxLQUFiLENBQW1CLENBQUMsV0FBRCxFQUFjLFNBQWQsQ0FBbkIsRUFBNkNILFFBQTdDO0FBSGtCLEdBQWxCLENBRFU7QUFNbkJJLGtCQUFnQixFQUFFWixHQUFHLENBQUNJLE1BQUosR0FBYUMsSUFBYixDQUFrQjtBQUNsQ0MsVUFBTSxFQUFFTixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUQwQjtBQUVsQ0ssVUFBTSxFQUFFYixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUYwQjtBQUdsQ00sV0FBTyxFQUFFZCxHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUh5QjtBQUlsQ08sVUFBTSxFQUFFZixHQUFHLENBQUNPLE1BQUosR0FBYUksS0FBYixDQUFtQixDQUFDLFdBQUQsRUFBYyxRQUFkLEVBQXdCLFNBQXhCLENBQW5CLEVBQXVESCxRQUF2RDtBQUowQixHQUFsQixDQU5DO0FBWW5CUSxjQUFZLEVBQUVoQixHQUFHLENBQUNJLE1BQUosR0FBYUMsSUFBYixDQUFrQjtBQUM5QkMsVUFBTSxFQUFFTixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQURzQjtBQUU5QkssVUFBTSxFQUFFYixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUZzQjtBQUc5Qk0sV0FBTyxFQUFFZCxHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYjtBQUhxQixHQUFsQixDQVpLO0FBaUJuQlMsYUFBVyxFQUFFakIsR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDN0JhLE9BQUcsRUFBRWxCLEdBQUcsQ0FBQ08sTUFBSixHQUFhWSxLQUFiLENBQW1CLFdBQW5CLEVBQWdDWCxRQUFoQyxFQUR3QjtBQUU3Qk0sV0FBTyxFQUFFZCxHQUFHLENBQUNPLE1BQUo7QUFGb0IsR0FBbEIsQ0FqQk07QUFxQm5CYSxlQUFhLEVBQUVwQixHQUFHLENBQUNJLE1BQUosR0FBYUMsSUFBYixDQUFrQjtBQUMvQkMsVUFBTSxFQUFFTixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUR1QjtBQUUvQk0sV0FBTyxFQUFFZCxHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYjtBQUZzQixHQUFsQixDQXJCSTtBQXlCbkJhLGFBQVcsRUFBRXJCLEdBQUcsQ0FBQ0ksTUFBSixHQUFhQyxJQUFiLENBQWtCO0FBQzdCYSxPQUFHLEVBQUVsQixHQUFHLENBQUNPLE1BQUosR0FBYVksS0FBYixDQUFtQixXQUFuQixFQUFnQ1gsUUFBaEMsRUFEd0I7QUFFN0JoQyxRQUFJLEVBQUV3QixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUZ1QjtBQUc3QmMsTUFBRSxFQUFFdEIsR0FBRyxDQUFDSSxNQUFKLEdBQWFJLFFBQWI7QUFIeUIsR0FBbEIsQ0F6Qk07QUE4Qm5CZixRQUFNLEVBQUVPLEdBQUcsQ0FBQ08sTUFBSjtBQTlCVyxDQUFyQjtBQWlDQTdCLE1BQU0sQ0FBQzZDLE9BQVAsQ0FBZTtBQUNiQyxXQUFTLENBQUUvQixNQUFGLEVBQVU7QUFDakJLLG1CQUFlLENBQUM7QUFDZDJCLFVBQUksRUFBRWhDLE1BRFE7QUFFZGlDLFlBQU0sRUFBRXhCLFlBQVksQ0FBQ1QsTUFGUDtBQUdka0MsV0FBSyxFQUFFO0FBQ0xDLGFBQUssRUFBRTtBQURGO0FBSE8sS0FBRCxDQUFmOztBQVFBLFFBQUl4RCxLQUFLLENBQUN5RCxJQUFOLENBQVc7QUFDYnBDO0FBRGEsS0FBWCxFQUVEO0FBQ0RxQyxXQUFLLEVBQUU7QUFETixLQUZDLEVBSURDLEtBSkMsRUFBSixFQUlZO0FBQ1YsWUFBTSxJQUFJckQsTUFBTSxDQUFDc0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQixpQkFBdEIsQ0FBTjtBQUNEOztBQUNELFVBQU1kLEdBQUcsR0FBR2xDLFVBQVUsQ0FBQ1MsTUFBRCxDQUF0Qjs7QUFDQSxRQUFJckIsS0FBSyxDQUFDeUQsSUFBTixDQUFXO0FBQ2JYO0FBRGEsS0FBWCxFQUVEO0FBQ0RZLFdBQUssRUFBRTtBQUROLEtBRkMsRUFJREMsS0FKQyxFQUFKLEVBSVk7QUFDVixZQUFNLElBQUlyRCxNQUFNLENBQUNzRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGNBQXRCLENBQU47QUFDRDs7QUFFRCxVQUFNbEIsT0FBTyxHQUFHakIsTUFBTSxDQUFDb0MsTUFBUCxFQUFoQjtBQUNBLFVBQU14QixTQUFTLEdBQUdaLE1BQU0sQ0FBQ29DLE1BQVAsRUFBbEI7QUFDQSxVQUFNM0IsTUFBTSxHQUFHbEMsS0FBSyxDQUFDOEQsTUFBTixDQUFhO0FBQzFCQyxjQUFRLEVBQUUsSUFBSUMsSUFBSixFQURnQjtBQUUxQjNDLFlBRjBCO0FBRzFCeUIsU0FIMEI7QUFJMUJKLGFBSjBCO0FBSzFCTDtBQUwwQixLQUFiLENBQWY7QUFRQSxXQUFPO0FBQ0xILFlBREs7QUFFTFEsYUFGSztBQUdMTDtBQUhLLEtBQVA7QUFLRCxHQXpDWTs7QUEwQ2JZLGFBQVcsQ0FBRWdCLFFBQUYsRUFBWTtBQUNyQnZDLG1CQUFlLENBQUM7QUFDZDJCLFVBQUksRUFBRVksUUFEUTtBQUVkWCxZQUFNLEVBQUV4QixZQUFZLENBQUNtQixXQUZQO0FBR2RNLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZjtBQU9BLFVBQU1VLElBQUksR0FBR2xFLEtBQUssQ0FBQ21FLE9BQU4sQ0FBYztBQUN6QnJCLFNBQUcsRUFBRW1CLFFBQVEsQ0FBQ25CO0FBRFcsS0FBZCxLQUVQbkIsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixFQUE0QjtBQUNyQzZCLFdBQUssRUFBRTtBQUQ4QixLQUE1QixDQUZYOztBQU1BLFFBQUl2RCxLQUFLLENBQUNrRSxPQUFOLENBQWM7QUFDaEJqQyxZQUFNLEVBQUVnQyxJQUFJLENBQUNFLEdBREc7QUFFaEJoRSxVQUFJLEVBQUU2RCxRQUFRLENBQUM3RDtBQUZDLEtBQWQsQ0FBSixFQUdJO0FBQ0Y7QUFDRDs7QUFDREgsU0FBSyxDQUFDNkQsTUFBTixDQUFhO0FBQ1g1QixZQUFNLEVBQUVnQyxJQUFJLENBQUNFLEdBREY7QUFFWGxCLFFBQUUsRUFBRWUsUUFBUSxDQUFDZixFQUZGO0FBR1g5QyxVQUFJLEVBQUU2RCxRQUFRLENBQUM3RCxJQUhKO0FBSVhpRSxlQUFTLEVBQUUsSUFBSUwsSUFBSixFQUpBO0FBS1hyQixZQUFNLEVBQUUsV0FMRztBQU1YMkIsZUFBUyxFQUFFO0FBTkEsS0FBYjs7QUFRQSxRQUFJTCxRQUFRLENBQUN2QixPQUFiLEVBQXNCO0FBQ3BCMUMsV0FBSyxDQUFDdUUsTUFBTixDQUFhO0FBQ1hILFdBQUcsRUFBRUYsSUFBSSxDQUFDRTtBQURDLE9BQWIsRUFFRztBQUNESSxZQUFJLEVBQUU7QUFDSnZFLGVBQUssRUFBRTtBQURIO0FBREwsT0FGSDtBQU9EO0FBQ0YsR0EvRVk7O0FBZ0Zid0UsWUFBVSxDQUFFcEQsTUFBRixFQUFVO0FBQ2xCSyxtQkFBZSxDQUFDO0FBQ2QyQixVQUFJLEVBQUVoQyxNQURRO0FBRWRpQyxZQUFNLEVBQUV4QixZQUFZLENBQUNULE1BRlA7QUFHZGtDLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZixDQURrQixDQVFsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFVBQU1WLEdBQUcsR0FBR2xDLFVBQVUsQ0FBQ1MsTUFBRCxDQUF0Qjs7QUFDQSxRQUFJckIsS0FBSyxDQUFDeUQsSUFBTixDQUFXO0FBQ2JYO0FBRGEsS0FBWCxFQUVEO0FBQ0RZLFdBQUssRUFBRTtBQUROLEtBRkMsRUFJREMsS0FKQyxFQUFKLEVBSVk7QUFDVixZQUFNLElBQUlyRCxNQUFNLENBQUNzRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGNBQXRCLENBQU47QUFDRDtBQUNGLEdBeEdZOztBQXlHYnBCLGtCQUFnQixDQUFFeUIsUUFBRixFQUFZO0FBQzFCdkMsbUJBQWUsQ0FBQztBQUNkMkIsVUFBSSxFQUFFWSxRQURRO0FBRWRYLFlBQU0sRUFBRXhCLFlBQVksQ0FBQ1UsZ0JBRlA7QUFHZGUsV0FBSyxFQUFFO0FBQ0xDLGFBQUssRUFBRTtBQURGO0FBSE8sS0FBRCxDQUFmO0FBUUF4RCxTQUFLLENBQUN5RCxJQUFOLENBQVc7QUFDVFcsU0FBRyxFQUFFSCxRQUFRLENBQUMvQjtBQURMLEtBQVgsRUFFR3lCLEtBRkgsTUFFY2hDLEtBQUssQ0FBQyxHQUFELEVBQU0sb0JBQU4sRUFBNEI7QUFDN0M2QixXQUFLLEVBQUU7QUFEc0MsS0FBNUIsQ0FGbkI7QUFNQXhELFNBQUssQ0FBQ3lELElBQU4sQ0FBVztBQUNUVyxTQUFHLEVBQUVILFFBQVEsQ0FBQy9CLE1BREw7QUFFVFEsYUFBTyxFQUFFdUIsUUFBUSxDQUFDdkI7QUFGVCxLQUFYLEVBR0dpQixLQUhILE1BR2NoQyxLQUFLLENBQUMsR0FBRCxFQUFNLDRDQUFOLEVBQW9EO0FBQ3JFNkIsV0FBSyxFQUFFO0FBRDhELEtBQXBELENBSG5CO0FBT0F2RCxTQUFLLENBQUN3RCxJQUFOLENBQVc7QUFDVFcsU0FBRyxFQUFFSCxRQUFRLENBQUN4QixNQURMO0FBRVRQLFlBQU0sRUFBRStCLFFBQVEsQ0FBQy9CO0FBRlIsS0FBWCxFQUdHeUIsS0FISCxNQUdjaEMsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixDQUhuQjtBQUtBMUIsU0FBSyxDQUFDc0UsTUFBTixDQUFhTixRQUFRLENBQUN4QixNQUF0QixFQUE4QjtBQUM1QmlDLFVBQUksRUFBRTtBQUNKL0IsY0FBTSxFQUFFc0IsUUFBUSxDQUFDdEI7QUFEYjtBQURzQixLQUE5QjtBQUtELEdBeklZOztBQTBJYkMsY0FBWSxDQUFFcUIsUUFBRixFQUFZO0FBQ3RCdkMsbUJBQWUsQ0FBQztBQUNkMkIsVUFBSSxFQUFFWSxRQURRO0FBRWRYLFlBQU0sRUFBRXhCLFlBQVksQ0FBQ2MsWUFGUDtBQUdkVyxXQUFLLEVBQUU7QUFDTEMsYUFBSyxFQUFFO0FBREY7QUFITyxLQUFELENBQWY7QUFRQXhELFNBQUssQ0FBQ3lELElBQU4sQ0FBVztBQUNUVyxTQUFHLEVBQUVILFFBQVEsQ0FBQy9CO0FBREwsS0FBWCxFQUVHeUIsS0FGSCxNQUVjaEMsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixFQUE0QjtBQUM3QzZCLFdBQUssRUFBRTtBQURzQyxLQUE1QixDQUZuQjtBQU1BeEQsU0FBSyxDQUFDeUQsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDL0IsTUFETDtBQUVUUSxhQUFPLEVBQUV1QixRQUFRLENBQUN2QjtBQUZULEtBQVgsRUFHR2lCLEtBSEgsTUFHY2hDLEtBQUssQ0FBQyxHQUFELEVBQU0sNENBQU4sRUFBb0Q7QUFDckU2QixXQUFLLEVBQUU7QUFEOEQsS0FBcEQsQ0FIbkI7QUFPQXZELFNBQUssQ0FBQ3dELElBQU4sQ0FBVztBQUNUVyxTQUFHLEVBQUVILFFBQVEsQ0FBQ3hCLE1BREw7QUFFVFAsWUFBTSxFQUFFK0IsUUFBUSxDQUFDL0I7QUFGUixLQUFYLEVBR0d5QixLQUhILE1BR2NoQyxLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLENBSG5CO0FBS0ExQixTQUFLLENBQUMwRSxNQUFOLENBQWFWLFFBQVEsQ0FBQ3hCLE1BQXRCO0FBQ0QsR0F0S1k7O0FBdUtiVixTQUFPLENBQUVrQyxRQUFGLEVBQVk7QUFDakJ2QyxtQkFBZSxDQUFDO0FBQ2QyQixVQUFJLEVBQUVZLFFBRFE7QUFFZFgsWUFBTSxFQUFFeEIsWUFBWSxDQUFDQyxPQUZQO0FBR2R3QixXQUFLLEVBQUU7QUFDTEMsYUFBSyxFQUFFO0FBREY7QUFITyxLQUFELENBQWY7QUFRQXhELFNBQUssQ0FBQ3lELElBQU4sQ0FBVztBQUNUVyxTQUFHLEVBQUVILFFBQVEsQ0FBQy9CO0FBREwsS0FBWCxFQUVHeUIsS0FGSCxNQUVjaEMsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixFQUE0QjtBQUM3QzZCLFdBQUssRUFBRTtBQURzQyxLQUE1QixDQUZuQjtBQU1BeEQsU0FBSyxDQUFDeUQsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDL0IsTUFETDtBQUVURyxlQUFTLEVBQUU0QixRQUFRLENBQUM1QjtBQUZYLEtBQVgsRUFHR3NCLEtBSEgsTUFHY2hDLEtBQUssQ0FBQyxHQUFELEVBQU0sdUNBQU4sRUFBK0M7QUFDaEU2QixXQUFLLEVBQUU7QUFEeUQsS0FBL0MsQ0FIbkI7QUFPQSxVQUFNbEIsS0FBSyxHQUFHYixNQUFNLENBQUNvQyxNQUFQLEVBQWQ7QUFFQTdELFNBQUssQ0FBQ3VFLE1BQU4sQ0FBYU4sUUFBUSxDQUFDL0IsTUFBdEIsRUFBOEI7QUFDNUJ3QyxVQUFJLEVBQUU7QUFDSixTQUFDVCxRQUFRLENBQUMzQixLQUFWLEdBQWtCQTtBQURkO0FBRHNCLEtBQTlCO0FBS0EsV0FBT0EsS0FBUDtBQUNEOztBQXJNWSxDQUFmO0FBd01BaEMsTUFBTSxDQUFDc0UsT0FBUCxDQUFlLE1BQWYsRUFBdUIsVUFBVVgsUUFBVixFQUFvQjtBQUN6Q3ZDLGlCQUFlLENBQUM7QUFDZDJCLFFBQUksRUFBRVksUUFEUTtBQUVkWCxVQUFNLEVBQUV4QixZQUFZLENBQUNlLFdBRlA7QUFHZFUsU0FBSyxFQUFFO0FBQ0xDLFdBQUssRUFBRTtBQURGO0FBSE8sR0FBRCxDQUFmO0FBT0EsUUFBTVUsSUFBSSxHQUFHbEUsS0FBSyxDQUFDbUUsT0FBTixDQUFjO0FBQ3pCckIsT0FBRyxFQUFFbUIsUUFBUSxDQUFDbkI7QUFEVyxHQUFkLEtBRVBuQixLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLEVBQTRCO0FBQ3JDNkIsU0FBSyxFQUFFO0FBRDhCLEdBQTVCLENBRlg7QUFNQVMsVUFBUSxDQUFDdkIsT0FBVCxJQUFvQndCLElBQUksQ0FBQ3hCLE9BQUwsS0FBaUJ1QixRQUFRLENBQUN2QixPQUE5QyxJQUF5RGYsS0FBSyxDQUFDLEdBQUQsRUFBTSxtQkFBTixFQUEyQjtBQUN2RjZCLFNBQUssRUFBRTtBQURnRixHQUEzQixDQUE5RDtBQUlBLFFBQU1xQixVQUFVLEdBQUc7QUFDakIzQyxVQUFNLEVBQUVnQyxJQUFJLENBQUNFO0FBREksR0FBbkI7O0FBSUEsTUFBSSxDQUFDSCxRQUFRLENBQUN2QixPQUFkLEVBQXVCO0FBQ3JCbUMsY0FBVSxDQUFDbEMsTUFBWCxHQUFvQixTQUFwQjtBQUNEOztBQUVELFNBQU8sQ0FDTDNDLEtBQUssQ0FBQ3lELElBQU4sQ0FBV1MsSUFBSSxDQUFDRSxHQUFoQixFQUFxQjtBQUNuQlUsVUFBTSxFQUFFO0FBQ056QyxlQUFTLEVBQUUsQ0FETDtBQUVOSyxhQUFPLEVBQUU7QUFGSDtBQURXLEdBQXJCLENBREssRUFPTHpDLEtBQUssQ0FBQ3dELElBQU4sQ0FBV29CLFVBQVgsQ0FQSyxDQUFQO0FBU0QsQ0FuQ0Q7QUFvQ0F2RSxNQUFNLENBQUNzRSxPQUFQLENBQWUsUUFBZixFQUF5QixVQUFVWCxRQUFWLEVBQW9CO0FBQzNDdkMsaUJBQWUsQ0FBQztBQUNkMkIsUUFBSSxFQUFFWSxRQURRO0FBRWRYLFVBQU0sRUFBRXhCLFlBQVksQ0FBQ2tCLGFBRlA7QUFHZE8sU0FBSyxFQUFFO0FBQ0xDLFdBQUssRUFBRTtBQURGO0FBSE8sR0FBRCxDQUFmO0FBUUEsU0FBT3hELEtBQUssQ0FBQ3lELElBQU4sQ0FBVztBQUNoQlcsT0FBRyxFQUFFSCxRQUFRLENBQUMvQixNQURFO0FBRWhCUSxXQUFPLEVBQUV1QixRQUFRLENBQUN2QjtBQUZGLEdBQVgsRUFHSjtBQUNEb0MsVUFBTSxFQUFFO0FBQ056QyxlQUFTLEVBQUUsQ0FETDtBQUVOSyxhQUFPLEVBQUU7QUFGSDtBQURQLEdBSEksQ0FBUDtBQVNELENBbEJELEU7Ozs7Ozs7Ozs7O0FDclJBNUMsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQzRCLE9BQUssRUFBQyxNQUFJQSxLQUFYO0FBQWlCRCxpQkFBZSxFQUFDLE1BQUlBO0FBQXJDLENBQWQ7QUFBcUUsSUFBSXBCLE1BQUo7QUFBV1IsTUFBTSxDQUFDTSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXVCLEdBQUo7QUFBUTlCLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLEtBQVosRUFBa0I7QUFBQ3lCLFNBQU8sQ0FBQ3hCLENBQUQsRUFBRztBQUFDdUIsT0FBRyxHQUFDdkIsQ0FBSjtBQUFNOztBQUFsQixDQUFsQixFQUFzQyxDQUF0Qzs7QUFHdEksTUFBTXNCLEtBQUssR0FBRyxTQUFTQSxLQUFULENBQWdCb0QsTUFBaEIsRUFBd0JDLE9BQXhCLEVBQWlDekIsS0FBakMsRUFBd0M7QUFDM0QsTUFBSUEsS0FBSixFQUFXO0FBQ1QwQixXQUFPLENBQUNDLEdBQVIsQ0FBWUgsTUFBWixFQUFvQkMsT0FBcEI7QUFDQUMsV0FBTyxDQUFDQyxHQUFSLENBQVlDLElBQUksQ0FBQ0MsU0FBTCxDQUFlN0IsS0FBZixFQUFzQixJQUF0QixFQUE0QixDQUE1QixDQUFaO0FBQ0Q7O0FBQ0QsUUFBTSxJQUFJakQsTUFBTSxDQUFDc0QsS0FBWCxDQUFpQm1CLE1BQWpCLEVBQXlCQyxPQUF6QixDQUFOO0FBQ0QsQ0FOTTs7QUFRQSxNQUFNdEQsZUFBZSxHQUFHLFVBQVV1QyxRQUFWLEVBQW9CO0FBQ2pELFFBQU1vQixVQUFVLEdBQUd6RCxHQUFHLENBQUMwRCxRQUFKLENBQWFyQixRQUFRLENBQUNaLElBQXRCLEVBQTRCWSxRQUFRLENBQUNYLE1BQXJDLENBQW5COztBQUNBLE1BQUksQ0FBQytCLFVBQVUsQ0FBQ0UsS0FBaEIsRUFBdUI7QUFDckI7QUFDRDs7QUFDRHRCLFVBQVEsR0FBR3VCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQ3ZCVixVQUFNLEVBQUUsR0FEZTtBQUV2QkMsV0FBTyxFQUFFSyxVQUFVLENBQUNFLEtBQVgsQ0FBaUJHLE9BQWpCLENBQXlCLENBQXpCLEVBQTRCQztBQUZkLEdBQWQsRUFHUjFCLFFBSFEsQ0FBWDs7QUFJQSxNQUFJQSxRQUFRLENBQUNWLEtBQWIsRUFBb0I7QUFDbEJVLFlBQVEsQ0FBQ1YsS0FBVCxDQUFlbUMsT0FBZixHQUF5QkwsVUFBVSxDQUFDRSxLQUFYLENBQWlCRyxPQUExQztBQUNBekIsWUFBUSxDQUFDVixLQUFULENBQWVxQyxPQUFmLEdBQXlCUCxVQUFVLENBQUNFLEtBQVgsQ0FBaUJLLE9BQTFDO0FBQ0Q7O0FBQ0RqRSxPQUFLLENBQUNzQyxRQUFRLENBQUNjLE1BQVYsRUFBa0JkLFFBQVEsQ0FBQ2UsT0FBM0IsRUFBb0NmLFFBQVEsQ0FBQ1YsS0FBN0MsQ0FBTDtBQUNELENBZE0sQzs7Ozs7Ozs7Ozs7QUNYUCxJQUFJc0MsT0FBSjtBQUFZL0YsTUFBTSxDQUFDTSxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDeUIsU0FBTyxDQUFDeEIsQ0FBRCxFQUFHO0FBQUN3RixXQUFPLEdBQUN4RixDQUFSO0FBQVU7O0FBQXRCLENBQXRCLEVBQThDLENBQTlDO0FBQWlELElBQUl5RixJQUFKO0FBQVNoRyxNQUFNLENBQUNNLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUMwRixNQUFJLENBQUN6RixDQUFELEVBQUc7QUFBQ3lGLFFBQUksR0FBQ3pGLENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSUMsTUFBSjtBQUFXUixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJTCxLQUFKLEVBQVVDLEtBQVY7QUFBZ0JILE1BQU0sQ0FBQ00sSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNKLE9BQUssQ0FBQ0ssQ0FBRCxFQUFHO0FBQUNMLFNBQUssR0FBQ0ssQ0FBTjtBQUFRLEdBQWxCOztBQUFtQkosT0FBSyxDQUFDSSxDQUFELEVBQUc7QUFBQ0osU0FBSyxHQUFDSSxDQUFOO0FBQVE7O0FBQXBDLENBQWxDLEVBQXdFLENBQXhFO0FBQTJFLElBQUkwRixNQUFKO0FBQVdqRyxNQUFNLENBQUNNLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUN5QixTQUFPLENBQUN4QixDQUFELEVBQUc7QUFBQzBGLFVBQU0sR0FBQzFGLENBQVA7QUFBUzs7QUFBckIsQ0FBckIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSTJGLEdBQUo7QUFBUWxHLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUN5QixTQUFPLENBQUN4QixDQUFELEVBQUc7QUFBQzJGLE9BQUcsR0FBQzNGLENBQUo7QUFBTTs7QUFBbEIsQ0FBakMsRUFBcUQsQ0FBckQ7QUFPbFYsTUFBTTRGLFNBQVMsR0FBRzNGLE1BQU0sQ0FBQzRGLFNBQVAsQ0FBaUIsVUFBVWpDLFFBQVYsRUFBb0JrQyxRQUFwQixFQUE4QjtBQUMvREgsS0FBRyxDQUFDL0IsUUFBRCxFQUFXLFVBQVVtQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0JDLENBQWhCLEVBQW1CO0FBQy9CSCxZQUFRLENBQUNDLENBQUQsRUFBSSxDQUFDQyxDQUFELEVBQUlSLE9BQU8sQ0FBQ1UsSUFBUixDQUFhRCxDQUFDLEdBQUdBLENBQUMsQ0FBQ0UsSUFBTCxHQUFZdkMsUUFBUSxDQUFDd0MsSUFBbkMsQ0FBSixDQUFKLENBQVI7QUFDRCxHQUZFLENBQUg7QUFHRCxDQUppQixDQUFsQjtBQU1BLE1BQU1DLElBQUksR0FBRztBQUNYQyxXQUFTLEVBQUU7QUFDVEMsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUJBLGNBQVEsQ0FBQ3pELElBQVQsQ0FBYzBELE9BQWQsR0FBd0I1QixJQUFJLENBQUM2QixLQUFMLENBQVdILENBQUMsQ0FBQyxvQ0FBRCxDQUFELENBQXdDSixJQUF4QyxFQUFYLEVBQTJEUSxvQkFBM0QsQ0FBZ0ZDLG9CQUF4RztBQUNBSixjQUFRLENBQUN6RCxJQUFULENBQWM4RCxhQUFkLEdBQThCTCxRQUFRLENBQUN6RCxJQUFULENBQWMrRCxPQUFkLENBQXNCN0YsT0FBdEIsQ0FBOEIsb0JBQTlCLEVBQW9ELEVBQXBELENBQTlCO0FBQ0F1RixjQUFRLENBQUN6RCxJQUFULENBQWMrRCxPQUFkLEdBQXdCTixRQUFRLENBQUN6RCxJQUFULENBQWMrRCxPQUFkLENBQXNCN0YsT0FBdEIsQ0FBOEIsa0JBQTlCLEVBQWtELEVBQWxELENBQXhCO0FBQ0EsYUFBT3VGLFFBQVA7QUFDRDs7QUFOUSxHQURBO0FBU1hPLFNBQU8sRUFBRTtBQUNQdEUsU0FBSyxFQUFFLDBDQURBOztBQUVQNkQsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUIsWUFBTVEsT0FBTyxHQUFHUixRQUFRLENBQUN6RCxJQUFULENBQWNrRSxLQUFkLENBQW9CQyxLQUFwQixDQUEwQmQsSUFBSSxDQUFDVyxPQUFMLENBQWF0RSxLQUF2QyxDQUFoQjs7QUFDQSxVQUFJLENBQUN1RSxPQUFMLEVBQWM7QUFDWixlQUFPUixRQUFQO0FBQ0Q7O0FBQ0QsWUFBTXpELElBQUksR0FBRzhCLElBQUksQ0FBQzZCLEtBQUwsQ0FBV2xCLElBQUksQ0FBQzJCLEdBQUwsQ0FBVSxtREFBa0RILE9BQU8sQ0FBQyxDQUFELENBQUksUUFBT2hILE1BQU0sQ0FBQ29ILFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCQyxVQUFXLGtCQUFqSCxFQUFvSUMsT0FBL0ksRUFBd0pDLEtBQXhKLENBQThKLENBQTlKLEVBQWlLQyxVQUE5SztBQUVBakIsY0FBUSxDQUFDekQsSUFBVCxDQUFjMEQsT0FBZCxHQUF3QjFELElBQUksQ0FBQzJFLFNBQUwsR0FBaUIzRSxJQUFJLENBQUM0RSxZQUE5QztBQUNBLGFBQU9uQixRQUFQO0FBQ0Q7O0FBWE0sR0FURTtBQXNCWG9CLFNBQU8sRUFBRTtBQUNQdEIsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUIsVUFBSXFCLEtBQUssR0FBR3RCLENBQUMsQ0FBQyxVQUFELENBQWI7QUFDQSxZQUFNdUIsU0FBUyxHQUFHLENBQUNELEtBQUssQ0FBQzFFLElBQU4sQ0FBVywwQkFBWCxFQUF1Q0osSUFBdkMsTUFBaUQ7QUFBRWdGLHNCQUFjLEVBQUU7QUFBbEIsT0FBbEQsRUFBeUVBLGNBQXpFLEdBQTBGLENBQTVHO0FBQ0EsWUFBTUMsU0FBUyxHQUFHLENBQUNILEtBQUssQ0FBQzFFLElBQU4sQ0FBVywwQkFBWCxFQUF1Q0osSUFBdkMsTUFBaUQ7QUFBRWdGLHNCQUFjLEVBQUU7QUFBbEIsT0FBbEQsRUFBeUVBLGNBQXpFLEdBQTBGLENBQTVHO0FBQ0F2QixjQUFRLENBQUN6RCxJQUFULENBQWMwRCxPQUFkLEdBQXdCcUIsU0FBUyxHQUFHRSxTQUFwQztBQUNBeEIsY0FBUSxDQUFDekQsSUFBVCxDQUFjK0QsT0FBZCxHQUF3Qk4sUUFBUSxDQUFDekQsSUFBVCxDQUFjK0QsT0FBZCxDQUFzQjdGLE9BQXRCLENBQThCLGFBQTlCLEVBQTZDLEVBQTdDLENBQXhCO0FBQ0EsYUFBT3VGLFFBQVA7QUFDRDs7QUFSTSxHQXRCRTtBQWdDWHlCLFFBQU0sRUFBRTtBQUNOM0IsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUJBLGNBQVEsQ0FBQ3pELElBQVQsQ0FBYzBELE9BQWQsR0FBd0J5QixRQUFRLENBQUMxQixRQUFRLENBQUN6RCxJQUFULENBQWM4RCxhQUFkLENBQTRCNUYsT0FBNUIsQ0FBb0MsTUFBcEMsRUFBNEMsRUFBNUMsRUFBZ0RBLE9BQWhELENBQXdELEdBQXhELEVBQTZELEVBQTdELENBQUQsQ0FBaEM7QUFDQXVGLGNBQVEsQ0FBQ3pELElBQVQsQ0FBYzhELGFBQWQsR0FBOEJMLFFBQVEsQ0FBQ3pELElBQVQsQ0FBYytELE9BQWQsQ0FBc0I3RixPQUF0QixDQUE4QixRQUE5QixFQUF3QyxFQUF4QyxDQUE5QjtBQUNBdUYsY0FBUSxDQUFDekQsSUFBVCxDQUFjK0QsT0FBZCxHQUF3Qk4sUUFBUSxDQUFDekQsSUFBVCxDQUFjK0QsT0FBZCxDQUFzQjdGLE9BQXRCLENBQThCLFFBQTlCLEVBQXdDLEVBQXhDLENBQXhCO0FBQ0EsYUFBT3VGLFFBQVA7QUFDRDs7QUFOSyxHQWhDRztBQXdDWDJCLE9BQUssRUFBRTtBQUNMN0IsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUIsWUFBTXpELElBQUksR0FBRzhCLElBQUksQ0FBQzZCLEtBQUwsQ0FBV2xCLElBQUksQ0FBQzJCLEdBQUwsQ0FBVSxHQUFFWCxRQUFRLENBQUN6RCxJQUFULENBQWNrRSxLQUFNLDBCQUFoQyxFQUEyRDtBQUNqRm1CLGVBQU8sRUFBRTtBQUNQLHdCQUFjLHNFQURQO0FBRVAscUJBQVc1QixRQUFRLENBQUN6RCxJQUFULENBQWNrRSxLQUZsQjtBQUdQLDhCQUFvQjtBQUhiO0FBRHdFLE9BQTNELEVBTXJCTSxPQU5VLENBQWI7QUFPQWYsY0FBUSxDQUFDekQsSUFBVCxDQUFjMEQsT0FBZCxHQUF3QjFELElBQUksQ0FBQ3NGLFdBQUwsQ0FBaUJDLEdBQXpDO0FBQ0EsYUFBTzlCLFFBQVA7QUFDRDs7QUFYSSxHQXhDSTtBQXFEWCxrQkFBZ0I7QUFDZEYsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUIsWUFBTStCLEtBQUssR0FBR0wsUUFBUSxDQUFDM0IsQ0FBQyxDQUFDLFdBQUQsQ0FBRCxDQUFlcEQsSUFBZixDQUFvQixRQUFwQixFQUE4QkEsSUFBOUIsQ0FBbUMsR0FBbkMsRUFBd0NxRixJQUF4QyxFQUFELENBQXRCO0FBQ0FoQyxjQUFRLENBQUN6RCxJQUFULENBQWMwRCxPQUFkLEdBQXdCOEIsS0FBSyxJQUFJLENBQWpDO0FBQ0EsYUFBTy9CLFFBQVA7QUFDRDs7QUFMYTtBQXJETCxDQUFiOztBQThEQSxNQUFNaUMsVUFBVSxHQUFHLFNBQVNBLFVBQVQsQ0FBcUJqRyxHQUFyQixFQUEwQjtBQUMzQyxNQUFJZ0UsUUFBSjtBQUNBLE1BQUlMLElBQUo7QUFDQSxNQUFJeEMsUUFBSjs7QUFDQSxNQUFJbkIsR0FBRyxDQUFDMEUsS0FBSixDQUFVLHdCQUFWLENBQUosRUFBeUM7QUFDdkN2RCxZQUFRLEdBQUc7QUFDVHdDLFVBQUksRUFBRVgsSUFBSSxDQUFDMkIsR0FBTCxDQUFTM0UsR0FBVCxFQUFjO0FBQ2xCNEYsZUFBTyxFQUFFO0FBQ1Asd0JBQWM7QUFEUDtBQURTLE9BQWQsRUFJSGI7QUFMTSxLQUFYO0FBT0QsR0FSRCxNQVFPO0FBQ0w1RCxZQUFRLEdBQUc7QUFDVG5CO0FBRFMsS0FBWDtBQUdEOztBQUNELEdBQUNnRSxRQUFELEVBQVdMLElBQVgsSUFBbUJSLFNBQVMsQ0FBQ2hDLFFBQUQsQ0FBNUI7O0FBRUEsTUFBSW5CLEdBQUcsQ0FBQzBFLEtBQUosQ0FBVSx3QkFBVixDQUFKLEVBQXlDO0FBQ3ZDVixZQUFRLENBQUN6RCxJQUFULENBQWMyRixVQUFkLEdBQTJCLFVBQTNCO0FBQ0Q7O0FBRUQsTUFBSXRDLElBQUksQ0FBQ0ksUUFBUSxDQUFDekQsSUFBVCxDQUFjMkYsVUFBZCxJQUE0QmxDLFFBQVEsQ0FBQ3pELElBQVQsQ0FBYzRGLFdBQTNDLENBQVIsRUFBaUU7QUFDL0QsV0FBT3ZDLElBQUksQ0FBQ0ksUUFBUSxDQUFDekQsSUFBVCxDQUFjMkYsVUFBZCxJQUE0QmxDLFFBQVEsQ0FBQ3pELElBQVQsQ0FBYzRGLFdBQTNDLENBQUosQ0FBNERyQyxhQUE1RCxDQUEwRUgsSUFBMUUsRUFBZ0ZLLFFBQWhGLENBQVA7QUFDRDs7QUFDRCxTQUFPQSxRQUFQO0FBQ0QsQ0EzQkQ7O0FBNkJBeEcsTUFBTSxDQUFDNkMsT0FBUCxDQUFlO0FBQ2IrRixrQkFBZ0IsQ0FBRWhILE1BQUYsRUFBVWlILE1BQVYsRUFBa0I7QUFDaEMsUUFBSSxDQUFDQSxNQUFELElBQVduSixLQUFLLENBQUNtRSxPQUFOLENBQWM7QUFDM0JDLFNBQUcsRUFBRWxDLE1BRHNCO0FBRTNCa0gsbUJBQWEsRUFBRTtBQUNiQyxXQUFHLEVBQUV0RCxNQUFNLEdBQUd1RCxRQUFULENBQWtCLENBQWxCLEVBQXFCLE1BQXJCLEVBQTZCQyxNQUE3QjtBQURRO0FBRlksS0FBZCxDQUFmLEVBS0k7QUFDRjtBQUNEOztBQUNELFFBQUlDLE1BQU0sR0FBRyxDQUFiO0FBQ0F2SixTQUFLLENBQUN3RCxJQUFOLENBQVc7QUFDVHZCLFlBRFM7QUFFVFMsWUFBTSxFQUFFO0FBRkMsS0FBWCxFQUdHOEcsT0FISCxDQUdXQyxJQUFJLElBQUk7QUFDakIsWUFBTTVDLFFBQVEsR0FBR2lDLFVBQVUsQ0FBQ1csSUFBSSxDQUFDdEosSUFBTixDQUEzQjtBQUNBSCxXQUFLLENBQUNzRSxNQUFOLENBQWE7QUFDWEgsV0FBRyxFQUFFc0YsSUFBSSxDQUFDdEY7QUFEQyxPQUFiLEVBRUc7QUFDRE0sWUFBSSxFQUFFO0FBQ0p4QixZQUFFLEVBQUU0RCxRQUFRLENBQUN6RDtBQURUO0FBREwsT0FGSDtBQU9BbUcsWUFBTSxJQUFJLENBQUMxQyxRQUFRLENBQUN6RCxJQUFULENBQWMwRCxPQUFkLElBQXlCLENBQTFCLElBQStCLENBQXpDO0FBQ0QsS0FiRDtBQWNBL0csU0FBSyxDQUFDdUUsTUFBTixDQUFhO0FBQ1hILFNBQUcsRUFBRWxDO0FBRE0sS0FBYixFQUVHO0FBQ0R3QyxVQUFJLEVBQUU7QUFDSjhFLGNBREk7QUFFSkoscUJBQWEsRUFBRSxJQUFJcEYsSUFBSjtBQUZYO0FBREwsS0FGSDtBQVFELEdBakNZOztBQWtDYjJGLGVBQWEsQ0FBRTdHLEdBQUYsRUFBTztBQUNsQixXQUFPaUcsVUFBVSxDQUFDakcsR0FBRCxDQUFqQjtBQUNEOztBQXBDWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDeEdBLElBQUl4QyxNQUFKO0FBQVdSLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlMLEtBQUosRUFBVUMsS0FBVjtBQUFnQkgsTUFBTSxDQUFDTSxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ0osT0FBSyxDQUFDSyxDQUFELEVBQUc7QUFBQ0wsU0FBSyxHQUFDSyxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CSixPQUFLLENBQUNJLENBQUQsRUFBRztBQUFDSixTQUFLLEdBQUNJLENBQU47QUFBUTs7QUFBcEMsQ0FBbEMsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSXFCLGVBQUo7QUFBb0I1QixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNzQixpQkFBZSxDQUFDckIsQ0FBRCxFQUFHO0FBQUNxQixtQkFBZSxHQUFDckIsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQTVCLEVBQW9FLENBQXBFO0FBQXVFLElBQUl1QixHQUFKO0FBQVE5QixNQUFNLENBQUNNLElBQVAsQ0FBWSxLQUFaLEVBQWtCO0FBQUN5QixTQUFPLENBQUN4QixDQUFELEVBQUc7QUFBQ3VCLE9BQUcsR0FBQ3ZCLENBQUo7QUFBTTs7QUFBbEIsQ0FBbEIsRUFBc0MsQ0FBdEM7QUFLOVAsTUFBTXlCLFlBQVksR0FBRztBQUNuQjhILFlBQVUsRUFBRWhJLEdBQUcsQ0FBQ08sTUFBSjtBQURPLENBQXJCO0FBSUE3QixNQUFNLENBQUNzRSxPQUFQLENBQWUsU0FBZixFQUEwQixVQUFVaUYsTUFBTSxHQUFHLENBQW5CLEVBQXNCO0FBQzlDLFNBQU83SixLQUFLLENBQUN5RCxJQUFOLENBQVc7QUFDaEJ4RCxTQUFLLEVBQUU7QUFDTG9KLFNBQUcsRUFBRTtBQURBO0FBRFMsR0FBWCxFQUlKO0FBQ0R2RSxVQUFNLEVBQUU7QUFDTnBDLGFBQU8sRUFBRSxDQURIO0FBRU5MLGVBQVMsRUFBRTtBQUZMLEtBRFA7QUFLRHlILFFBQUksRUFBRTtBQUNKTixZQUFNLEVBQUUsQ0FBQztBQURMLEtBTEw7QUFRRE8sUUFBSSxFQUFFLEtBQUtGLE1BUlY7QUFTRG5HLFNBQUssRUFBRTtBQVROLEdBSkksQ0FBUDtBQWVELENBaEJEO0FBa0JBcEQsTUFBTSxDQUFDc0UsT0FBUCxDQUFlLFVBQWYsRUFBMkIsVUFBVW9GLFFBQVYsRUFBb0JILE1BQU0sR0FBRyxDQUE3QixFQUFnQztBQUN6RCxNQUFJOUcsS0FBSyxHQUFHLE1BQVo7O0FBQ0EsTUFBSTtBQUNGQSxTQUFLLEdBQUcsSUFBSWtILE1BQUosQ0FBV0QsUUFBWCxDQUFSO0FBQ0QsR0FGRCxDQUVFLE9BQU81RCxDQUFQLEVBQVU7QUFDVnJELFNBQUssR0FBRyxJQUFSO0FBQ0Q7O0FBQ0QsU0FBTy9DLEtBQUssQ0FBQ3lELElBQU4sQ0FBVztBQUNoQnBDLFVBQU0sRUFBRTBCLEtBRFE7QUFFaEI5QyxTQUFLLEVBQUU7QUFDTG9KLFNBQUcsRUFBRTtBQURBO0FBRlMsR0FBWCxFQUtKO0FBQ0R2RSxVQUFNLEVBQUU7QUFDTnBDLGFBQU8sRUFBRSxDQURIO0FBRU5MLGVBQVMsRUFBRTtBQUZMLEtBRFA7QUFLRHlILFFBQUksRUFBRTtBQUNKTixZQUFNLEVBQUUsQ0FBQztBQURMLEtBTEw7QUFRRE8sUUFBSSxFQUFFLEtBQUtGLE1BUlY7QUFTRG5HLFNBQUssRUFBRTtBQVROLEdBTEksQ0FBUDtBQWdCRCxDQXZCRDtBQXlCQXBELE1BQU0sQ0FBQ3NFLE9BQVAsQ0FBZSxZQUFmLEVBQTZCLFVBQVUxQyxNQUFWLEVBQWtCO0FBQzdDUixpQkFBZSxDQUFDO0FBQ2QyQixRQUFJLEVBQUVuQixNQURRO0FBRWRvQixVQUFNLEVBQUV4QixZQUFZLENBQUM4SCxVQUZQO0FBR2RyRyxTQUFLLEVBQUU7QUFDTEMsV0FBSyxFQUFFO0FBREY7QUFITyxHQUFELENBQWY7QUFRQSxTQUFPdkQsS0FBSyxDQUFDd0QsSUFBTixDQUFXO0FBQ2hCdkIsVUFEZ0I7QUFFaEJTLFVBQU0sRUFBRTtBQUZRLEdBQVgsRUFHSjtBQUNEbUgsUUFBSSxFQUFFO0FBQ0p4RixlQUFTLEVBQUUsQ0FEUDtBQUVKRCxlQUFTLEVBQUUsQ0FBQztBQUZSLEtBREw7QUFLRFgsU0FBSyxFQUFFO0FBTE4sR0FISSxDQUFQO0FBVUQsQ0FuQkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuXG5leHBvcnQgY29uc3QgY2xpcHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2xpcHMnKVxuZXhwb3J0IGNvbnN0IHBvc3RzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3Bvc3RzJylcbmV4cG9ydCB2YXIgbWlzQ2xpcHNcblxuaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICBtaXNDbGlwcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKG51bGwpXG4gIC8qIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSAqL1xuICBuZXcgUGVyc2lzdGVudE1pbmltb25nbzIobWlzQ2xpcHMsICdtaXNDbGlwcycpXG59XG5cbmlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCkge1xuICBnbG9iYWwubWlzQ2xpcHMgPSBtaXNDbGlwc1xuICBnbG9iYWwuY2xpcHMgPSBjbGlwc1xuICBnbG9iYWwucG9zdHMgPSBwb3N0c1xufVxuIiwiY29uc3QgZGlhY3JpdGljYXMgPSB7XG4gIMOhOiAnYScsXG4gIMOpOiAnZScsXG4gIMOtOiAnaScsXG4gIMOzOiAnbycsXG4gIMO6OiAndScsXG4gIMOxOiAnbicsXG4gIMOnOiAnYydcbn1cblxuZXhwb3J0IGNvbnN0IHRpdHVsb0FVcmwgPSBmdW5jdGlvbiB0aXR1bG9BVXJsICh0aXR1bG8pIHtcbiAgcmV0dXJuICh0aXR1bG8gfHwgJycpLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvWyBdL2csICctJykucmVwbGFjZSgvW8Ohw6nDrcO6w7PDvMOxXS9nLCBmdW5jdGlvbiAobGV0cmEpIHtcbiAgICByZXR1cm4gZGlhY3JpdGljYXNbbGV0cmFdXG4gIH0pLnJlcGxhY2UoL1teYS16MC05IF8uLV0vZywgJycpXG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgUmFuZG9tIH0gZnJvbSAnbWV0ZW9yL3JhbmRvbSdcbmltcG9ydCB7IGNsaXBzLCBwb3N0cyB9IGZyb20gJy9jb21tb24vYmFzZURlRGF0b3MnXG5pbXBvcnQgeyBzYWxpclZhbGlkYWNpb24sIHNhbGlyIH0gZnJvbSAnL3NlcnZlci9jb211bidcbmltcG9ydCB7IHRpdHVsb0FVcmwgfSBmcm9tICcvY29tbW9uL3ZhcmlvcydcblxuaW1wb3J0IEpvaSBmcm9tICdqb2knXG5cbmNvbnN0IHZhbGlkYWNpb25lcyA9IHtcbiAgcmV2b2NhcjogSm9pLm9iamVjdCgpLmtleXMoe1xuICAgIGNsaXBJZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgc2VndXJpZGFkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBsbGF2ZTogSm9pLnN0cmluZygpLnZhbGlkKFsnc2VndXJpZGFkJywgJ3NlY3JldG8nXSkucmVxdWlyZWQoKVxuICB9KSxcbiAgZXN0YWJsZWNlclN0YXR1czogSm9pLm9iamVjdCgpLmtleXMoe1xuICAgIGNsaXBJZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgcG9zdElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBzZWNyZXRvOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBzdGF0dXM6IEpvaS5zdHJpbmcoKS52YWxpZChbJ1JFQ0hBWkFETycsICdPQ1VMVE8nLCAnVklTSUJMRSddKS5yZXF1aXJlZCgpXG4gIH0pLFxuICBlbGltaW5hclBvc3Q6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICBjbGlwSWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHBvc3RJZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgc2VjcmV0bzogSm9pLnN0cmluZygpLnJlcXVpcmVkKClcbiAgfSksXG4gIGNsaXBQdWJsaXNoOiBKb2kub2JqZWN0KCkua2V5cyh7XG4gICAgdXJsOiBKb2kuc3RyaW5nKCkucmVnZXgoL15bYS16LV0rJC8pLnJlcXVpcmVkKCksXG4gICAgc2VjcmV0bzogSm9pLnN0cmluZygpXG4gIH0pLFxuICBjbGlwSWRQdWJsaXNoOiBKb2kub2JqZWN0KCkua2V5cyh7XG4gICAgY2xpcElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBzZWNyZXRvOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKVxuICB9KSxcbiAgYWdyZWdhckxpbms6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICB1cmw6IEpvaS5zdHJpbmcoKS5yZWdleCgvXlthLXotXSskLykucmVxdWlyZWQoKSxcbiAgICBsaW5rOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBPRzogSm9pLm9iamVjdCgpLnJlcXVpcmVkKClcbiAgfSksXG4gIHRpdHVsbzogSm9pLnN0cmluZygpXG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgY3JlYXJDbGlwICh0aXR1bG8pIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogdGl0dWxvLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMudGl0dWxvLFxuICAgICAgZGVidWc6IHtcbiAgICAgICAgZG9uZGU6ICdtZXRob2QgY3JlYXJDbGlwJ1xuICAgICAgfVxuICAgIH0pXG5cbiAgICBpZiAoY2xpcHMuZmluZCh7XG4gICAgICB0aXR1bG9cbiAgICB9LCB7XG4gICAgICBsaW1pdDogMVxuICAgIH0pLmNvdW50KCkpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCAndGl0dWxvIHJlcGV0aWRvJylcbiAgICB9XG4gICAgY29uc3QgdXJsID0gdGl0dWxvQVVybCh0aXR1bG8pXG4gICAgaWYgKGNsaXBzLmZpbmQoe1xuICAgICAgdXJsXG4gICAgfSwge1xuICAgICAgbGltaXQ6IDFcbiAgICB9KS5jb3VudCgpKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMCwgJ3VybCByZXBldGlkYScpXG4gICAgfVxuXG4gICAgY29uc3Qgc2VjcmV0byA9IFJhbmRvbS5zZWNyZXQoKVxuICAgIGNvbnN0IHNlZ3VyaWRhZCA9IFJhbmRvbS5zZWNyZXQoKVxuICAgIGNvbnN0IGNsaXBJZCA9IGNsaXBzLmluc2VydCh7XG4gICAgICBjcmVhY2lvbjogbmV3IERhdGUoKSxcbiAgICAgIHRpdHVsbyxcbiAgICAgIHVybCxcbiAgICAgIHNlY3JldG8sXG4gICAgICBzZWd1cmlkYWRcbiAgICB9KVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIGNsaXBJZCxcbiAgICAgIHNlY3JldG8sXG4gICAgICBzZWd1cmlkYWRcbiAgICB9XG4gIH0sXG4gIGFncmVnYXJMaW5rIChvcGNpb25lcykge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiBvcGNpb25lcyxcbiAgICAgIHNjaGVtYTogdmFsaWRhY2lvbmVzLmFncmVnYXJMaW5rLFxuICAgICAgZGVidWc6IHtcbiAgICAgICAgZG9uZGU6ICdtZXRob2QgYWdyZWdhckxpbmsnXG4gICAgICB9XG4gICAgfSlcbiAgICBjb25zdCBjbGlwID0gY2xpcHMuZmluZE9uZSh7XG4gICAgICB1cmw6IG9wY2lvbmVzLnVybFxuICAgIH0pIHx8IHNhbGlyKDQwNCwgJ0NsaXAgbm8gZW5jb250cmFkbycsIHtcbiAgICAgIGRvbmRlOiAnbWV0aG9kIGFncmVnYXJMaW5rJ1xuICAgIH0pXG5cbiAgICBpZiAocG9zdHMuZmluZE9uZSh7XG4gICAgICBjbGlwSWQ6IGNsaXAuX2lkLFxuICAgICAgbGluazogb3BjaW9uZXMubGlua1xuICAgIH0pKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgcG9zdHMuaW5zZXJ0KHtcbiAgICAgIGNsaXBJZDogY2xpcC5faWQsXG4gICAgICBPRzogb3BjaW9uZXMuT0csXG4gICAgICBsaW5rOiBvcGNpb25lcy5saW5rLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLFxuICAgICAgc3RhdHVzOiAnUEVORElFTlRFJyxcbiAgICAgIHByaW9yaWRhZDogMFxuICAgIH0pXG4gICAgaWYgKG9wY2lvbmVzLnNlY3JldG8pIHtcbiAgICAgIGNsaXBzLnVwZGF0ZSh7XG4gICAgICAgIF9pZDogY2xpcC5faWRcbiAgICAgIH0sIHtcbiAgICAgICAgJGluYzoge1xuICAgICAgICAgIHBvc3RzOiAxXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuICB9LFxuICB0ZXN0VGl0dWxvICh0aXR1bG8pIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogdGl0dWxvLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMudGl0dWxvLFxuICAgICAgZGVidWc6IHtcbiAgICAgICAgZG9uZGU6ICdtZXRob2QgdGVzdFRpdHVsbydcbiAgICAgIH1cbiAgICB9KVxuICAgIC8vIGlmIChjbGlwcy5maW5kKHtcbiAgICAvLyAgIHRpdHVsb1xuICAgIC8vIH0sIHtcbiAgICAvLyAgIGxpbWl0OiAxXG4gICAgLy8gfSkuY291bnQoKSkge1xuICAgIC8vICAgY29uc29sZS5sb2coJ3RpdHVsbyByZXBldGlkbycpXG4gICAgLy8gICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMCwgJ3RpdHVsbyByZXBldGlkbycpXG4gICAgLy8gfVxuICAgIGNvbnN0IHVybCA9IHRpdHVsb0FVcmwodGl0dWxvKVxuICAgIGlmIChjbGlwcy5maW5kKHtcbiAgICAgIHVybFxuICAgIH0sIHtcbiAgICAgIGxpbWl0OiAxXG4gICAgfSkuY291bnQoKSkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsICd1cmwgcmVwZXRpZGEnKVxuICAgIH1cbiAgfSxcbiAgZXN0YWJsZWNlclN0YXR1cyAob3BjaW9uZXMpIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogb3BjaW9uZXMsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5lc3RhYmxlY2VyU3RhdHVzLFxuICAgICAgZGVidWc6IHtcbiAgICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgY2xpcHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZFxuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDA0LCAnQ2xpcCBubyBlbmNvbnRyYWRvJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICB9KVxuXG4gICAgY2xpcHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZCxcbiAgICAgIHNlY3JldG86IG9wY2lvbmVzLnNlY3JldG9cbiAgICB9KS5jb3VudCgpIHx8IHNhbGlyKDQwMSwgJ05vIHRpZW5lcyBwZXJtaXNvIHBhcmEgYWRtaW5pc3RyYXIgZWwgY2xpcCcsIHtcbiAgICAgIGRvbmRlOiAnbWV0aG9kIGVzdGFibGVjZXJTdGF0dXMnXG4gICAgfSlcblxuICAgIHBvc3RzLmZpbmQoe1xuICAgICAgX2lkOiBvcGNpb25lcy5wb3N0SWQsXG4gICAgICBjbGlwSWQ6IG9wY2lvbmVzLmNsaXBJZFxuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDA0LCAnUG9zdCBubyBlbmNvbnRyYWRvJylcblxuICAgIHBvc3RzLnVwZGF0ZShvcGNpb25lcy5wb3N0SWQsIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgc3RhdHVzOiBvcGNpb25lcy5zdGF0dXNcbiAgICAgIH1cbiAgICB9KVxuICB9LFxuICBlbGltaW5hclBvc3QgKG9wY2lvbmVzKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMuZWxpbWluYXJQb3N0LFxuICAgICAgZGVidWc6IHtcbiAgICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgY2xpcHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZFxuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDA0LCAnQ2xpcCBubyBlbmNvbnRyYWRvJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICB9KVxuXG4gICAgY2xpcHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZCxcbiAgICAgIHNlY3JldG86IG9wY2lvbmVzLnNlY3JldG9cbiAgICB9KS5jb3VudCgpIHx8IHNhbGlyKDQwMSwgJ05vIHRpZW5lcyBwZXJtaXNvIHBhcmEgYWRtaW5pc3RyYXIgZWwgY2xpcCcsIHtcbiAgICAgIGRvbmRlOiAnbWV0aG9kIGVzdGFibGVjZXJTdGF0dXMnXG4gICAgfSlcblxuICAgIHBvc3RzLmZpbmQoe1xuICAgICAgX2lkOiBvcGNpb25lcy5wb3N0SWQsXG4gICAgICBjbGlwSWQ6IG9wY2lvbmVzLmNsaXBJZFxuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDA0LCAnUG9zdCBubyBlbmNvbnRyYWRvJylcblxuICAgIHBvc3RzLnJlbW92ZShvcGNpb25lcy5wb3N0SWQpXG4gIH0sXG4gIHJldm9jYXIgKG9wY2lvbmVzKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMucmV2b2NhcixcbiAgICAgIGRlYnVnOiB7XG4gICAgICAgIGRvbmRlOiAnbWV0aG9kIHJldm9jYXInXG4gICAgICB9XG4gICAgfSlcblxuICAgIGNsaXBzLmZpbmQoe1xuICAgICAgX2lkOiBvcGNpb25lcy5jbGlwSWRcbiAgICB9KS5jb3VudCgpIHx8IHNhbGlyKDQwNCwgJ0NsaXAgbm8gZW5jb250cmFkbycsIHtcbiAgICAgIGRvbmRlOiAnbWV0aG9kIHJldm9jYXInXG4gICAgfSlcblxuICAgIGNsaXBzLmZpbmQoe1xuICAgICAgX2lkOiBvcGNpb25lcy5jbGlwSWQsXG4gICAgICBzZWd1cmlkYWQ6IG9wY2lvbmVzLnNlZ3VyaWRhZFxuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDAwLCAnTm8gdGllbmVzIHBlcm1pc28gcGFyYSByZXZvY2FyIGxsYXZlcycsIHtcbiAgICAgIGRvbmRlOiAnbWV0aG9kIHJldm9jYXInXG4gICAgfSlcblxuICAgIGNvbnN0IGxsYXZlID0gUmFuZG9tLnNlY3JldCgpXG5cbiAgICBjbGlwcy51cGRhdGUob3BjaW9uZXMuY2xpcElkLCB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIFtvcGNpb25lcy5sbGF2ZV06IGxsYXZlXG4gICAgICB9XG4gICAgfSlcbiAgICByZXR1cm4gbGxhdmVcbiAgfVxufSlcblxuTWV0ZW9yLnB1Ymxpc2goJ2NsaXAnLCBmdW5jdGlvbiAob3BjaW9uZXMpIHtcbiAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICBkYXRhOiBvcGNpb25lcyxcbiAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5jbGlwUHVibGlzaCxcbiAgICBkZWJ1Zzoge1xuICAgICAgZG9uZGU6ICdwdWJsaXNoIGNsaXAnXG4gICAgfVxuICB9KVxuICBjb25zdCBjbGlwID0gY2xpcHMuZmluZE9uZSh7XG4gICAgdXJsOiBvcGNpb25lcy51cmxcbiAgfSkgfHwgc2FsaXIoNDA0LCAnQ2xpcCBubyBlbmNvbnRyYWRvJywge1xuICAgIGRvbmRlOiAncHVibGlzaCBjbGlwJ1xuICB9KVxuXG4gIG9wY2lvbmVzLnNlY3JldG8gJiYgY2xpcC5zZWNyZXRvICE9PSBvcGNpb25lcy5zZWNyZXRvICYmIHNhbGlyKDQwMSwgJ05vIHRpZW5lcyBwZXJtaXNvJywge1xuICAgIGRvbmRlOiAncHVibGlzaCBjbGlwJ1xuICB9KVxuXG4gIGNvbnN0IHBvc3RzUXVlcnkgPSB7XG4gICAgY2xpcElkOiBjbGlwLl9pZFxuICB9XG5cbiAgaWYgKCFvcGNpb25lcy5zZWNyZXRvKSB7XG4gICAgcG9zdHNRdWVyeS5zdGF0dXMgPSAnVklTSUJMRSdcbiAgfVxuXG4gIHJldHVybiBbXG4gICAgY2xpcHMuZmluZChjbGlwLl9pZCwge1xuICAgICAgZmllbGRzOiB7XG4gICAgICAgIHNlZ3VyaWRhZDogMCxcbiAgICAgICAgc2VjcmV0bzogMFxuICAgICAgfVxuICAgIH0pLFxuICAgIHBvc3RzLmZpbmQocG9zdHNRdWVyeSlcbiAgXVxufSlcbk1ldGVvci5wdWJsaXNoKCdjbGlwSWQnLCBmdW5jdGlvbiAob3BjaW9uZXMpIHtcbiAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICBkYXRhOiBvcGNpb25lcyxcbiAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5jbGlwSWRQdWJsaXNoLFxuICAgIGRlYnVnOiB7XG4gICAgICBkb25kZTogJ3B1Ymxpc2ggY2xpcElkJ1xuICAgIH1cbiAgfSlcblxuICByZXR1cm4gY2xpcHMuZmluZCh7XG4gICAgX2lkOiBvcGNpb25lcy5jbGlwSWQsXG4gICAgc2VjcmV0bzogb3BjaW9uZXMuc2VjcmV0b1xuICB9LCB7XG4gICAgZmllbGRzOiB7XG4gICAgICBzZWd1cmlkYWQ6IDAsXG4gICAgICBzZWNyZXRvOiAwXG4gICAgfVxuICB9KVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgSm9pIGZyb20gJ2pvaSdcblxuZXhwb3J0IGNvbnN0IHNhbGlyID0gZnVuY3Rpb24gc2FsaXIgKGNvZGlnbywgbWVuc2FqZSwgZGVidWcpIHtcbiAgaWYgKGRlYnVnKSB7XG4gICAgY29uc29sZS5sb2coY29kaWdvLCBtZW5zYWplKVxuICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KGRlYnVnLCBudWxsLCAyKSlcbiAgfVxuICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGNvZGlnbywgbWVuc2FqZSlcbn1cblxuZXhwb3J0IGNvbnN0IHNhbGlyVmFsaWRhY2lvbiA9IGZ1bmN0aW9uIChvcGNpb25lcykge1xuICBjb25zdCB2YWxpZGFjaW9uID0gSm9pLnZhbGlkYXRlKG9wY2lvbmVzLmRhdGEsIG9wY2lvbmVzLnNjaGVtYSlcbiAgaWYgKCF2YWxpZGFjaW9uLmVycm9yKSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgb3BjaW9uZXMgPSBPYmplY3QuYXNzaWduKHtcbiAgICBjb2RpZ286IDQwMCxcbiAgICBtZW5zYWplOiB2YWxpZGFjaW9uLmVycm9yLmRldGFpbHNbMF0ubWVzc2FnZVxuICB9LCBvcGNpb25lcylcbiAgaWYgKG9wY2lvbmVzLmRlYnVnKSB7XG4gICAgb3BjaW9uZXMuZGVidWcuZGV0YWlscyA9IHZhbGlkYWNpb24uZXJyb3IuZGV0YWlsc1xuICAgIG9wY2lvbmVzLmRlYnVnLl9vYmplY3QgPSB2YWxpZGFjaW9uLmVycm9yLl9vYmplY3RcbiAgfVxuICBzYWxpcihvcGNpb25lcy5jb2RpZ28sIG9wY2lvbmVzLm1lbnNhamUsIG9wY2lvbmVzLmRlYnVnKVxufVxuIiwiaW1wb3J0IGNoZWVyaW8gZnJvbSAnY2hlZXJpbydcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCdcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBjbGlwcywgcG9zdHMgfSBmcm9tICcvY29tbW9uL2Jhc2VEZURhdG9zJ1xuaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnXG5pbXBvcnQgb2dzIGZyb20gJ29wZW4tZ3JhcGgtc2NyYXBlcidcblxuY29uc3QgbWV0ZW9yT0dTID0gTWV0ZW9yLndyYXBBc3luYyhmdW5jdGlvbiAob3BjaW9uZXMsIGNhbGxiYWNrKSB7XG4gIG9ncyhvcGNpb25lcywgZnVuY3Rpb24gKGUsIHIsIGgpIHtcbiAgICBjYWxsYmFjayhlLCBbciwgY2hlZXJpby5sb2FkKGggPyBoLmJvZHkgOiBvcGNpb25lcy5odG1sKV0pXG4gIH0pXG59KVxuXG5jb25zdCBycnNzID0ge1xuICBJbnN0YWdyYW06IHtcbiAgICBvYnRlbmVyQXBveW9zICgkLCByZXNwb25zZSkge1xuICAgICAgcmVzcG9uc2UuZGF0YS5jckxpa2VzID0gSlNPTi5wYXJzZSgkKCdzY3JpcHRbdHlwZT1cImFwcGxpY2F0aW9uL2xkK2pzb25cIl0nKS5odG1sKCkpLmludGVyYWN0aW9uU3RhdGlzdGljLnVzZXJJbnRlcmFjdGlvbkNvdW50XG4gICAgICByZXNwb25zZS5kYXRhLm9nRGVzY3JpcHRpb24gPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvXi4qP29uIEluc3RhZ3JhbTogLywgJycpXG4gICAgICByZXNwb25zZS5kYXRhLm9nVGl0bGUgPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvb24gSW5zdGFncmFtOi4qJC8sICcnKVxuICAgICAgcmV0dXJuIHJlc3BvbnNlXG4gICAgfVxuICB9LFxuICBZb3VUdWJlOiB7XG4gICAgcmVnZXg6IC8oXnw9fFxcLykoWzAtOUEtWmEtel8tXXsxMX0pKFxcL3wmfCR8XFw/fCMpLyxcbiAgICBvYnRlbmVyQXBveW9zICgkLCByZXNwb25zZSkge1xuICAgICAgY29uc3QgeW91dHViZSA9IHJlc3BvbnNlLmRhdGEub2dVcmwubWF0Y2gocnJzcy5Zb3VUdWJlLnJlZ2V4KVxuICAgICAgaWYgKCF5b3V0dWJlKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZVxuICAgICAgfVxuICAgICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UoSFRUUC5nZXQoYGh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL3lvdXR1YmUvdjMvdmlkZW9zP2lkPSR7eW91dHViZVsyXX0ma2V5PSR7TWV0ZW9yLnNldHRpbmdzLnByaXZhdGUueW91dHViZUFQSX0mcGFydD1zdGF0aXN0aWNzYCkuY29udGVudCkuaXRlbXNbMF0uc3RhdGlzdGljc1xuXG4gICAgICByZXNwb25zZS5kYXRhLmNyTGlrZXMgPSBkYXRhLmxpa2VDb3VudCAtIGRhdGEuZGlzbGlrZUNvdW50XG4gICAgICByZXR1cm4gcmVzcG9uc2VcbiAgICB9XG4gIH0sXG4gIFR3aXR0ZXI6IHtcbiAgICBvYnRlbmVyQXBveW9zICgkLCByZXNwb25zZSkge1xuICAgICAgdmFyIHN0YXRzID0gJCgndWwuc3RhdHMnKVxuICAgICAgY29uc3QgcmV0d2VldGVkID0gKHN0YXRzLmZpbmQoJy5yZXF1ZXN0LXJldHdlZXRlZC1wb3B1cCcpLmRhdGEoKSB8fCB7IHR3ZWV0U3RhdENvdW50OiAwIH0pLnR3ZWV0U3RhdENvdW50ICogMVxuICAgICAgY29uc3QgZmF2b3JpdGVkID0gKHN0YXRzLmZpbmQoJy5yZXF1ZXN0LWZhdm9yaXRlZC1wb3B1cCcpLmRhdGEoKSB8fCB7IHR3ZWV0U3RhdENvdW50OiAwIH0pLnR3ZWV0U3RhdENvdW50ICogMVxuICAgICAgcmVzcG9uc2UuZGF0YS5jckxpa2VzID0gcmV0d2VldGVkICsgZmF2b3JpdGVkXG4gICAgICByZXNwb25zZS5kYXRhLm9nVGl0bGUgPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvb24gVHdpdHRlciQvLCAnJylcbiAgICAgIHJldHVybiByZXNwb25zZVxuICAgIH1cbiAgfSxcbiAgcmVkZGl0OiB7XG4gICAgb2J0ZW5lckFwb3lvcyAoJCwgcmVzcG9uc2UpIHtcbiAgICAgIHJlc3BvbnNlLmRhdGEuY3JMaWtlcyA9IHBhcnNlSW50KHJlc3BvbnNlLmRhdGEub2dEZXNjcmlwdGlvbi5yZXBsYWNlKC8gLiokLywgJycpLnJlcGxhY2UoLywvLCAnJykpXG4gICAgICByZXNwb25zZS5kYXRhLm9nRGVzY3JpcHRpb24gPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvXi4qPy0gLywgJycpXG4gICAgICByZXNwb25zZS5kYXRhLm9nVGl0bGUgPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvIC0gLiokLywgJycpXG4gICAgICByZXR1cm4gcmVzcG9uc2VcbiAgICB9XG4gIH0sXG4gIFZpbWVvOiB7XG4gICAgb2J0ZW5lckFwb3lvcyAoJCwgcmVzcG9uc2UpIHtcbiAgICAgIGNvbnN0IGRhdGEgPSBKU09OLnBhcnNlKEhUVFAuZ2V0KGAke3Jlc3BvbnNlLmRhdGEub2dVcmx9P2FjdGlvbj1sb2FkX3N0YXRfY291bnRzYCwge1xuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ1VzZXItQWdlbnQnOiAnTW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0OyBydjo2Ny4wKSBHZWNrby8yMDEwMDEwMSBGaXJlZm94LzY3LjAnLFxuICAgICAgICAgICdSZWZlcmVyJzogcmVzcG9uc2UuZGF0YS5vZ1VybCxcbiAgICAgICAgICAnWC1SZXF1ZXN0ZWQtV2l0aCc6ICdYTUxIdHRwUmVxdWVzdCdcbiAgICAgICAgfVxuICAgICAgfSkuY29udGVudClcbiAgICAgIHJlc3BvbnNlLmRhdGEuY3JMaWtlcyA9IGRhdGEudG90YWxfbGlrZXMucmF3XG4gICAgICByZXR1cm4gcmVzcG9uc2VcbiAgICB9XG4gIH0sXG4gICdAbWVuZWFtZV9uZXQnOiB7XG4gICAgb2J0ZW5lckFwb3lvcyAoJCwgcmVzcG9uc2UpIHtcbiAgICAgIGNvbnN0IHZvdG9zID0gcGFyc2VJbnQoJCgnI25ld3N3cmFwJykuZmluZCgnLnZvdGVzJykuZmluZCgnYScpLnRleHQoKSlcbiAgICAgIHJlc3BvbnNlLmRhdGEuY3JMaWtlcyA9IHZvdG9zIHx8IDBcbiAgICAgIHJldHVybiByZXNwb25zZVxuICAgIH1cbiAgfVxufVxuXG5jb25zdCBhY3R1YWxpemFyID0gZnVuY3Rpb24gYWN0dWFsaXphciAodXJsKSB7XG4gIHZhciByZXNwb25zZVxuICB2YXIgaHRtbFxuICB2YXIgb3BjaW9uZXNcbiAgaWYgKHVybC5tYXRjaCgvaHR0cHM6XFwvXFwvd3d3LmZhY2Vib29rLykpIHtcbiAgICBvcGNpb25lcyA9IHtcbiAgICAgIGh0bWw6IEhUVFAuZ2V0KHVybCwge1xuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ1VzZXItQWdlbnQnOiAnRmVlZEZldGNoZXItR29vZ2xlOyAoK2h0dHA6Ly93d3cuZ29vZ2xlLmNvbS9mZWVkZmV0Y2hlci5odG1sKSdcbiAgICAgICAgfVxuICAgICAgfSkuY29udGVudFxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBvcGNpb25lcyA9IHtcbiAgICAgIHVybFxuICAgIH1cbiAgfVxuICBbcmVzcG9uc2UsIGh0bWxdID0gbWV0ZW9yT0dTKG9wY2lvbmVzKVxuXG4gIGlmICh1cmwubWF0Y2goL2h0dHBzOlxcL1xcL3d3dy5mYWNlYm9vay8pKSB7XG4gICAgcmVzcG9uc2UuZGF0YS5vZ1NpdGVOYW1lID0gJ0ZhY2Vib29rJ1xuICB9XG5cbiAgaWYgKHJyc3NbcmVzcG9uc2UuZGF0YS5vZ1NpdGVOYW1lIHx8IHJlc3BvbnNlLmRhdGEudHdpdHRlclNpdGVdKSB7XG4gICAgcmV0dXJuIHJyc3NbcmVzcG9uc2UuZGF0YS5vZ1NpdGVOYW1lIHx8IHJlc3BvbnNlLmRhdGEudHdpdHRlclNpdGVdLm9idGVuZXJBcG95b3MoaHRtbCwgcmVzcG9uc2UpXG4gIH1cbiAgcmV0dXJuIHJlc3BvbnNlXG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgYWN0dWFsaXphckFwb3lvcyAoY2xpcElkLCBmb3J6YXIpIHtcbiAgICBpZiAoIWZvcnphciAmJiBjbGlwcy5maW5kT25lKHtcbiAgICAgIF9pZDogY2xpcElkLFxuICAgICAgYWN0dWFsaXphY2lvbjoge1xuICAgICAgICAkZ3Q6IG1vbWVudCgpLnN1YnRyYWN0KDEsICdob3VyJykudG9EYXRlKClcbiAgICAgIH1cbiAgICB9KSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHZhciBhcG95b3MgPSAwXG4gICAgcG9zdHMuZmluZCh7XG4gICAgICBjbGlwSWQsXG4gICAgICBzdGF0dXM6ICdWSVNJQkxFJ1xuICAgIH0pLmZvckVhY2gocG9zdCA9PiB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGFjdHVhbGl6YXIocG9zdC5saW5rKVxuICAgICAgcG9zdHMudXBkYXRlKHtcbiAgICAgICAgX2lkOiBwb3N0Ll9pZFxuICAgICAgfSwge1xuICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgT0c6IHJlc3BvbnNlLmRhdGFcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICAgIGFwb3lvcyArPSAocmVzcG9uc2UuZGF0YS5jckxpa2VzIHx8IDApICogMVxuICAgIH0pXG4gICAgY2xpcHMudXBkYXRlKHtcbiAgICAgIF9pZDogY2xpcElkXG4gICAgfSwge1xuICAgICAgJHNldDoge1xuICAgICAgICBhcG95b3MsXG4gICAgICAgIGFjdHVhbGl6YWNpb246IG5ldyBEYXRlKClcbiAgICAgIH1cbiAgICB9KVxuICB9LFxuICBwcmV2aXN1YWxpemFyICh1cmwpIHtcbiAgICByZXR1cm4gYWN0dWFsaXphcih1cmwpXG4gIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgY2xpcHMsIHBvc3RzIH0gZnJvbSAnL2NvbW1vbi9iYXNlRGVEYXRvcydcbmltcG9ydCB7IHNhbGlyVmFsaWRhY2lvbiB9IGZyb20gJy9zZXJ2ZXIvY29tdW4nXG5pbXBvcnQgSm9pIGZyb20gJ2pvaSdcblxuY29uc3QgdmFsaWRhY2lvbmVzID0ge1xuICBwcmltZXJQb3N0OiBKb2kuc3RyaW5nKClcbn1cblxuTWV0ZW9yLnB1Ymxpc2goJ3JhbmtpbmcnLCBmdW5jdGlvbiAocGFnaW5hID0gMCkge1xuICByZXR1cm4gY2xpcHMuZmluZCh7XG4gICAgcG9zdHM6IHtcbiAgICAgICRndDogMFxuICAgIH1cbiAgfSwge1xuICAgIGZpZWxkczoge1xuICAgICAgc2VjcmV0bzogMCxcbiAgICAgIHNlZ3VyaWRhZDogMFxuICAgIH0sXG4gICAgc29ydDoge1xuICAgICAgYXBveW9zOiAtMVxuICAgIH0sXG4gICAgc2tpcDogMTAgKiBwYWdpbmEsXG4gICAgbGltaXQ6IDEwXG4gIH0pXG59KVxuXG5NZXRlb3IucHVibGlzaCgnYnVzcXVlZGEnLCBmdW5jdGlvbiAoYnVzcXVlZGEsIHBhZ2luYSA9IDApIHtcbiAgdmFyIHJlZ2V4ID0gLyg/OikvXG4gIHRyeSB7XG4gICAgcmVnZXggPSBuZXcgUmVnRXhwKGJ1c3F1ZWRhKVxuICB9IGNhdGNoIChlKSB7XG4gICAgcmVnZXggPSAvJF4vXG4gIH1cbiAgcmV0dXJuIGNsaXBzLmZpbmQoe1xuICAgIHRpdHVsbzogcmVnZXgsXG4gICAgcG9zdHM6IHtcbiAgICAgICRndDogMFxuICAgIH1cbiAgfSwge1xuICAgIGZpZWxkczoge1xuICAgICAgc2VjcmV0bzogMCxcbiAgICAgIHNlZ3VyaWRhZDogMFxuICAgIH0sXG4gICAgc29ydDoge1xuICAgICAgYXBveW9zOiAtMVxuICAgIH0sXG4gICAgc2tpcDogMTAgKiBwYWdpbmEsXG4gICAgbGltaXQ6IDEwXG4gIH0pXG59KVxuXG5NZXRlb3IucHVibGlzaCgncHJpbWVyUG9zdCcsIGZ1bmN0aW9uIChjbGlwSWQpIHtcbiAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICBkYXRhOiBjbGlwSWQsXG4gICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMucHJpbWVyUG9zdCxcbiAgICBkZWJ1Zzoge1xuICAgICAgZG9uZGU6ICdwdWJsaXNoIGNsaXAnXG4gICAgfVxuICB9KVxuXG4gIHJldHVybiBwb3N0cy5maW5kKHtcbiAgICBjbGlwSWQsXG4gICAgc3RhdHVzOiAnVklTSUJMRSdcbiAgfSwge1xuICAgIHNvcnQ6IHtcbiAgICAgIHByaW9yaWRhZDogMSxcbiAgICAgIHRpbWVzdGFtcDogLTFcbiAgICB9LFxuICAgIGxpbWl0OiAxXG4gIH0pXG59KVxuIl19
