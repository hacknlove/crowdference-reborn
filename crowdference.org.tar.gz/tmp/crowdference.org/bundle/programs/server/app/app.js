var require = meteorInstall({"common":{"baseDeDatos.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// common/baseDeDatos.js                                                                                  //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({
  clips: () => clips,
  posts: () => posts,
  misClips: () => misClips
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
const clips = new Mongo.Collection('clips');
const posts = new Mongo.Collection('posts');
var misClips;

if (Meteor.isClient) {
  module.runSetters(misClips = new Mongo.Collection(null));
  /* eslint-disable-next-line */

  new PersistentMinimongo2(misClips, 'misClips');
}

if (Meteor.isDevelopment) {
  global.misClips = misClips;
  global.clips = clips;
  global.posts = posts;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"varios.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// common/varios.js                                                                                       //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({
  tituloAUrl: () => tituloAUrl
});
const diacriticas = {
  á: 'a',
  é: 'e',
  í: 'i',
  ó: 'o',
  ú: 'u',
  ñ: 'n',
  ç: 'c'
};

const tituloAUrl = function tituloAUrl(titulo) {
  return (titulo || '').toLowerCase().replace(/[ ]/g, '-').replace(/[áéíúóüñ]/g, function (letra) {
    return diacriticas[letra];
  }).replace(/[^a-z0-9 _.-]/g, '');
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"clip.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/clip.js                                                                                         //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 1);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 2);
let salirValidacion, salir;
module.link("/server/comun", {
  salirValidacion(v) {
    salirValidacion = v;
  },

  salir(v) {
    salir = v;
  }

}, 3);
let tituloAUrl;
module.link("/common/varios", {
  tituloAUrl(v) {
    tituloAUrl = v;
  }

}, 4);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 5);
const validaciones = {
  cambiarPrioridad: Joi.object().keys({
    clipId: Joi.string().required(),
    postId: Joi.string().required(),
    secreto: Joi.string().required(),
    prioridad: Joi.number().required()
  }),
  revocar: Joi.object().keys({
    clipId: Joi.string().required(),
    seguridad: Joi.string().required(),
    llave: Joi.string().valid(['seguridad', 'secreto']).required()
  }),
  obtenerSecreto: Joi.object().keys({
    clipId: Joi.string().required(),
    seguridad: Joi.string().required()
  }),
  establecerStatus: Joi.object().keys({
    clipId: Joi.string().required(),
    postId: Joi.string().required(),
    secreto: Joi.string().required(),
    status: Joi.string().valid(['RECHAZADO', 'OCULTO', 'VISIBLE']).required()
  }),
  eliminarPost: Joi.object().keys({
    clipId: Joi.string().required(),
    postId: Joi.string().required(),
    secreto: Joi.string().required()
  }),
  clipPublish: Joi.object().keys({
    url: Joi.string().regex(/^[a-z-]+$/).required(),
    secreto: Joi.string()
  }),
  clipIdPublish: Joi.object().keys({
    clipId: Joi.string().required(),
    secreto: Joi.string().required()
  }),
  agregarLink: Joi.object().keys({
    url: Joi.string().regex(/^[a-z-]+$/).required(),
    link: Joi.string().required(),
    OG: Joi.object().required()
  }),
  titulo: Joi.string()
};
Meteor.methods({
  crearClip(titulo) {
    salirValidacion({
      data: titulo,
      schema: validaciones.titulo,
      debug: {
        donde: 'method crearClip'
      }
    });

    if (clips.find({
      titulo
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'titulo repetido');
    }

    const url = tituloAUrl(titulo);

    if (clips.find({
      url
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'url repetida');
    }

    const secreto = Random.secret();
    const seguridad = Random.secret();
    const clipId = clips.insert({
      creacion: new Date(),
      titulo,
      url,
      secreto,
      seguridad
    });
    return {
      clipId,
      secreto,
      seguridad
    };
  },

  agregarLink(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.agregarLink,
      debug: {
        donde: 'method agregarLink'
      }
    });
    const clip = clips.findOne({
      url: opciones.url
    }) || salir(404, 'Clip no encontrado', {
      donde: 'method agregarLink'
    });

    if (posts.findOne({
      clipId: clip._id,
      link: opciones.link
    })) {
      return;
    }

    posts.insert({
      clipId: clip._id,
      OG: opciones.OG,
      link: opciones.link,
      timestamp: new Date(),
      status: 'PENDIENTE',
      prioridad: 0
    });

    if (opciones.secreto) {
      clips.update({
        _id: clip._id
      }, {
        $inc: {
          posts: 1
        }
      });
    }
  },

  cambiarPrioridad(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.cambiarPrioridad,
      debug: {
        donde: 'method cambiarPrioridad'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method establecerStatus'
    });
    clips.find({
      _id: opciones.clipId,
      secreto: opciones.secreto
    }).count() || salir(401, 'No tienes permiso para administrar el clip', {
      donde: 'method establecerStatus'
    });
    posts.find({
      _id: opciones.postId,
      clipId: opciones.clipId
    }).count() || salir(404, 'Post no encontrado');
    posts.update(opciones.postId, {
      $set: {
        prioridad: opciones.prioridad
      }
    });
  },

  testTitulo(titulo) {
    salirValidacion({
      data: titulo,
      schema: validaciones.titulo,
      debug: {
        donde: 'method testTitulo'
      }
    }); // if (clips.find({
    //   titulo
    // }, {
    //   limit: 1
    // }).count()) {
    //   console.log('titulo repetido')
    //   throw new Meteor.Error(400, 'titulo repetido')
    // }

    const url = tituloAUrl(titulo);

    if (clips.find({
      url
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'url repetida');
    }
  },

  establecerStatus(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.establecerStatus,
      debug: {
        donde: 'method establecerStatus'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method establecerStatus'
    });
    clips.find({
      _id: opciones.clipId,
      secreto: opciones.secreto
    }).count() || salir(401, 'No tienes permiso para administrar el clip', {
      donde: 'method establecerStatus'
    });
    posts.find({
      _id: opciones.postId,
      clipId: opciones.clipId
    }).count() || salir(404, 'Post no encontrado');
    posts.update(opciones.postId, {
      $set: {
        status: opciones.status
      }
    });
  },

  eliminarPost(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.eliminarPost,
      debug: {
        donde: 'method establecerStatus'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method establecerStatus'
    });
    clips.find({
      _id: opciones.clipId,
      secreto: opciones.secreto
    }).count() || salir(401, 'No tienes permiso para administrar el clip', {
      donde: 'method establecerStatus'
    });
    posts.find({
      _id: opciones.postId,
      clipId: opciones.clipId
    }).count() || salir(404, 'Post no encontrado');
    posts.remove(opciones.postId);
  },

  revocar(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.revocar,
      debug: {
        donde: 'method revocar'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method revocar'
    });
    clips.find({
      _id: opciones.clipId,
      seguridad: opciones.seguridad
    }).count() || salir(400, 'No tienes permiso para revocar llaves', {
      donde: 'method revocar'
    });
    const llave = Random.secret();
    clips.update(opciones.clipId, {
      $set: {
        [opciones.llave]: llave
      }
    });
    return llave;
  },

  obtenerSecreto(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.obtenerSecreto,
      debug: {
        donde: 'method obtenerSecreto'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method revocar'
    });
    const clip = clips.findOne({
      _id: opciones.clipId,
      seguridad: opciones.seguridad
    }) || salir(401, 'No tienes permiso para obtener la llave de administración', {
      donde: 'method revocar'
    });
    return clip.secreto;
  }

});
Meteor.publish('clip', function (opciones) {
  salirValidacion({
    data: opciones,
    schema: validaciones.clipPublish,
    debug: {
      donde: 'publish clip'
    }
  });
  const clip = clips.findOne({
    url: opciones.url
  }) || salir(404, 'Clip no encontrado', {
    donde: 'publish clip'
  });
  opciones.secreto && clip.secreto !== opciones.secreto && salir(401, 'No tienes permiso', {
    donde: 'publish clip'
  });
  const postsQuery = {
    clipId: clip._id
  };

  if (!opciones.secreto) {
    postsQuery.status = 'VISIBLE';
  }

  return [clips.find(clip._id, {
    fields: {
      seguridad: 0,
      secreto: 0
    }
  }), posts.find(postsQuery)];
});
Meteor.publish('clipId', function (opciones) {
  salirValidacion({
    data: opciones,
    schema: validaciones.clipIdPublish,
    debug: {
      donde: 'publish clipId'
    }
  });
  return clips.find({
    _id: opciones.clipId,
    secreto: opciones.secreto
  }, {
    fields: {
      seguridad: 0,
      secreto: 0
    }
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comun.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/comun.js                                                                                        //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({
  salir: () => salir,
  salirValidacion: () => salirValidacion
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 1);

const salir = function salir(codigo, mensaje, debug) {
  if (debug) {
    console.log(codigo, mensaje);
    console.log(JSON.stringify(debug, null, 2));
  }

  throw new Meteor.Error(codigo, mensaje);
};

const salirValidacion = function (opciones) {
  const validacion = Joi.validate(opciones.data, opciones.schema);

  if (!validacion.error) {
    return;
  }

  opciones = Object.assign({
    codigo: 400,
    mensaje: validacion.error.details[0].message
  }, opciones);

  if (opciones.debug) {
    opciones.debug.details = validacion.error.details;
    opciones.debug._object = validacion.error._object;
  }

  salir(opciones.codigo, opciones.mensaje, opciones.debug);
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"externo.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/externo.js                                                                                      //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
let cheerio;
module.link("cheerio", {
  default(v) {
    cheerio = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 3);
let moment;
module.link("moment", {
  default(v) {
    moment = v;
  }

}, 4);
let ogs;
module.link("open-graph-scraper", {
  default(v) {
    ogs = v;
  }

}, 5);
const meteorOGS = Meteor.wrapAsync(function (opciones, callback) {
  ogs(opciones, function (e, r, h) {
    callback(e, [r, cheerio.load(h ? h.body : opciones.html)]);
  });
});
const rrss = {
  Instagram: {
    obtenerApoyos($, response) {
      response.data.crLikes = JSON.parse($('script[type="application/ld+json"]').html()).interactionStatistic.userInteractionCount;
      response.data.ogDescription = response.data.ogTitle.replace(/^.*?on Instagram: /, '');
      response.data.ogTitle = response.data.ogTitle.replace(/on Instagram:.*$/, '');
      return response;
    }

  },
  YouTube: {
    regex: /(^|=|\/)([0-9A-Za-z_-]{11})(\/|&|$|\?|#)/,

    obtenerApoyos($, response) {
      const youtube = response.data.ogUrl.match(rrss.YouTube.regex);

      if (!youtube) {
        return response;
      }

      const data = JSON.parse(HTTP.get(`https://www.googleapis.com/youtube/v3/videos?id=${youtube[2]}&key=${Meteor.settings.private.youtubeAPI}&part=statistics`).content).items[0].statistics;
      response.data.crLikes = data.likeCount - data.dislikeCount;
      return response;
    }

  },
  Twitter: {
    obtenerApoyos($, response) {
      var stats = $('ul.stats');
      const retweeted = (stats.find('.request-retweeted-popup').data() || {
        tweetStatCount: 0
      }).tweetStatCount * 1;
      const favorited = (stats.find('.request-favorited-popup').data() || {
        tweetStatCount: 0
      }).tweetStatCount * 1;
      response.data.crLikes = retweeted + favorited;
      response.data.ogTitle = response.data.ogTitle.replace(/on Twitter$/, '');
      return response;
    }

  },
  reddit: {
    obtenerApoyos($, response) {
      response.data.crLikes = parseInt(response.data.ogDescription.replace(/ .*$/, '').replace(/,/, ''));
      response.data.ogDescription = response.data.ogTitle.replace(/^.*?- /, '');
      response.data.ogTitle = response.data.ogTitle.replace(/ - .*$/, '');
      return response;
    }

  },
  Vimeo: {
    obtenerApoyos($, response) {
      const data = JSON.parse(HTTP.get(`${response.data.ogUrl}?action=load_stat_counts`, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:67.0) Gecko/20100101 Firefox/67.0',
          'Referer': response.data.ogUrl,
          'X-Requested-With': 'XMLHttpRequest'
        }
      }).content);
      response.data.crLikes = data.total_likes.raw;
      return response;
    }

  },
  '@meneame_net': {
    obtenerApoyos($, response) {
      const votos = parseInt($('#newswrap').find('.votes').find('a').text());
      response.data.crLikes = votos || 0;
      return response;
    }

  }
};

const actualizar = function actualizar(url) {
  var response;
  var html;
  var opciones;

  if (url.match(/https:\/\/www.facebook/)) {
    opciones = {
      html: HTTP.get(url, {
        headers: {
          'User-Agent': 'FeedFetcher-Google; (+http://www.google.com/feedfetcher.html)'
        }
      }).content
    };
  } else {
    opciones = {
      url
    };
  }

  [response, html] = meteorOGS(opciones);

  if (url.match(/https:\/\/www.facebook/)) {
    response.data.ogSiteName = 'Facebook';
  }

  if (rrss[response.data.ogSiteName || response.data.twitterSite]) {
    return rrss[response.data.ogSiteName || response.data.twitterSite].obtenerApoyos(html, response);
  }

  return response;
};

Meteor.methods({
  actualizarApoyos(clipId, forzar) {
    if (!forzar && clips.findOne({
      _id: clipId,
      actualizacion: {
        $gt: moment().subtract(1, 'hour').toDate()
      }
    })) {
      return;
    }

    var apoyos = 0;
    posts.find({
      clipId,
      status: 'VISIBLE'
    }).forEach(post => {
      const response = actualizar(post.link);
      posts.update({
        _id: post._id
      }, {
        $set: {
          OG: response.data
        }
      });
      apoyos += (response.data.crLikes || 0) * 1;
    });
    clips.update({
      _id: clipId
    }, {
      $set: {
        apoyos,
        actualizacion: new Date()
      }
    });
  },

  previsualizar(url) {
    return actualizar(url);
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"listas.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/listas.js                                                                                       //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 1);
let salirValidacion;
module.link("/server/comun", {
  salirValidacion(v) {
    salirValidacion = v;
  }

}, 2);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 3);
const validaciones = {
  primerPost: Joi.string()
};
Meteor.publish('ranking', function (pagina = 0) {
  return clips.find({
    posts: {
      $gt: 0
    }
  }, {
    fields: {
      secreto: 0,
      seguridad: 0
    },
    sort: {
      apoyos: -1
    },
    skip: 10 * pagina,
    limit: 10
  });
});
Meteor.publish('busqueda', function (busqueda, pagina = 0) {
  var regex = /(?:)/;

  try {
    regex = new RegExp(busqueda);
  } catch (e) {
    regex = /$^/;
  }

  return clips.find({
    titulo: regex,
    posts: {
      $gt: 0
    }
  }, {
    fields: {
      secreto: 0,
      seguridad: 0
    },
    sort: {
      apoyos: -1
    },
    skip: 10 * pagina,
    limit: 10
  });
});
Meteor.publish('primerPost', function (clipId) {
  salirValidacion({
    data: clipId,
    schema: validaciones.primerPost,
    debug: {
      donde: 'publish clip'
    }
  });
  return posts.find({
    clipId,
    status: 'VISIBLE'
  }, {
    sort: {
      prioridad: -1,
      timestamp: -1
    },
    limit: 1
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/common/baseDeDatos.js");
require("/common/varios.js");
require("/server/clip.js");
require("/server/comun.js");
require("/server/externo.js");
require("/server/listas.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29tbW9uL2Jhc2VEZURhdG9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb21tb24vdmFyaW9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY2xpcC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbXVuLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZXh0ZXJuby5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2xpc3Rhcy5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJjbGlwcyIsInBvc3RzIiwibWlzQ2xpcHMiLCJNb25nbyIsImxpbmsiLCJ2IiwiTWV0ZW9yIiwiQ29sbGVjdGlvbiIsImlzQ2xpZW50IiwiUGVyc2lzdGVudE1pbmltb25nbzIiLCJpc0RldmVsb3BtZW50IiwiZ2xvYmFsIiwidGl0dWxvQVVybCIsImRpYWNyaXRpY2FzIiwiw6EiLCLDqSIsIsOtIiwiw7MiLCLDuiIsIsOxIiwiw6ciLCJ0aXR1bG8iLCJ0b0xvd2VyQ2FzZSIsInJlcGxhY2UiLCJsZXRyYSIsIlJhbmRvbSIsInNhbGlyVmFsaWRhY2lvbiIsInNhbGlyIiwiSm9pIiwiZGVmYXVsdCIsInZhbGlkYWNpb25lcyIsImNhbWJpYXJQcmlvcmlkYWQiLCJvYmplY3QiLCJrZXlzIiwiY2xpcElkIiwic3RyaW5nIiwicmVxdWlyZWQiLCJwb3N0SWQiLCJzZWNyZXRvIiwicHJpb3JpZGFkIiwibnVtYmVyIiwicmV2b2NhciIsInNlZ3VyaWRhZCIsImxsYXZlIiwidmFsaWQiLCJvYnRlbmVyU2VjcmV0byIsImVzdGFibGVjZXJTdGF0dXMiLCJzdGF0dXMiLCJlbGltaW5hclBvc3QiLCJjbGlwUHVibGlzaCIsInVybCIsInJlZ2V4IiwiY2xpcElkUHVibGlzaCIsImFncmVnYXJMaW5rIiwiT0ciLCJtZXRob2RzIiwiY3JlYXJDbGlwIiwiZGF0YSIsInNjaGVtYSIsImRlYnVnIiwiZG9uZGUiLCJmaW5kIiwibGltaXQiLCJjb3VudCIsIkVycm9yIiwic2VjcmV0IiwiaW5zZXJ0IiwiY3JlYWNpb24iLCJEYXRlIiwib3BjaW9uZXMiLCJjbGlwIiwiZmluZE9uZSIsIl9pZCIsInRpbWVzdGFtcCIsInVwZGF0ZSIsIiRpbmMiLCIkc2V0IiwidGVzdFRpdHVsbyIsInJlbW92ZSIsInB1Ymxpc2giLCJwb3N0c1F1ZXJ5IiwiZmllbGRzIiwiY29kaWdvIiwibWVuc2FqZSIsImNvbnNvbGUiLCJsb2ciLCJKU09OIiwic3RyaW5naWZ5IiwidmFsaWRhY2lvbiIsInZhbGlkYXRlIiwiZXJyb3IiLCJPYmplY3QiLCJhc3NpZ24iLCJkZXRhaWxzIiwibWVzc2FnZSIsIl9vYmplY3QiLCJjaGVlcmlvIiwiSFRUUCIsIm1vbWVudCIsIm9ncyIsIm1ldGVvck9HUyIsIndyYXBBc3luYyIsImNhbGxiYWNrIiwiZSIsInIiLCJoIiwibG9hZCIsImJvZHkiLCJodG1sIiwicnJzcyIsIkluc3RhZ3JhbSIsIm9idGVuZXJBcG95b3MiLCIkIiwicmVzcG9uc2UiLCJjckxpa2VzIiwicGFyc2UiLCJpbnRlcmFjdGlvblN0YXRpc3RpYyIsInVzZXJJbnRlcmFjdGlvbkNvdW50Iiwib2dEZXNjcmlwdGlvbiIsIm9nVGl0bGUiLCJZb3VUdWJlIiwieW91dHViZSIsIm9nVXJsIiwibWF0Y2giLCJnZXQiLCJzZXR0aW5ncyIsInByaXZhdGUiLCJ5b3V0dWJlQVBJIiwiY29udGVudCIsIml0ZW1zIiwic3RhdGlzdGljcyIsImxpa2VDb3VudCIsImRpc2xpa2VDb3VudCIsIlR3aXR0ZXIiLCJzdGF0cyIsInJldHdlZXRlZCIsInR3ZWV0U3RhdENvdW50IiwiZmF2b3JpdGVkIiwicmVkZGl0IiwicGFyc2VJbnQiLCJWaW1lbyIsImhlYWRlcnMiLCJ0b3RhbF9saWtlcyIsInJhdyIsInZvdG9zIiwidGV4dCIsImFjdHVhbGl6YXIiLCJvZ1NpdGVOYW1lIiwidHdpdHRlclNpdGUiLCJhY3R1YWxpemFyQXBveW9zIiwiZm9yemFyIiwiYWN0dWFsaXphY2lvbiIsIiRndCIsInN1YnRyYWN0IiwidG9EYXRlIiwiYXBveW9zIiwiZm9yRWFjaCIsInBvc3QiLCJwcmV2aXN1YWxpemFyIiwicHJpbWVyUG9zdCIsInBhZ2luYSIsInNvcnQiLCJza2lwIiwiYnVzcXVlZGEiLCJSZWdFeHAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLE9BQUssRUFBQyxNQUFJQSxLQUFYO0FBQWlCQyxPQUFLLEVBQUMsTUFBSUEsS0FBM0I7QUFBaUNDLFVBQVEsRUFBQyxNQUFJQTtBQUE5QyxDQUFkO0FBQXVFLElBQUlDLEtBQUo7QUFBVUwsTUFBTSxDQUFDTSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRCxPQUFLLENBQUNFLENBQUQsRUFBRztBQUFDRixTQUFLLEdBQUNFLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUMsTUFBSjtBQUFXUixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUd2SSxNQUFNTCxLQUFLLEdBQUcsSUFBSUcsS0FBSyxDQUFDSSxVQUFWLENBQXFCLE9BQXJCLENBQWQ7QUFDQSxNQUFNTixLQUFLLEdBQUcsSUFBSUUsS0FBSyxDQUFDSSxVQUFWLENBQXFCLE9BQXJCLENBQWQ7QUFDQSxJQUFJTCxRQUFKOztBQUVQLElBQUlJLE1BQU0sQ0FBQ0UsUUFBWCxFQUFxQjtBQUNuQixvQkFBQU4sUUFBUSxHQUFHLElBQUlDLEtBQUssQ0FBQ0ksVUFBVixDQUFxQixJQUFyQixDQUFYO0FBQ0E7O0FBQ0EsTUFBSUUsb0JBQUosQ0FBeUJQLFFBQXpCLEVBQW1DLFVBQW5DO0FBQ0Q7O0FBRUQsSUFBSUksTUFBTSxDQUFDSSxhQUFYLEVBQTBCO0FBQ3hCQyxRQUFNLENBQUNULFFBQVAsR0FBa0JBLFFBQWxCO0FBQ0FTLFFBQU0sQ0FBQ1gsS0FBUCxHQUFlQSxLQUFmO0FBQ0FXLFFBQU0sQ0FBQ1YsS0FBUCxHQUFlQSxLQUFmO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUNqQkRILE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNhLFlBQVUsRUFBQyxNQUFJQTtBQUFoQixDQUFkO0FBQUEsTUFBTUMsV0FBVyxHQUFHO0FBQ2xCQyxHQUFDLEVBQUUsR0FEZTtBQUVsQkMsR0FBQyxFQUFFLEdBRmU7QUFHbEJDLEdBQUMsRUFBRSxHQUhlO0FBSWxCQyxHQUFDLEVBQUUsR0FKZTtBQUtsQkMsR0FBQyxFQUFFLEdBTGU7QUFNbEJDLEdBQUMsRUFBRSxHQU5lO0FBT2xCQyxHQUFDLEVBQUU7QUFQZSxDQUFwQjs7QUFVTyxNQUFNUixVQUFVLEdBQUcsU0FBU0EsVUFBVCxDQUFxQlMsTUFBckIsRUFBNkI7QUFDckQsU0FBTyxDQUFDQSxNQUFNLElBQUksRUFBWCxFQUFlQyxXQUFmLEdBQTZCQyxPQUE3QixDQUFxQyxNQUFyQyxFQUE2QyxHQUE3QyxFQUFrREEsT0FBbEQsQ0FBMEQsWUFBMUQsRUFBd0UsVUFBVUMsS0FBVixFQUFpQjtBQUM5RixXQUFPWCxXQUFXLENBQUNXLEtBQUQsQ0FBbEI7QUFDRCxHQUZNLEVBRUpELE9BRkksQ0FFSSxnQkFGSixFQUVzQixFQUZ0QixDQUFQO0FBR0QsQ0FKTSxDOzs7Ozs7Ozs7OztBQ1ZQLElBQUlqQixNQUFKO0FBQVdSLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlvQixNQUFKO0FBQVczQixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNxQixRQUFNLENBQUNwQixDQUFELEVBQUc7QUFBQ29CLFVBQU0sR0FBQ3BCLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUwsS0FBSixFQUFVQyxLQUFWO0FBQWdCSCxNQUFNLENBQUNNLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDSixPQUFLLENBQUNLLENBQUQsRUFBRztBQUFDTCxTQUFLLEdBQUNLLENBQU47QUFBUSxHQUFsQjs7QUFBbUJKLE9BQUssQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNKLFNBQUssR0FBQ0ksQ0FBTjtBQUFROztBQUFwQyxDQUFsQyxFQUF3RSxDQUF4RTtBQUEyRSxJQUFJcUIsZUFBSixFQUFvQkMsS0FBcEI7QUFBMEI3QixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNzQixpQkFBZSxDQUFDckIsQ0FBRCxFQUFHO0FBQUNxQixtQkFBZSxHQUFDckIsQ0FBaEI7QUFBa0IsR0FBdEM7O0FBQXVDc0IsT0FBSyxDQUFDdEIsQ0FBRCxFQUFHO0FBQUNzQixTQUFLLEdBQUN0QixDQUFOO0FBQVE7O0FBQXhELENBQTVCLEVBQXNGLENBQXRGO0FBQXlGLElBQUlPLFVBQUo7QUFBZWQsTUFBTSxDQUFDTSxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ1EsWUFBVSxDQUFDUCxDQUFELEVBQUc7QUFBQ08sY0FBVSxHQUFDUCxDQUFYO0FBQWE7O0FBQTVCLENBQTdCLEVBQTJELENBQTNEO0FBQThELElBQUl1QixHQUFKO0FBQVE5QixNQUFNLENBQUNNLElBQVAsQ0FBWSxLQUFaLEVBQWtCO0FBQUN5QixTQUFPLENBQUN4QixDQUFELEVBQUc7QUFBQ3VCLE9BQUcsR0FBQ3ZCLENBQUo7QUFBTTs7QUFBbEIsQ0FBbEIsRUFBc0MsQ0FBdEM7QUFRbmEsTUFBTXlCLFlBQVksR0FBRztBQUNuQkMsa0JBQWdCLEVBQUVILEdBQUcsQ0FBQ0ksTUFBSixHQUFhQyxJQUFiLENBQWtCO0FBQ2xDQyxVQUFNLEVBQUVOLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRDBCO0FBRWxDQyxVQUFNLEVBQUVULEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRjBCO0FBR2xDRSxXQUFPLEVBQUVWLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBSHlCO0FBSWxDRyxhQUFTLEVBQUVYLEdBQUcsQ0FBQ1ksTUFBSixHQUFhSixRQUFiO0FBSnVCLEdBQWxCLENBREM7QUFPbkJLLFNBQU8sRUFBRWIsR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDekJDLFVBQU0sRUFBRU4sR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFEaUI7QUFFekJNLGFBQVMsRUFBRWQsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFGYztBQUd6Qk8sU0FBSyxFQUFFZixHQUFHLENBQUNPLE1BQUosR0FBYVMsS0FBYixDQUFtQixDQUFDLFdBQUQsRUFBYyxTQUFkLENBQW5CLEVBQTZDUixRQUE3QztBQUhrQixHQUFsQixDQVBVO0FBWW5CUyxnQkFBYyxFQUFFakIsR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDaENDLFVBQU0sRUFBRU4sR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFEd0I7QUFFaENNLGFBQVMsRUFBRWQsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWI7QUFGcUIsR0FBbEIsQ0FaRztBQWdCbkJVLGtCQUFnQixFQUFFbEIsR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDbENDLFVBQU0sRUFBRU4sR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFEMEI7QUFFbENDLFVBQU0sRUFBRVQsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFGMEI7QUFHbENFLFdBQU8sRUFBRVYsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFIeUI7QUFJbENXLFVBQU0sRUFBRW5CLEdBQUcsQ0FBQ08sTUFBSixHQUFhUyxLQUFiLENBQW1CLENBQUMsV0FBRCxFQUFjLFFBQWQsRUFBd0IsU0FBeEIsQ0FBbkIsRUFBdURSLFFBQXZEO0FBSjBCLEdBQWxCLENBaEJDO0FBc0JuQlksY0FBWSxFQUFFcEIsR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDOUJDLFVBQU0sRUFBRU4sR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFEc0I7QUFFOUJDLFVBQU0sRUFBRVQsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFGc0I7QUFHOUJFLFdBQU8sRUFBRVYsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWI7QUFIcUIsR0FBbEIsQ0F0Qks7QUEyQm5CYSxhQUFXLEVBQUVyQixHQUFHLENBQUNJLE1BQUosR0FBYUMsSUFBYixDQUFrQjtBQUM3QmlCLE9BQUcsRUFBRXRCLEdBQUcsQ0FBQ08sTUFBSixHQUFhZ0IsS0FBYixDQUFtQixXQUFuQixFQUFnQ2YsUUFBaEMsRUFEd0I7QUFFN0JFLFdBQU8sRUFBRVYsR0FBRyxDQUFDTyxNQUFKO0FBRm9CLEdBQWxCLENBM0JNO0FBK0JuQmlCLGVBQWEsRUFBRXhCLEdBQUcsQ0FBQ0ksTUFBSixHQUFhQyxJQUFiLENBQWtCO0FBQy9CQyxVQUFNLEVBQUVOLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRHVCO0FBRS9CRSxXQUFPLEVBQUVWLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiO0FBRnNCLEdBQWxCLENBL0JJO0FBbUNuQmlCLGFBQVcsRUFBRXpCLEdBQUcsQ0FBQ0ksTUFBSixHQUFhQyxJQUFiLENBQWtCO0FBQzdCaUIsT0FBRyxFQUFFdEIsR0FBRyxDQUFDTyxNQUFKLEdBQWFnQixLQUFiLENBQW1CLFdBQW5CLEVBQWdDZixRQUFoQyxFQUR3QjtBQUU3QmhDLFFBQUksRUFBRXdCLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRnVCO0FBRzdCa0IsTUFBRSxFQUFFMUIsR0FBRyxDQUFDSSxNQUFKLEdBQWFJLFFBQWI7QUFIeUIsR0FBbEIsQ0FuQ007QUF3Q25CZixRQUFNLEVBQUVPLEdBQUcsQ0FBQ08sTUFBSjtBQXhDVyxDQUFyQjtBQTJDQTdCLE1BQU0sQ0FBQ2lELE9BQVAsQ0FBZTtBQUNiQyxXQUFTLENBQUVuQyxNQUFGLEVBQVU7QUFDakJLLG1CQUFlLENBQUM7QUFDZCtCLFVBQUksRUFBRXBDLE1BRFE7QUFFZHFDLFlBQU0sRUFBRTVCLFlBQVksQ0FBQ1QsTUFGUDtBQUdkc0MsV0FBSyxFQUFFO0FBQ0xDLGFBQUssRUFBRTtBQURGO0FBSE8sS0FBRCxDQUFmOztBQVFBLFFBQUk1RCxLQUFLLENBQUM2RCxJQUFOLENBQVc7QUFDYnhDO0FBRGEsS0FBWCxFQUVEO0FBQ0R5QyxXQUFLLEVBQUU7QUFETixLQUZDLEVBSURDLEtBSkMsRUFBSixFQUlZO0FBQ1YsWUFBTSxJQUFJekQsTUFBTSxDQUFDMEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixpQkFBdEIsQ0FBTjtBQUNEOztBQUNELFVBQU1kLEdBQUcsR0FBR3RDLFVBQVUsQ0FBQ1MsTUFBRCxDQUF0Qjs7QUFDQSxRQUFJckIsS0FBSyxDQUFDNkQsSUFBTixDQUFXO0FBQ2JYO0FBRGEsS0FBWCxFQUVEO0FBQ0RZLFdBQUssRUFBRTtBQUROLEtBRkMsRUFJREMsS0FKQyxFQUFKLEVBSVk7QUFDVixZQUFNLElBQUl6RCxNQUFNLENBQUMwRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGNBQXRCLENBQU47QUFDRDs7QUFFRCxVQUFNMUIsT0FBTyxHQUFHYixNQUFNLENBQUN3QyxNQUFQLEVBQWhCO0FBQ0EsVUFBTXZCLFNBQVMsR0FBR2pCLE1BQU0sQ0FBQ3dDLE1BQVAsRUFBbEI7QUFDQSxVQUFNL0IsTUFBTSxHQUFHbEMsS0FBSyxDQUFDa0UsTUFBTixDQUFhO0FBQzFCQyxjQUFRLEVBQUUsSUFBSUMsSUFBSixFQURnQjtBQUUxQi9DLFlBRjBCO0FBRzFCNkIsU0FIMEI7QUFJMUJaLGFBSjBCO0FBSzFCSTtBQUwwQixLQUFiLENBQWY7QUFRQSxXQUFPO0FBQ0xSLFlBREs7QUFFTEksYUFGSztBQUdMSTtBQUhLLEtBQVA7QUFLRCxHQXpDWTs7QUEwQ2JXLGFBQVcsQ0FBRWdCLFFBQUYsRUFBWTtBQUNyQjNDLG1CQUFlLENBQUM7QUFDZCtCLFVBQUksRUFBRVksUUFEUTtBQUVkWCxZQUFNLEVBQUU1QixZQUFZLENBQUN1QixXQUZQO0FBR2RNLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZjtBQU9BLFVBQU1VLElBQUksR0FBR3RFLEtBQUssQ0FBQ3VFLE9BQU4sQ0FBYztBQUN6QnJCLFNBQUcsRUFBRW1CLFFBQVEsQ0FBQ25CO0FBRFcsS0FBZCxLQUVQdkIsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixFQUE0QjtBQUNyQ2lDLFdBQUssRUFBRTtBQUQ4QixLQUE1QixDQUZYOztBQU1BLFFBQUkzRCxLQUFLLENBQUNzRSxPQUFOLENBQWM7QUFDaEJyQyxZQUFNLEVBQUVvQyxJQUFJLENBQUNFLEdBREc7QUFFaEJwRSxVQUFJLEVBQUVpRSxRQUFRLENBQUNqRTtBQUZDLEtBQWQsQ0FBSixFQUdJO0FBQ0Y7QUFDRDs7QUFDREgsU0FBSyxDQUFDaUUsTUFBTixDQUFhO0FBQ1hoQyxZQUFNLEVBQUVvQyxJQUFJLENBQUNFLEdBREY7QUFFWGxCLFFBQUUsRUFBRWUsUUFBUSxDQUFDZixFQUZGO0FBR1hsRCxVQUFJLEVBQUVpRSxRQUFRLENBQUNqRSxJQUhKO0FBSVhxRSxlQUFTLEVBQUUsSUFBSUwsSUFBSixFQUpBO0FBS1hyQixZQUFNLEVBQUUsV0FMRztBQU1YUixlQUFTLEVBQUU7QUFOQSxLQUFiOztBQVFBLFFBQUk4QixRQUFRLENBQUMvQixPQUFiLEVBQXNCO0FBQ3BCdEMsV0FBSyxDQUFDMEUsTUFBTixDQUFhO0FBQ1hGLFdBQUcsRUFBRUYsSUFBSSxDQUFDRTtBQURDLE9BQWIsRUFFRztBQUNERyxZQUFJLEVBQUU7QUFDSjFFLGVBQUssRUFBRTtBQURIO0FBREwsT0FGSDtBQU9EO0FBQ0YsR0EvRVk7O0FBZ0ZiOEIsa0JBQWdCLENBQUVzQyxRQUFGLEVBQVk7QUFDMUIzQyxtQkFBZSxDQUFDO0FBQ2QrQixVQUFJLEVBQUVZLFFBRFE7QUFFZFgsWUFBTSxFQUFFNUIsWUFBWSxDQUFDQyxnQkFGUDtBQUdkNEIsV0FBSyxFQUFFO0FBQ0xDLGFBQUssRUFBRTtBQURGO0FBSE8sS0FBRCxDQUFmO0FBT0E1RCxTQUFLLENBQUM2RCxJQUFOLENBQVc7QUFDVFcsU0FBRyxFQUFFSCxRQUFRLENBQUNuQztBQURMLEtBQVgsRUFFRzZCLEtBRkgsTUFFY3BDLEtBQUssQ0FBQyxHQUFELEVBQU0sb0JBQU4sRUFBNEI7QUFDN0NpQyxXQUFLLEVBQUU7QUFEc0MsS0FBNUIsQ0FGbkI7QUFNQTVELFNBQUssQ0FBQzZELElBQU4sQ0FBVztBQUNUVyxTQUFHLEVBQUVILFFBQVEsQ0FBQ25DLE1BREw7QUFFVEksYUFBTyxFQUFFK0IsUUFBUSxDQUFDL0I7QUFGVCxLQUFYLEVBR0d5QixLQUhILE1BR2NwQyxLQUFLLENBQUMsR0FBRCxFQUFNLDRDQUFOLEVBQW9EO0FBQ3JFaUMsV0FBSyxFQUFFO0FBRDhELEtBQXBELENBSG5CO0FBT0EzRCxTQUFLLENBQUM0RCxJQUFOLENBQVc7QUFDVFcsU0FBRyxFQUFFSCxRQUFRLENBQUNoQyxNQURMO0FBRVRILFlBQU0sRUFBRW1DLFFBQVEsQ0FBQ25DO0FBRlIsS0FBWCxFQUdHNkIsS0FISCxNQUdjcEMsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixDQUhuQjtBQUtBMUIsU0FBSyxDQUFDeUUsTUFBTixDQUFhTCxRQUFRLENBQUNoQyxNQUF0QixFQUE4QjtBQUM1QnVDLFVBQUksRUFBRTtBQUNKckMsaUJBQVMsRUFBRThCLFFBQVEsQ0FBQzlCO0FBRGhCO0FBRHNCLEtBQTlCO0FBS0QsR0EvR1k7O0FBZ0hic0MsWUFBVSxDQUFFeEQsTUFBRixFQUFVO0FBQ2xCSyxtQkFBZSxDQUFDO0FBQ2QrQixVQUFJLEVBQUVwQyxNQURRO0FBRWRxQyxZQUFNLEVBQUU1QixZQUFZLENBQUNULE1BRlA7QUFHZHNDLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZixDQURrQixDQVFsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFVBQU1WLEdBQUcsR0FBR3RDLFVBQVUsQ0FBQ1MsTUFBRCxDQUF0Qjs7QUFDQSxRQUFJckIsS0FBSyxDQUFDNkQsSUFBTixDQUFXO0FBQ2JYO0FBRGEsS0FBWCxFQUVEO0FBQ0RZLFdBQUssRUFBRTtBQUROLEtBRkMsRUFJREMsS0FKQyxFQUFKLEVBSVk7QUFDVixZQUFNLElBQUl6RCxNQUFNLENBQUMwRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGNBQXRCLENBQU47QUFDRDtBQUNGLEdBeElZOztBQXlJYmxCLGtCQUFnQixDQUFFdUIsUUFBRixFQUFZO0FBQzFCM0MsbUJBQWUsQ0FBQztBQUNkK0IsVUFBSSxFQUFFWSxRQURRO0FBRWRYLFlBQU0sRUFBRTVCLFlBQVksQ0FBQ2dCLGdCQUZQO0FBR2RhLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZjtBQVFBNUQsU0FBSyxDQUFDNkQsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDbkM7QUFETCxLQUFYLEVBRUc2QixLQUZILE1BRWNwQyxLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLEVBQTRCO0FBQzdDaUMsV0FBSyxFQUFFO0FBRHNDLEtBQTVCLENBRm5CO0FBTUE1RCxTQUFLLENBQUM2RCxJQUFOLENBQVc7QUFDVFcsU0FBRyxFQUFFSCxRQUFRLENBQUNuQyxNQURMO0FBRVRJLGFBQU8sRUFBRStCLFFBQVEsQ0FBQy9CO0FBRlQsS0FBWCxFQUdHeUIsS0FISCxNQUdjcEMsS0FBSyxDQUFDLEdBQUQsRUFBTSw0Q0FBTixFQUFvRDtBQUNyRWlDLFdBQUssRUFBRTtBQUQ4RCxLQUFwRCxDQUhuQjtBQU9BM0QsU0FBSyxDQUFDNEQsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDaEMsTUFETDtBQUVUSCxZQUFNLEVBQUVtQyxRQUFRLENBQUNuQztBQUZSLEtBQVgsRUFHRzZCLEtBSEgsTUFHY3BDLEtBQUssQ0FBQyxHQUFELEVBQU0sb0JBQU4sQ0FIbkI7QUFLQTFCLFNBQUssQ0FBQ3lFLE1BQU4sQ0FBYUwsUUFBUSxDQUFDaEMsTUFBdEIsRUFBOEI7QUFDNUJ1QyxVQUFJLEVBQUU7QUFDSjdCLGNBQU0sRUFBRXNCLFFBQVEsQ0FBQ3RCO0FBRGI7QUFEc0IsS0FBOUI7QUFLRCxHQXpLWTs7QUEwS2JDLGNBQVksQ0FBRXFCLFFBQUYsRUFBWTtBQUN0QjNDLG1CQUFlLENBQUM7QUFDZCtCLFVBQUksRUFBRVksUUFEUTtBQUVkWCxZQUFNLEVBQUU1QixZQUFZLENBQUNrQixZQUZQO0FBR2RXLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZjtBQVFBNUQsU0FBSyxDQUFDNkQsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDbkM7QUFETCxLQUFYLEVBRUc2QixLQUZILE1BRWNwQyxLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLEVBQTRCO0FBQzdDaUMsV0FBSyxFQUFFO0FBRHNDLEtBQTVCLENBRm5CO0FBTUE1RCxTQUFLLENBQUM2RCxJQUFOLENBQVc7QUFDVFcsU0FBRyxFQUFFSCxRQUFRLENBQUNuQyxNQURMO0FBRVRJLGFBQU8sRUFBRStCLFFBQVEsQ0FBQy9CO0FBRlQsS0FBWCxFQUdHeUIsS0FISCxNQUdjcEMsS0FBSyxDQUFDLEdBQUQsRUFBTSw0Q0FBTixFQUFvRDtBQUNyRWlDLFdBQUssRUFBRTtBQUQ4RCxLQUFwRCxDQUhuQjtBQU9BM0QsU0FBSyxDQUFDNEQsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDaEMsTUFETDtBQUVUSCxZQUFNLEVBQUVtQyxRQUFRLENBQUNuQztBQUZSLEtBQVgsRUFHRzZCLEtBSEgsTUFHY3BDLEtBQUssQ0FBQyxHQUFELEVBQU0sb0JBQU4sQ0FIbkI7QUFLQTFCLFNBQUssQ0FBQzZFLE1BQU4sQ0FBYVQsUUFBUSxDQUFDaEMsTUFBdEI7QUFDRCxHQXRNWTs7QUF1TWJJLFNBQU8sQ0FBRTRCLFFBQUYsRUFBWTtBQUNqQjNDLG1CQUFlLENBQUM7QUFDZCtCLFVBQUksRUFBRVksUUFEUTtBQUVkWCxZQUFNLEVBQUU1QixZQUFZLENBQUNXLE9BRlA7QUFHZGtCLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZjtBQVFBNUQsU0FBSyxDQUFDNkQsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDbkM7QUFETCxLQUFYLEVBRUc2QixLQUZILE1BRWNwQyxLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLEVBQTRCO0FBQzdDaUMsV0FBSyxFQUFFO0FBRHNDLEtBQTVCLENBRm5CO0FBTUE1RCxTQUFLLENBQUM2RCxJQUFOLENBQVc7QUFDVFcsU0FBRyxFQUFFSCxRQUFRLENBQUNuQyxNQURMO0FBRVRRLGVBQVMsRUFBRTJCLFFBQVEsQ0FBQzNCO0FBRlgsS0FBWCxFQUdHcUIsS0FISCxNQUdjcEMsS0FBSyxDQUFDLEdBQUQsRUFBTSx1Q0FBTixFQUErQztBQUNoRWlDLFdBQUssRUFBRTtBQUR5RCxLQUEvQyxDQUhuQjtBQU9BLFVBQU1qQixLQUFLLEdBQUdsQixNQUFNLENBQUN3QyxNQUFQLEVBQWQ7QUFFQWpFLFNBQUssQ0FBQzBFLE1BQU4sQ0FBYUwsUUFBUSxDQUFDbkMsTUFBdEIsRUFBOEI7QUFDNUIwQyxVQUFJLEVBQUU7QUFDSixTQUFDUCxRQUFRLENBQUMxQixLQUFWLEdBQWtCQTtBQURkO0FBRHNCLEtBQTlCO0FBS0EsV0FBT0EsS0FBUDtBQUNELEdBck9ZOztBQXNPYkUsZ0JBQWMsQ0FBRXdCLFFBQUYsRUFBWTtBQUN4QjNDLG1CQUFlLENBQUM7QUFDZCtCLFVBQUksRUFBRVksUUFEUTtBQUVkWCxZQUFNLEVBQUU1QixZQUFZLENBQUNlLGNBRlA7QUFHZGMsV0FBSyxFQUFFO0FBQ0xDLGFBQUssRUFBRTtBQURGO0FBSE8sS0FBRCxDQUFmO0FBUUE1RCxTQUFLLENBQUM2RCxJQUFOLENBQVc7QUFDVFcsU0FBRyxFQUFFSCxRQUFRLENBQUNuQztBQURMLEtBQVgsRUFFRzZCLEtBRkgsTUFFY3BDLEtBQUssQ0FBQyxHQUFELEVBQU0sb0JBQU4sRUFBNEI7QUFDN0NpQyxXQUFLLEVBQUU7QUFEc0MsS0FBNUIsQ0FGbkI7QUFNQSxVQUFNVSxJQUFJLEdBQUd0RSxLQUFLLENBQUN1RSxPQUFOLENBQWM7QUFDekJDLFNBQUcsRUFBRUgsUUFBUSxDQUFDbkMsTUFEVztBQUV6QlEsZUFBUyxFQUFFMkIsUUFBUSxDQUFDM0I7QUFGSyxLQUFkLEtBR1BmLEtBQUssQ0FBQyxHQUFELEVBQU0sMkRBQU4sRUFBbUU7QUFDNUVpQyxXQUFLLEVBQUU7QUFEcUUsS0FBbkUsQ0FIWDtBQU9BLFdBQU9VLElBQUksQ0FBQ2hDLE9BQVo7QUFDRDs7QUE3UFksQ0FBZjtBQWdRQWhDLE1BQU0sQ0FBQ3lFLE9BQVAsQ0FBZSxNQUFmLEVBQXVCLFVBQVVWLFFBQVYsRUFBb0I7QUFDekMzQyxpQkFBZSxDQUFDO0FBQ2QrQixRQUFJLEVBQUVZLFFBRFE7QUFFZFgsVUFBTSxFQUFFNUIsWUFBWSxDQUFDbUIsV0FGUDtBQUdkVSxTQUFLLEVBQUU7QUFDTEMsV0FBSyxFQUFFO0FBREY7QUFITyxHQUFELENBQWY7QUFPQSxRQUFNVSxJQUFJLEdBQUd0RSxLQUFLLENBQUN1RSxPQUFOLENBQWM7QUFDekJyQixPQUFHLEVBQUVtQixRQUFRLENBQUNuQjtBQURXLEdBQWQsS0FFUHZCLEtBQUssQ0FBQyxHQUFELEVBQU0sb0JBQU4sRUFBNEI7QUFDckNpQyxTQUFLLEVBQUU7QUFEOEIsR0FBNUIsQ0FGWDtBQU1BUyxVQUFRLENBQUMvQixPQUFULElBQW9CZ0MsSUFBSSxDQUFDaEMsT0FBTCxLQUFpQitCLFFBQVEsQ0FBQy9CLE9BQTlDLElBQXlEWCxLQUFLLENBQUMsR0FBRCxFQUFNLG1CQUFOLEVBQTJCO0FBQ3ZGaUMsU0FBSyxFQUFFO0FBRGdGLEdBQTNCLENBQTlEO0FBSUEsUUFBTW9CLFVBQVUsR0FBRztBQUNqQjlDLFVBQU0sRUFBRW9DLElBQUksQ0FBQ0U7QUFESSxHQUFuQjs7QUFJQSxNQUFJLENBQUNILFFBQVEsQ0FBQy9CLE9BQWQsRUFBdUI7QUFDckIwQyxjQUFVLENBQUNqQyxNQUFYLEdBQW9CLFNBQXBCO0FBQ0Q7O0FBRUQsU0FBTyxDQUNML0MsS0FBSyxDQUFDNkQsSUFBTixDQUFXUyxJQUFJLENBQUNFLEdBQWhCLEVBQXFCO0FBQ25CUyxVQUFNLEVBQUU7QUFDTnZDLGVBQVMsRUFBRSxDQURMO0FBRU5KLGFBQU8sRUFBRTtBQUZIO0FBRFcsR0FBckIsQ0FESyxFQU9MckMsS0FBSyxDQUFDNEQsSUFBTixDQUFXbUIsVUFBWCxDQVBLLENBQVA7QUFTRCxDQW5DRDtBQW9DQTFFLE1BQU0sQ0FBQ3lFLE9BQVAsQ0FBZSxRQUFmLEVBQXlCLFVBQVVWLFFBQVYsRUFBb0I7QUFDM0MzQyxpQkFBZSxDQUFDO0FBQ2QrQixRQUFJLEVBQUVZLFFBRFE7QUFFZFgsVUFBTSxFQUFFNUIsWUFBWSxDQUFDc0IsYUFGUDtBQUdkTyxTQUFLLEVBQUU7QUFDTEMsV0FBSyxFQUFFO0FBREY7QUFITyxHQUFELENBQWY7QUFRQSxTQUFPNUQsS0FBSyxDQUFDNkQsSUFBTixDQUFXO0FBQ2hCVyxPQUFHLEVBQUVILFFBQVEsQ0FBQ25DLE1BREU7QUFFaEJJLFdBQU8sRUFBRStCLFFBQVEsQ0FBQy9CO0FBRkYsR0FBWCxFQUdKO0FBQ0QyQyxVQUFNLEVBQUU7QUFDTnZDLGVBQVMsRUFBRSxDQURMO0FBRU5KLGFBQU8sRUFBRTtBQUZIO0FBRFAsR0FISSxDQUFQO0FBU0QsQ0FsQkQsRTs7Ozs7Ozs7Ozs7QUN2VkF4QyxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDNEIsT0FBSyxFQUFDLE1BQUlBLEtBQVg7QUFBaUJELGlCQUFlLEVBQUMsTUFBSUE7QUFBckMsQ0FBZDtBQUFxRSxJQUFJcEIsTUFBSjtBQUFXUixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJdUIsR0FBSjtBQUFROUIsTUFBTSxDQUFDTSxJQUFQLENBQVksS0FBWixFQUFrQjtBQUFDeUIsU0FBTyxDQUFDeEIsQ0FBRCxFQUFHO0FBQUN1QixPQUFHLEdBQUN2QixDQUFKO0FBQU07O0FBQWxCLENBQWxCLEVBQXNDLENBQXRDOztBQUd0SSxNQUFNc0IsS0FBSyxHQUFHLFNBQVNBLEtBQVQsQ0FBZ0J1RCxNQUFoQixFQUF3QkMsT0FBeEIsRUFBaUN4QixLQUFqQyxFQUF3QztBQUMzRCxNQUFJQSxLQUFKLEVBQVc7QUFDVHlCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSCxNQUFaLEVBQW9CQyxPQUFwQjtBQUNBQyxXQUFPLENBQUNDLEdBQVIsQ0FBWUMsSUFBSSxDQUFDQyxTQUFMLENBQWU1QixLQUFmLEVBQXNCLElBQXRCLEVBQTRCLENBQTVCLENBQVo7QUFDRDs7QUFDRCxRQUFNLElBQUlyRCxNQUFNLENBQUMwRCxLQUFYLENBQWlCa0IsTUFBakIsRUFBeUJDLE9BQXpCLENBQU47QUFDRCxDQU5NOztBQVFBLE1BQU16RCxlQUFlLEdBQUcsVUFBVTJDLFFBQVYsRUFBb0I7QUFDakQsUUFBTW1CLFVBQVUsR0FBRzVELEdBQUcsQ0FBQzZELFFBQUosQ0FBYXBCLFFBQVEsQ0FBQ1osSUFBdEIsRUFBNEJZLFFBQVEsQ0FBQ1gsTUFBckMsQ0FBbkI7O0FBQ0EsTUFBSSxDQUFDOEIsVUFBVSxDQUFDRSxLQUFoQixFQUF1QjtBQUNyQjtBQUNEOztBQUNEckIsVUFBUSxHQUFHc0IsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFDdkJWLFVBQU0sRUFBRSxHQURlO0FBRXZCQyxXQUFPLEVBQUVLLFVBQVUsQ0FBQ0UsS0FBWCxDQUFpQkcsT0FBakIsQ0FBeUIsQ0FBekIsRUFBNEJDO0FBRmQsR0FBZCxFQUdSekIsUUFIUSxDQUFYOztBQUlBLE1BQUlBLFFBQVEsQ0FBQ1YsS0FBYixFQUFvQjtBQUNsQlUsWUFBUSxDQUFDVixLQUFULENBQWVrQyxPQUFmLEdBQXlCTCxVQUFVLENBQUNFLEtBQVgsQ0FBaUJHLE9BQTFDO0FBQ0F4QixZQUFRLENBQUNWLEtBQVQsQ0FBZW9DLE9BQWYsR0FBeUJQLFVBQVUsQ0FBQ0UsS0FBWCxDQUFpQkssT0FBMUM7QUFDRDs7QUFDRHBFLE9BQUssQ0FBQzBDLFFBQVEsQ0FBQ2EsTUFBVixFQUFrQmIsUUFBUSxDQUFDYyxPQUEzQixFQUFvQ2QsUUFBUSxDQUFDVixLQUE3QyxDQUFMO0FBQ0QsQ0FkTSxDOzs7Ozs7Ozs7OztBQ1hQLElBQUlxQyxPQUFKO0FBQVlsRyxNQUFNLENBQUNNLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUN5QixTQUFPLENBQUN4QixDQUFELEVBQUc7QUFBQzJGLFdBQU8sR0FBQzNGLENBQVI7QUFBVTs7QUFBdEIsQ0FBdEIsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSTRGLElBQUo7QUFBU25HLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQzZGLE1BQUksQ0FBQzVGLENBQUQsRUFBRztBQUFDNEYsUUFBSSxHQUFDNUYsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJQyxNQUFKO0FBQVdSLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlMLEtBQUosRUFBVUMsS0FBVjtBQUFnQkgsTUFBTSxDQUFDTSxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ0osT0FBSyxDQUFDSyxDQUFELEVBQUc7QUFBQ0wsU0FBSyxHQUFDSyxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CSixPQUFLLENBQUNJLENBQUQsRUFBRztBQUFDSixTQUFLLEdBQUNJLENBQU47QUFBUTs7QUFBcEMsQ0FBbEMsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSTZGLE1BQUo7QUFBV3BHLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ3lCLFNBQU8sQ0FBQ3hCLENBQUQsRUFBRztBQUFDNkYsVUFBTSxHQUFDN0YsQ0FBUDtBQUFTOztBQUFyQixDQUFyQixFQUE0QyxDQUE1QztBQUErQyxJQUFJOEYsR0FBSjtBQUFRckcsTUFBTSxDQUFDTSxJQUFQLENBQVksb0JBQVosRUFBaUM7QUFBQ3lCLFNBQU8sQ0FBQ3hCLENBQUQsRUFBRztBQUFDOEYsT0FBRyxHQUFDOUYsQ0FBSjtBQUFNOztBQUFsQixDQUFqQyxFQUFxRCxDQUFyRDtBQU9sVixNQUFNK0YsU0FBUyxHQUFHOUYsTUFBTSxDQUFDK0YsU0FBUCxDQUFpQixVQUFVaEMsUUFBVixFQUFvQmlDLFFBQXBCLEVBQThCO0FBQy9ESCxLQUFHLENBQUM5QixRQUFELEVBQVcsVUFBVWtDLENBQVYsRUFBYUMsQ0FBYixFQUFnQkMsQ0FBaEIsRUFBbUI7QUFDL0JILFlBQVEsQ0FBQ0MsQ0FBRCxFQUFJLENBQUNDLENBQUQsRUFBSVIsT0FBTyxDQUFDVSxJQUFSLENBQWFELENBQUMsR0FBR0EsQ0FBQyxDQUFDRSxJQUFMLEdBQVl0QyxRQUFRLENBQUN1QyxJQUFuQyxDQUFKLENBQUosQ0FBUjtBQUNELEdBRkUsQ0FBSDtBQUdELENBSmlCLENBQWxCO0FBTUEsTUFBTUMsSUFBSSxHQUFHO0FBQ1hDLFdBQVMsRUFBRTtBQUNUQyxpQkFBYSxDQUFFQyxDQUFGLEVBQUtDLFFBQUwsRUFBZTtBQUMxQkEsY0FBUSxDQUFDeEQsSUFBVCxDQUFjeUQsT0FBZCxHQUF3QjVCLElBQUksQ0FBQzZCLEtBQUwsQ0FBV0gsQ0FBQyxDQUFDLG9DQUFELENBQUQsQ0FBd0NKLElBQXhDLEVBQVgsRUFBMkRRLG9CQUEzRCxDQUFnRkMsb0JBQXhHO0FBQ0FKLGNBQVEsQ0FBQ3hELElBQVQsQ0FBYzZELGFBQWQsR0FBOEJMLFFBQVEsQ0FBQ3hELElBQVQsQ0FBYzhELE9BQWQsQ0FBc0JoRyxPQUF0QixDQUE4QixvQkFBOUIsRUFBb0QsRUFBcEQsQ0FBOUI7QUFDQTBGLGNBQVEsQ0FBQ3hELElBQVQsQ0FBYzhELE9BQWQsR0FBd0JOLFFBQVEsQ0FBQ3hELElBQVQsQ0FBYzhELE9BQWQsQ0FBc0JoRyxPQUF0QixDQUE4QixrQkFBOUIsRUFBa0QsRUFBbEQsQ0FBeEI7QUFDQSxhQUFPMEYsUUFBUDtBQUNEOztBQU5RLEdBREE7QUFTWE8sU0FBTyxFQUFFO0FBQ1ByRSxTQUFLLEVBQUUsMENBREE7O0FBRVA0RCxpQkFBYSxDQUFFQyxDQUFGLEVBQUtDLFFBQUwsRUFBZTtBQUMxQixZQUFNUSxPQUFPLEdBQUdSLFFBQVEsQ0FBQ3hELElBQVQsQ0FBY2lFLEtBQWQsQ0FBb0JDLEtBQXBCLENBQTBCZCxJQUFJLENBQUNXLE9BQUwsQ0FBYXJFLEtBQXZDLENBQWhCOztBQUNBLFVBQUksQ0FBQ3NFLE9BQUwsRUFBYztBQUNaLGVBQU9SLFFBQVA7QUFDRDs7QUFDRCxZQUFNeEQsSUFBSSxHQUFHNkIsSUFBSSxDQUFDNkIsS0FBTCxDQUFXbEIsSUFBSSxDQUFDMkIsR0FBTCxDQUFVLG1EQUFrREgsT0FBTyxDQUFDLENBQUQsQ0FBSSxRQUFPbkgsTUFBTSxDQUFDdUgsUUFBUCxDQUFnQkMsT0FBaEIsQ0FBd0JDLFVBQVcsa0JBQWpILEVBQW9JQyxPQUEvSSxFQUF3SkMsS0FBeEosQ0FBOEosQ0FBOUosRUFBaUtDLFVBQTlLO0FBRUFqQixjQUFRLENBQUN4RCxJQUFULENBQWN5RCxPQUFkLEdBQXdCekQsSUFBSSxDQUFDMEUsU0FBTCxHQUFpQjFFLElBQUksQ0FBQzJFLFlBQTlDO0FBQ0EsYUFBT25CLFFBQVA7QUFDRDs7QUFYTSxHQVRFO0FBc0JYb0IsU0FBTyxFQUFFO0FBQ1B0QixpQkFBYSxDQUFFQyxDQUFGLEVBQUtDLFFBQUwsRUFBZTtBQUMxQixVQUFJcUIsS0FBSyxHQUFHdEIsQ0FBQyxDQUFDLFVBQUQsQ0FBYjtBQUNBLFlBQU11QixTQUFTLEdBQUcsQ0FBQ0QsS0FBSyxDQUFDekUsSUFBTixDQUFXLDBCQUFYLEVBQXVDSixJQUF2QyxNQUFpRDtBQUFFK0Usc0JBQWMsRUFBRTtBQUFsQixPQUFsRCxFQUF5RUEsY0FBekUsR0FBMEYsQ0FBNUc7QUFDQSxZQUFNQyxTQUFTLEdBQUcsQ0FBQ0gsS0FBSyxDQUFDekUsSUFBTixDQUFXLDBCQUFYLEVBQXVDSixJQUF2QyxNQUFpRDtBQUFFK0Usc0JBQWMsRUFBRTtBQUFsQixPQUFsRCxFQUF5RUEsY0FBekUsR0FBMEYsQ0FBNUc7QUFDQXZCLGNBQVEsQ0FBQ3hELElBQVQsQ0FBY3lELE9BQWQsR0FBd0JxQixTQUFTLEdBQUdFLFNBQXBDO0FBQ0F4QixjQUFRLENBQUN4RCxJQUFULENBQWM4RCxPQUFkLEdBQXdCTixRQUFRLENBQUN4RCxJQUFULENBQWM4RCxPQUFkLENBQXNCaEcsT0FBdEIsQ0FBOEIsYUFBOUIsRUFBNkMsRUFBN0MsQ0FBeEI7QUFDQSxhQUFPMEYsUUFBUDtBQUNEOztBQVJNLEdBdEJFO0FBZ0NYeUIsUUFBTSxFQUFFO0FBQ04zQixpQkFBYSxDQUFFQyxDQUFGLEVBQUtDLFFBQUwsRUFBZTtBQUMxQkEsY0FBUSxDQUFDeEQsSUFBVCxDQUFjeUQsT0FBZCxHQUF3QnlCLFFBQVEsQ0FBQzFCLFFBQVEsQ0FBQ3hELElBQVQsQ0FBYzZELGFBQWQsQ0FBNEIvRixPQUE1QixDQUFvQyxNQUFwQyxFQUE0QyxFQUE1QyxFQUFnREEsT0FBaEQsQ0FBd0QsR0FBeEQsRUFBNkQsRUFBN0QsQ0FBRCxDQUFoQztBQUNBMEYsY0FBUSxDQUFDeEQsSUFBVCxDQUFjNkQsYUFBZCxHQUE4QkwsUUFBUSxDQUFDeEQsSUFBVCxDQUFjOEQsT0FBZCxDQUFzQmhHLE9BQXRCLENBQThCLFFBQTlCLEVBQXdDLEVBQXhDLENBQTlCO0FBQ0EwRixjQUFRLENBQUN4RCxJQUFULENBQWM4RCxPQUFkLEdBQXdCTixRQUFRLENBQUN4RCxJQUFULENBQWM4RCxPQUFkLENBQXNCaEcsT0FBdEIsQ0FBOEIsUUFBOUIsRUFBd0MsRUFBeEMsQ0FBeEI7QUFDQSxhQUFPMEYsUUFBUDtBQUNEOztBQU5LLEdBaENHO0FBd0NYMkIsT0FBSyxFQUFFO0FBQ0w3QixpQkFBYSxDQUFFQyxDQUFGLEVBQUtDLFFBQUwsRUFBZTtBQUMxQixZQUFNeEQsSUFBSSxHQUFHNkIsSUFBSSxDQUFDNkIsS0FBTCxDQUFXbEIsSUFBSSxDQUFDMkIsR0FBTCxDQUFVLEdBQUVYLFFBQVEsQ0FBQ3hELElBQVQsQ0FBY2lFLEtBQU0sMEJBQWhDLEVBQTJEO0FBQ2pGbUIsZUFBTyxFQUFFO0FBQ1Asd0JBQWMsc0VBRFA7QUFFUCxxQkFBVzVCLFFBQVEsQ0FBQ3hELElBQVQsQ0FBY2lFLEtBRmxCO0FBR1AsOEJBQW9CO0FBSGI7QUFEd0UsT0FBM0QsRUFNckJNLE9BTlUsQ0FBYjtBQU9BZixjQUFRLENBQUN4RCxJQUFULENBQWN5RCxPQUFkLEdBQXdCekQsSUFBSSxDQUFDcUYsV0FBTCxDQUFpQkMsR0FBekM7QUFDQSxhQUFPOUIsUUFBUDtBQUNEOztBQVhJLEdBeENJO0FBcURYLGtCQUFnQjtBQUNkRixpQkFBYSxDQUFFQyxDQUFGLEVBQUtDLFFBQUwsRUFBZTtBQUMxQixZQUFNK0IsS0FBSyxHQUFHTCxRQUFRLENBQUMzQixDQUFDLENBQUMsV0FBRCxDQUFELENBQWVuRCxJQUFmLENBQW9CLFFBQXBCLEVBQThCQSxJQUE5QixDQUFtQyxHQUFuQyxFQUF3Q29GLElBQXhDLEVBQUQsQ0FBdEI7QUFDQWhDLGNBQVEsQ0FBQ3hELElBQVQsQ0FBY3lELE9BQWQsR0FBd0I4QixLQUFLLElBQUksQ0FBakM7QUFDQSxhQUFPL0IsUUFBUDtBQUNEOztBQUxhO0FBckRMLENBQWI7O0FBOERBLE1BQU1pQyxVQUFVLEdBQUcsU0FBU0EsVUFBVCxDQUFxQmhHLEdBQXJCLEVBQTBCO0FBQzNDLE1BQUkrRCxRQUFKO0FBQ0EsTUFBSUwsSUFBSjtBQUNBLE1BQUl2QyxRQUFKOztBQUNBLE1BQUluQixHQUFHLENBQUN5RSxLQUFKLENBQVUsd0JBQVYsQ0FBSixFQUF5QztBQUN2Q3RELFlBQVEsR0FBRztBQUNUdUMsVUFBSSxFQUFFWCxJQUFJLENBQUMyQixHQUFMLENBQVMxRSxHQUFULEVBQWM7QUFDbEIyRixlQUFPLEVBQUU7QUFDUCx3QkFBYztBQURQO0FBRFMsT0FBZCxFQUlIYjtBQUxNLEtBQVg7QUFPRCxHQVJELE1BUU87QUFDTDNELFlBQVEsR0FBRztBQUNUbkI7QUFEUyxLQUFYO0FBR0Q7O0FBQ0QsR0FBQytELFFBQUQsRUFBV0wsSUFBWCxJQUFtQlIsU0FBUyxDQUFDL0IsUUFBRCxDQUE1Qjs7QUFFQSxNQUFJbkIsR0FBRyxDQUFDeUUsS0FBSixDQUFVLHdCQUFWLENBQUosRUFBeUM7QUFDdkNWLFlBQVEsQ0FBQ3hELElBQVQsQ0FBYzBGLFVBQWQsR0FBMkIsVUFBM0I7QUFDRDs7QUFFRCxNQUFJdEMsSUFBSSxDQUFDSSxRQUFRLENBQUN4RCxJQUFULENBQWMwRixVQUFkLElBQTRCbEMsUUFBUSxDQUFDeEQsSUFBVCxDQUFjMkYsV0FBM0MsQ0FBUixFQUFpRTtBQUMvRCxXQUFPdkMsSUFBSSxDQUFDSSxRQUFRLENBQUN4RCxJQUFULENBQWMwRixVQUFkLElBQTRCbEMsUUFBUSxDQUFDeEQsSUFBVCxDQUFjMkYsV0FBM0MsQ0FBSixDQUE0RHJDLGFBQTVELENBQTBFSCxJQUExRSxFQUFnRkssUUFBaEYsQ0FBUDtBQUNEOztBQUNELFNBQU9BLFFBQVA7QUFDRCxDQTNCRDs7QUE2QkEzRyxNQUFNLENBQUNpRCxPQUFQLENBQWU7QUFDYjhGLGtCQUFnQixDQUFFbkgsTUFBRixFQUFVb0gsTUFBVixFQUFrQjtBQUNoQyxRQUFJLENBQUNBLE1BQUQsSUFBV3RKLEtBQUssQ0FBQ3VFLE9BQU4sQ0FBYztBQUMzQkMsU0FBRyxFQUFFdEMsTUFEc0I7QUFFM0JxSCxtQkFBYSxFQUFFO0FBQ2JDLFdBQUcsRUFBRXRELE1BQU0sR0FBR3VELFFBQVQsQ0FBa0IsQ0FBbEIsRUFBcUIsTUFBckIsRUFBNkJDLE1BQTdCO0FBRFE7QUFGWSxLQUFkLENBQWYsRUFLSTtBQUNGO0FBQ0Q7O0FBQ0QsUUFBSUMsTUFBTSxHQUFHLENBQWI7QUFDQTFKLFNBQUssQ0FBQzRELElBQU4sQ0FBVztBQUNUM0IsWUFEUztBQUVUYSxZQUFNLEVBQUU7QUFGQyxLQUFYLEVBR0c2RyxPQUhILENBR1dDLElBQUksSUFBSTtBQUNqQixZQUFNNUMsUUFBUSxHQUFHaUMsVUFBVSxDQUFDVyxJQUFJLENBQUN6SixJQUFOLENBQTNCO0FBQ0FILFdBQUssQ0FBQ3lFLE1BQU4sQ0FBYTtBQUNYRixXQUFHLEVBQUVxRixJQUFJLENBQUNyRjtBQURDLE9BQWIsRUFFRztBQUNESSxZQUFJLEVBQUU7QUFDSnRCLFlBQUUsRUFBRTJELFFBQVEsQ0FBQ3hEO0FBRFQ7QUFETCxPQUZIO0FBT0FrRyxZQUFNLElBQUksQ0FBQzFDLFFBQVEsQ0FBQ3hELElBQVQsQ0FBY3lELE9BQWQsSUFBeUIsQ0FBMUIsSUFBK0IsQ0FBekM7QUFDRCxLQWJEO0FBY0FsSCxTQUFLLENBQUMwRSxNQUFOLENBQWE7QUFDWEYsU0FBRyxFQUFFdEM7QUFETSxLQUFiLEVBRUc7QUFDRDBDLFVBQUksRUFBRTtBQUNKK0UsY0FESTtBQUVKSixxQkFBYSxFQUFFLElBQUluRixJQUFKO0FBRlg7QUFETCxLQUZIO0FBUUQsR0FqQ1k7O0FBa0NiMEYsZUFBYSxDQUFFNUcsR0FBRixFQUFPO0FBQ2xCLFdBQU9nRyxVQUFVLENBQUNoRyxHQUFELENBQWpCO0FBQ0Q7O0FBcENZLENBQWYsRTs7Ozs7Ozs7Ozs7QUN4R0EsSUFBSTVDLE1BQUo7QUFBV1IsTUFBTSxDQUFDTSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUwsS0FBSixFQUFVQyxLQUFWO0FBQWdCSCxNQUFNLENBQUNNLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDSixPQUFLLENBQUNLLENBQUQsRUFBRztBQUFDTCxTQUFLLEdBQUNLLENBQU47QUFBUSxHQUFsQjs7QUFBbUJKLE9BQUssQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNKLFNBQUssR0FBQ0ksQ0FBTjtBQUFROztBQUFwQyxDQUFsQyxFQUF3RSxDQUF4RTtBQUEyRSxJQUFJcUIsZUFBSjtBQUFvQjVCLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3NCLGlCQUFlLENBQUNyQixDQUFELEVBQUc7QUFBQ3FCLG1CQUFlLEdBQUNyQixDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBNUIsRUFBb0UsQ0FBcEU7QUFBdUUsSUFBSXVCLEdBQUo7QUFBUTlCLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLEtBQVosRUFBa0I7QUFBQ3lCLFNBQU8sQ0FBQ3hCLENBQUQsRUFBRztBQUFDdUIsT0FBRyxHQUFDdkIsQ0FBSjtBQUFNOztBQUFsQixDQUFsQixFQUFzQyxDQUF0QztBQUs5UCxNQUFNeUIsWUFBWSxHQUFHO0FBQ25CaUksWUFBVSxFQUFFbkksR0FBRyxDQUFDTyxNQUFKO0FBRE8sQ0FBckI7QUFJQTdCLE1BQU0sQ0FBQ3lFLE9BQVAsQ0FBZSxTQUFmLEVBQTBCLFVBQVVpRixNQUFNLEdBQUcsQ0FBbkIsRUFBc0I7QUFDOUMsU0FBT2hLLEtBQUssQ0FBQzZELElBQU4sQ0FBVztBQUNoQjVELFNBQUssRUFBRTtBQUNMdUosU0FBRyxFQUFFO0FBREE7QUFEUyxHQUFYLEVBSUo7QUFDRHZFLFVBQU0sRUFBRTtBQUNOM0MsYUFBTyxFQUFFLENBREg7QUFFTkksZUFBUyxFQUFFO0FBRkwsS0FEUDtBQUtEdUgsUUFBSSxFQUFFO0FBQ0pOLFlBQU0sRUFBRSxDQUFDO0FBREwsS0FMTDtBQVFETyxRQUFJLEVBQUUsS0FBS0YsTUFSVjtBQVNEbEcsU0FBSyxFQUFFO0FBVE4sR0FKSSxDQUFQO0FBZUQsQ0FoQkQ7QUFrQkF4RCxNQUFNLENBQUN5RSxPQUFQLENBQWUsVUFBZixFQUEyQixVQUFVb0YsUUFBVixFQUFvQkgsTUFBTSxHQUFHLENBQTdCLEVBQWdDO0FBQ3pELE1BQUk3RyxLQUFLLEdBQUcsTUFBWjs7QUFDQSxNQUFJO0FBQ0ZBLFNBQUssR0FBRyxJQUFJaUgsTUFBSixDQUFXRCxRQUFYLENBQVI7QUFDRCxHQUZELENBRUUsT0FBTzVELENBQVAsRUFBVTtBQUNWcEQsU0FBSyxHQUFHLElBQVI7QUFDRDs7QUFDRCxTQUFPbkQsS0FBSyxDQUFDNkQsSUFBTixDQUFXO0FBQ2hCeEMsVUFBTSxFQUFFOEIsS0FEUTtBQUVoQmxELFNBQUssRUFBRTtBQUNMdUosU0FBRyxFQUFFO0FBREE7QUFGUyxHQUFYLEVBS0o7QUFDRHZFLFVBQU0sRUFBRTtBQUNOM0MsYUFBTyxFQUFFLENBREg7QUFFTkksZUFBUyxFQUFFO0FBRkwsS0FEUDtBQUtEdUgsUUFBSSxFQUFFO0FBQ0pOLFlBQU0sRUFBRSxDQUFDO0FBREwsS0FMTDtBQVFETyxRQUFJLEVBQUUsS0FBS0YsTUFSVjtBQVNEbEcsU0FBSyxFQUFFO0FBVE4sR0FMSSxDQUFQO0FBZ0JELENBdkJEO0FBeUJBeEQsTUFBTSxDQUFDeUUsT0FBUCxDQUFlLFlBQWYsRUFBNkIsVUFBVTdDLE1BQVYsRUFBa0I7QUFDN0NSLGlCQUFlLENBQUM7QUFDZCtCLFFBQUksRUFBRXZCLE1BRFE7QUFFZHdCLFVBQU0sRUFBRTVCLFlBQVksQ0FBQ2lJLFVBRlA7QUFHZHBHLFNBQUssRUFBRTtBQUNMQyxXQUFLLEVBQUU7QUFERjtBQUhPLEdBQUQsQ0FBZjtBQVFBLFNBQU8zRCxLQUFLLENBQUM0RCxJQUFOLENBQVc7QUFDaEIzQixVQURnQjtBQUVoQmEsVUFBTSxFQUFFO0FBRlEsR0FBWCxFQUdKO0FBQ0RrSCxRQUFJLEVBQUU7QUFDSjFILGVBQVMsRUFBRSxDQUFDLENBRFI7QUFFSmtDLGVBQVMsRUFBRSxDQUFDO0FBRlIsS0FETDtBQUtEWCxTQUFLLEVBQUU7QUFMTixHQUhJLENBQVA7QUFVRCxDQW5CRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5cbmV4cG9ydCBjb25zdCBjbGlwcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjbGlwcycpXG5leHBvcnQgY29uc3QgcG9zdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncG9zdHMnKVxuZXhwb3J0IHZhciBtaXNDbGlwc1xuXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KSB7XG4gIG1pc0NsaXBzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24obnVsbClcbiAgLyogZXNsaW50LWRpc2FibGUtbmV4dC1saW5lICovXG4gIG5ldyBQZXJzaXN0ZW50TWluaW1vbmdvMihtaXNDbGlwcywgJ21pc0NsaXBzJylcbn1cblxuaWYgKE1ldGVvci5pc0RldmVsb3BtZW50KSB7XG4gIGdsb2JhbC5taXNDbGlwcyA9IG1pc0NsaXBzXG4gIGdsb2JhbC5jbGlwcyA9IGNsaXBzXG4gIGdsb2JhbC5wb3N0cyA9IHBvc3RzXG59XG4iLCJjb25zdCBkaWFjcml0aWNhcyA9IHtcbiAgw6E6ICdhJyxcbiAgw6k6ICdlJyxcbiAgw606ICdpJyxcbiAgw7M6ICdvJyxcbiAgw7o6ICd1JyxcbiAgw7E6ICduJyxcbiAgw6c6ICdjJ1xufVxuXG5leHBvcnQgY29uc3QgdGl0dWxvQVVybCA9IGZ1bmN0aW9uIHRpdHVsb0FVcmwgKHRpdHVsbykge1xuICByZXR1cm4gKHRpdHVsbyB8fCAnJykudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bIF0vZywgJy0nKS5yZXBsYWNlKC9bw6HDqcOtw7rDs8O8w7FdL2csIGZ1bmN0aW9uIChsZXRyYSkge1xuICAgIHJldHVybiBkaWFjcml0aWNhc1tsZXRyYV1cbiAgfSkucmVwbGFjZSgvW15hLXowLTkgXy4tXS9nLCAnJylcbn1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuaW1wb3J0IHsgY2xpcHMsIHBvc3RzIH0gZnJvbSAnL2NvbW1vbi9iYXNlRGVEYXRvcydcbmltcG9ydCB7IHNhbGlyVmFsaWRhY2lvbiwgc2FsaXIgfSBmcm9tICcvc2VydmVyL2NvbXVuJ1xuaW1wb3J0IHsgdGl0dWxvQVVybCB9IGZyb20gJy9jb21tb24vdmFyaW9zJ1xuXG5pbXBvcnQgSm9pIGZyb20gJ2pvaSdcblxuY29uc3QgdmFsaWRhY2lvbmVzID0ge1xuICBjYW1iaWFyUHJpb3JpZGFkOiBKb2kub2JqZWN0KCkua2V5cyh7XG4gICAgY2xpcElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBwb3N0SWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlY3JldG86IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHByaW9yaWRhZDogSm9pLm51bWJlcigpLnJlcXVpcmVkKClcbiAgfSksXG4gIHJldm9jYXI6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICBjbGlwSWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlZ3VyaWRhZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgbGxhdmU6IEpvaS5zdHJpbmcoKS52YWxpZChbJ3NlZ3VyaWRhZCcsICdzZWNyZXRvJ10pLnJlcXVpcmVkKClcbiAgfSksXG4gIG9idGVuZXJTZWNyZXRvOiBKb2kub2JqZWN0KCkua2V5cyh7XG4gICAgY2xpcElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBzZWd1cmlkYWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpXG4gIH0pLFxuICBlc3RhYmxlY2VyU3RhdHVzOiBKb2kub2JqZWN0KCkua2V5cyh7XG4gICAgY2xpcElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBwb3N0SWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlY3JldG86IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHN0YXR1czogSm9pLnN0cmluZygpLnZhbGlkKFsnUkVDSEFaQURPJywgJ09DVUxUTycsICdWSVNJQkxFJ10pLnJlcXVpcmVkKClcbiAgfSksXG4gIGVsaW1pbmFyUG9zdDogSm9pLm9iamVjdCgpLmtleXMoe1xuICAgIGNsaXBJZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgcG9zdElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBzZWNyZXRvOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKVxuICB9KSxcbiAgY2xpcFB1Ymxpc2g6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICB1cmw6IEpvaS5zdHJpbmcoKS5yZWdleCgvXlthLXotXSskLykucmVxdWlyZWQoKSxcbiAgICBzZWNyZXRvOiBKb2kuc3RyaW5nKClcbiAgfSksXG4gIGNsaXBJZFB1Ymxpc2g6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICBjbGlwSWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlY3JldG86IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpXG4gIH0pLFxuICBhZ3JlZ2FyTGluazogSm9pLm9iamVjdCgpLmtleXMoe1xuICAgIHVybDogSm9pLnN0cmluZygpLnJlZ2V4KC9eW2Etei1dKyQvKS5yZXF1aXJlZCgpLFxuICAgIGxpbms6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIE9HOiBKb2kub2JqZWN0KCkucmVxdWlyZWQoKVxuICB9KSxcbiAgdGl0dWxvOiBKb2kuc3RyaW5nKClcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBjcmVhckNsaXAgKHRpdHVsbykge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiB0aXR1bG8sXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy50aXR1bG8sXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCBjcmVhckNsaXAnXG4gICAgICB9XG4gICAgfSlcblxuICAgIGlmIChjbGlwcy5maW5kKHtcbiAgICAgIHRpdHVsb1xuICAgIH0sIHtcbiAgICAgIGxpbWl0OiAxXG4gICAgfSkuY291bnQoKSkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsICd0aXR1bG8gcmVwZXRpZG8nKVxuICAgIH1cbiAgICBjb25zdCB1cmwgPSB0aXR1bG9BVXJsKHRpdHVsbylcbiAgICBpZiAoY2xpcHMuZmluZCh7XG4gICAgICB1cmxcbiAgICB9LCB7XG4gICAgICBsaW1pdDogMVxuICAgIH0pLmNvdW50KCkpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCAndXJsIHJlcGV0aWRhJylcbiAgICB9XG5cbiAgICBjb25zdCBzZWNyZXRvID0gUmFuZG9tLnNlY3JldCgpXG4gICAgY29uc3Qgc2VndXJpZGFkID0gUmFuZG9tLnNlY3JldCgpXG4gICAgY29uc3QgY2xpcElkID0gY2xpcHMuaW5zZXJ0KHtcbiAgICAgIGNyZWFjaW9uOiBuZXcgRGF0ZSgpLFxuICAgICAgdGl0dWxvLFxuICAgICAgdXJsLFxuICAgICAgc2VjcmV0byxcbiAgICAgIHNlZ3VyaWRhZFxuICAgIH0pXG5cbiAgICByZXR1cm4ge1xuICAgICAgY2xpcElkLFxuICAgICAgc2VjcmV0byxcbiAgICAgIHNlZ3VyaWRhZFxuICAgIH1cbiAgfSxcbiAgYWdyZWdhckxpbmsgKG9wY2lvbmVzKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMuYWdyZWdhckxpbmssXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCBhZ3JlZ2FyTGluaydcbiAgICAgIH1cbiAgICB9KVxuICAgIGNvbnN0IGNsaXAgPSBjbGlwcy5maW5kT25lKHtcbiAgICAgIHVybDogb3BjaW9uZXMudXJsXG4gICAgfSkgfHwgc2FsaXIoNDA0LCAnQ2xpcCBubyBlbmNvbnRyYWRvJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgYWdyZWdhckxpbmsnXG4gICAgfSlcblxuICAgIGlmIChwb3N0cy5maW5kT25lKHtcbiAgICAgIGNsaXBJZDogY2xpcC5faWQsXG4gICAgICBsaW5rOiBvcGNpb25lcy5saW5rXG4gICAgfSkpIHtcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBwb3N0cy5pbnNlcnQoe1xuICAgICAgY2xpcElkOiBjbGlwLl9pZCxcbiAgICAgIE9HOiBvcGNpb25lcy5PRyxcbiAgICAgIGxpbms6IG9wY2lvbmVzLmxpbmssXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCksXG4gICAgICBzdGF0dXM6ICdQRU5ESUVOVEUnLFxuICAgICAgcHJpb3JpZGFkOiAwXG4gICAgfSlcbiAgICBpZiAob3BjaW9uZXMuc2VjcmV0bykge1xuICAgICAgY2xpcHMudXBkYXRlKHtcbiAgICAgICAgX2lkOiBjbGlwLl9pZFxuICAgICAgfSwge1xuICAgICAgICAkaW5jOiB7XG4gICAgICAgICAgcG9zdHM6IDFcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gIH0sXG4gIGNhbWJpYXJQcmlvcmlkYWQgKG9wY2lvbmVzKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMuY2FtYmlhclByaW9yaWRhZCxcbiAgICAgIGRlYnVnOiB7XG4gICAgICAgIGRvbmRlOiAnbWV0aG9kIGNhbWJpYXJQcmlvcmlkYWQnXG4gICAgICB9XG4gICAgfSlcbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkLFxuICAgICAgc2VjcmV0bzogb3BjaW9uZXMuc2VjcmV0b1xuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDAxLCAnTm8gdGllbmVzIHBlcm1pc28gcGFyYSBhZG1pbmlzdHJhciBlbCBjbGlwJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICB9KVxuXG4gICAgcG9zdHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLnBvc3RJZCxcbiAgICAgIGNsaXBJZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdQb3N0IG5vIGVuY29udHJhZG8nKVxuXG4gICAgcG9zdHMudXBkYXRlKG9wY2lvbmVzLnBvc3RJZCwge1xuICAgICAgJHNldDoge1xuICAgICAgICBwcmlvcmlkYWQ6IG9wY2lvbmVzLnByaW9yaWRhZFxuICAgICAgfVxuICAgIH0pXG4gIH0sXG4gIHRlc3RUaXR1bG8gKHRpdHVsbykge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiB0aXR1bG8sXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy50aXR1bG8sXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCB0ZXN0VGl0dWxvJ1xuICAgICAgfVxuICAgIH0pXG4gICAgLy8gaWYgKGNsaXBzLmZpbmQoe1xuICAgIC8vICAgdGl0dWxvXG4gICAgLy8gfSwge1xuICAgIC8vICAgbGltaXQ6IDFcbiAgICAvLyB9KS5jb3VudCgpKSB7XG4gICAgLy8gICBjb25zb2xlLmxvZygndGl0dWxvIHJlcGV0aWRvJylcbiAgICAvLyAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCAndGl0dWxvIHJlcGV0aWRvJylcbiAgICAvLyB9XG4gICAgY29uc3QgdXJsID0gdGl0dWxvQVVybCh0aXR1bG8pXG4gICAgaWYgKGNsaXBzLmZpbmQoe1xuICAgICAgdXJsXG4gICAgfSwge1xuICAgICAgbGltaXQ6IDFcbiAgICB9KS5jb3VudCgpKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMCwgJ3VybCByZXBldGlkYScpXG4gICAgfVxuICB9LFxuICBlc3RhYmxlY2VyU3RhdHVzIChvcGNpb25lcykge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiBvcGNpb25lcyxcbiAgICAgIHNjaGVtYTogdmFsaWRhY2lvbmVzLmVzdGFibGVjZXJTdGF0dXMsXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgICAgfVxuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkLFxuICAgICAgc2VjcmV0bzogb3BjaW9uZXMuc2VjcmV0b1xuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDAxLCAnTm8gdGllbmVzIHBlcm1pc28gcGFyYSBhZG1pbmlzdHJhciBlbCBjbGlwJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICB9KVxuXG4gICAgcG9zdHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLnBvc3RJZCxcbiAgICAgIGNsaXBJZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdQb3N0IG5vIGVuY29udHJhZG8nKVxuXG4gICAgcG9zdHMudXBkYXRlKG9wY2lvbmVzLnBvc3RJZCwge1xuICAgICAgJHNldDoge1xuICAgICAgICBzdGF0dXM6IG9wY2lvbmVzLnN0YXR1c1xuICAgICAgfVxuICAgIH0pXG4gIH0sXG4gIGVsaW1pbmFyUG9zdCAob3BjaW9uZXMpIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogb3BjaW9uZXMsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5lbGltaW5hclBvc3QsXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgICAgfVxuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkLFxuICAgICAgc2VjcmV0bzogb3BjaW9uZXMuc2VjcmV0b1xuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDAxLCAnTm8gdGllbmVzIHBlcm1pc28gcGFyYSBhZG1pbmlzdHJhciBlbCBjbGlwJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICB9KVxuXG4gICAgcG9zdHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLnBvc3RJZCxcbiAgICAgIGNsaXBJZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdQb3N0IG5vIGVuY29udHJhZG8nKVxuXG4gICAgcG9zdHMucmVtb3ZlKG9wY2lvbmVzLnBvc3RJZClcbiAgfSxcbiAgcmV2b2NhciAob3BjaW9uZXMpIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogb3BjaW9uZXMsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5yZXZvY2FyLFxuICAgICAgZGVidWc6IHtcbiAgICAgICAgZG9uZGU6ICdtZXRob2QgcmV2b2NhcidcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgY2xpcHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZFxuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDA0LCAnQ2xpcCBubyBlbmNvbnRyYWRvJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgcmV2b2NhcidcbiAgICB9KVxuXG4gICAgY2xpcHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZCxcbiAgICAgIHNlZ3VyaWRhZDogb3BjaW9uZXMuc2VndXJpZGFkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDAsICdObyB0aWVuZXMgcGVybWlzbyBwYXJhIHJldm9jYXIgbGxhdmVzJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgcmV2b2NhcidcbiAgICB9KVxuXG4gICAgY29uc3QgbGxhdmUgPSBSYW5kb20uc2VjcmV0KClcblxuICAgIGNsaXBzLnVwZGF0ZShvcGNpb25lcy5jbGlwSWQsIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgW29wY2lvbmVzLmxsYXZlXTogbGxhdmVcbiAgICAgIH1cbiAgICB9KVxuICAgIHJldHVybiBsbGF2ZVxuICB9LFxuICBvYnRlbmVyU2VjcmV0byAob3BjaW9uZXMpIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogb3BjaW9uZXMsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5vYnRlbmVyU2VjcmV0byxcbiAgICAgIGRlYnVnOiB7XG4gICAgICAgIGRvbmRlOiAnbWV0aG9kIG9idGVuZXJTZWNyZXRvJ1xuICAgICAgfVxuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgICBkb25kZTogJ21ldGhvZCByZXZvY2FyJ1xuICAgIH0pXG5cbiAgICBjb25zdCBjbGlwID0gY2xpcHMuZmluZE9uZSh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZCxcbiAgICAgIHNlZ3VyaWRhZDogb3BjaW9uZXMuc2VndXJpZGFkXG4gICAgfSkgfHwgc2FsaXIoNDAxLCAnTm8gdGllbmVzIHBlcm1pc28gcGFyYSBvYnRlbmVyIGxhIGxsYXZlIGRlIGFkbWluaXN0cmFjacOzbicsIHtcbiAgICAgIGRvbmRlOiAnbWV0aG9kIHJldm9jYXInXG4gICAgfSlcblxuICAgIHJldHVybiBjbGlwLnNlY3JldG9cbiAgfVxufSlcblxuTWV0ZW9yLnB1Ymxpc2goJ2NsaXAnLCBmdW5jdGlvbiAob3BjaW9uZXMpIHtcbiAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICBkYXRhOiBvcGNpb25lcyxcbiAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5jbGlwUHVibGlzaCxcbiAgICBkZWJ1Zzoge1xuICAgICAgZG9uZGU6ICdwdWJsaXNoIGNsaXAnXG4gICAgfVxuICB9KVxuICBjb25zdCBjbGlwID0gY2xpcHMuZmluZE9uZSh7XG4gICAgdXJsOiBvcGNpb25lcy51cmxcbiAgfSkgfHwgc2FsaXIoNDA0LCAnQ2xpcCBubyBlbmNvbnRyYWRvJywge1xuICAgIGRvbmRlOiAncHVibGlzaCBjbGlwJ1xuICB9KVxuXG4gIG9wY2lvbmVzLnNlY3JldG8gJiYgY2xpcC5zZWNyZXRvICE9PSBvcGNpb25lcy5zZWNyZXRvICYmIHNhbGlyKDQwMSwgJ05vIHRpZW5lcyBwZXJtaXNvJywge1xuICAgIGRvbmRlOiAncHVibGlzaCBjbGlwJ1xuICB9KVxuXG4gIGNvbnN0IHBvc3RzUXVlcnkgPSB7XG4gICAgY2xpcElkOiBjbGlwLl9pZFxuICB9XG5cbiAgaWYgKCFvcGNpb25lcy5zZWNyZXRvKSB7XG4gICAgcG9zdHNRdWVyeS5zdGF0dXMgPSAnVklTSUJMRSdcbiAgfVxuXG4gIHJldHVybiBbXG4gICAgY2xpcHMuZmluZChjbGlwLl9pZCwge1xuICAgICAgZmllbGRzOiB7XG4gICAgICAgIHNlZ3VyaWRhZDogMCxcbiAgICAgICAgc2VjcmV0bzogMFxuICAgICAgfVxuICAgIH0pLFxuICAgIHBvc3RzLmZpbmQocG9zdHNRdWVyeSlcbiAgXVxufSlcbk1ldGVvci5wdWJsaXNoKCdjbGlwSWQnLCBmdW5jdGlvbiAob3BjaW9uZXMpIHtcbiAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICBkYXRhOiBvcGNpb25lcyxcbiAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5jbGlwSWRQdWJsaXNoLFxuICAgIGRlYnVnOiB7XG4gICAgICBkb25kZTogJ3B1Ymxpc2ggY2xpcElkJ1xuICAgIH1cbiAgfSlcblxuICByZXR1cm4gY2xpcHMuZmluZCh7XG4gICAgX2lkOiBvcGNpb25lcy5jbGlwSWQsXG4gICAgc2VjcmV0bzogb3BjaW9uZXMuc2VjcmV0b1xuICB9LCB7XG4gICAgZmllbGRzOiB7XG4gICAgICBzZWd1cmlkYWQ6IDAsXG4gICAgICBzZWNyZXRvOiAwXG4gICAgfVxuICB9KVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgSm9pIGZyb20gJ2pvaSdcblxuZXhwb3J0IGNvbnN0IHNhbGlyID0gZnVuY3Rpb24gc2FsaXIgKGNvZGlnbywgbWVuc2FqZSwgZGVidWcpIHtcbiAgaWYgKGRlYnVnKSB7XG4gICAgY29uc29sZS5sb2coY29kaWdvLCBtZW5zYWplKVxuICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KGRlYnVnLCBudWxsLCAyKSlcbiAgfVxuICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGNvZGlnbywgbWVuc2FqZSlcbn1cblxuZXhwb3J0IGNvbnN0IHNhbGlyVmFsaWRhY2lvbiA9IGZ1bmN0aW9uIChvcGNpb25lcykge1xuICBjb25zdCB2YWxpZGFjaW9uID0gSm9pLnZhbGlkYXRlKG9wY2lvbmVzLmRhdGEsIG9wY2lvbmVzLnNjaGVtYSlcbiAgaWYgKCF2YWxpZGFjaW9uLmVycm9yKSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgb3BjaW9uZXMgPSBPYmplY3QuYXNzaWduKHtcbiAgICBjb2RpZ286IDQwMCxcbiAgICBtZW5zYWplOiB2YWxpZGFjaW9uLmVycm9yLmRldGFpbHNbMF0ubWVzc2FnZVxuICB9LCBvcGNpb25lcylcbiAgaWYgKG9wY2lvbmVzLmRlYnVnKSB7XG4gICAgb3BjaW9uZXMuZGVidWcuZGV0YWlscyA9IHZhbGlkYWNpb24uZXJyb3IuZGV0YWlsc1xuICAgIG9wY2lvbmVzLmRlYnVnLl9vYmplY3QgPSB2YWxpZGFjaW9uLmVycm9yLl9vYmplY3RcbiAgfVxuICBzYWxpcihvcGNpb25lcy5jb2RpZ28sIG9wY2lvbmVzLm1lbnNhamUsIG9wY2lvbmVzLmRlYnVnKVxufVxuIiwiaW1wb3J0IGNoZWVyaW8gZnJvbSAnY2hlZXJpbydcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCdcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBjbGlwcywgcG9zdHMgfSBmcm9tICcvY29tbW9uL2Jhc2VEZURhdG9zJ1xuaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnXG5pbXBvcnQgb2dzIGZyb20gJ29wZW4tZ3JhcGgtc2NyYXBlcidcblxuY29uc3QgbWV0ZW9yT0dTID0gTWV0ZW9yLndyYXBBc3luYyhmdW5jdGlvbiAob3BjaW9uZXMsIGNhbGxiYWNrKSB7XG4gIG9ncyhvcGNpb25lcywgZnVuY3Rpb24gKGUsIHIsIGgpIHtcbiAgICBjYWxsYmFjayhlLCBbciwgY2hlZXJpby5sb2FkKGggPyBoLmJvZHkgOiBvcGNpb25lcy5odG1sKV0pXG4gIH0pXG59KVxuXG5jb25zdCBycnNzID0ge1xuICBJbnN0YWdyYW06IHtcbiAgICBvYnRlbmVyQXBveW9zICgkLCByZXNwb25zZSkge1xuICAgICAgcmVzcG9uc2UuZGF0YS5jckxpa2VzID0gSlNPTi5wYXJzZSgkKCdzY3JpcHRbdHlwZT1cImFwcGxpY2F0aW9uL2xkK2pzb25cIl0nKS5odG1sKCkpLmludGVyYWN0aW9uU3RhdGlzdGljLnVzZXJJbnRlcmFjdGlvbkNvdW50XG4gICAgICByZXNwb25zZS5kYXRhLm9nRGVzY3JpcHRpb24gPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvXi4qP29uIEluc3RhZ3JhbTogLywgJycpXG4gICAgICByZXNwb25zZS5kYXRhLm9nVGl0bGUgPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvb24gSW5zdGFncmFtOi4qJC8sICcnKVxuICAgICAgcmV0dXJuIHJlc3BvbnNlXG4gICAgfVxuICB9LFxuICBZb3VUdWJlOiB7XG4gICAgcmVnZXg6IC8oXnw9fFxcLykoWzAtOUEtWmEtel8tXXsxMX0pKFxcL3wmfCR8XFw/fCMpLyxcbiAgICBvYnRlbmVyQXBveW9zICgkLCByZXNwb25zZSkge1xuICAgICAgY29uc3QgeW91dHViZSA9IHJlc3BvbnNlLmRhdGEub2dVcmwubWF0Y2gocnJzcy5Zb3VUdWJlLnJlZ2V4KVxuICAgICAgaWYgKCF5b3V0dWJlKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZVxuICAgICAgfVxuICAgICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UoSFRUUC5nZXQoYGh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL3lvdXR1YmUvdjMvdmlkZW9zP2lkPSR7eW91dHViZVsyXX0ma2V5PSR7TWV0ZW9yLnNldHRpbmdzLnByaXZhdGUueW91dHViZUFQSX0mcGFydD1zdGF0aXN0aWNzYCkuY29udGVudCkuaXRlbXNbMF0uc3RhdGlzdGljc1xuXG4gICAgICByZXNwb25zZS5kYXRhLmNyTGlrZXMgPSBkYXRhLmxpa2VDb3VudCAtIGRhdGEuZGlzbGlrZUNvdW50XG4gICAgICByZXR1cm4gcmVzcG9uc2VcbiAgICB9XG4gIH0sXG4gIFR3aXR0ZXI6IHtcbiAgICBvYnRlbmVyQXBveW9zICgkLCByZXNwb25zZSkge1xuICAgICAgdmFyIHN0YXRzID0gJCgndWwuc3RhdHMnKVxuICAgICAgY29uc3QgcmV0d2VldGVkID0gKHN0YXRzLmZpbmQoJy5yZXF1ZXN0LXJldHdlZXRlZC1wb3B1cCcpLmRhdGEoKSB8fCB7IHR3ZWV0U3RhdENvdW50OiAwIH0pLnR3ZWV0U3RhdENvdW50ICogMVxuICAgICAgY29uc3QgZmF2b3JpdGVkID0gKHN0YXRzLmZpbmQoJy5yZXF1ZXN0LWZhdm9yaXRlZC1wb3B1cCcpLmRhdGEoKSB8fCB7IHR3ZWV0U3RhdENvdW50OiAwIH0pLnR3ZWV0U3RhdENvdW50ICogMVxuICAgICAgcmVzcG9uc2UuZGF0YS5jckxpa2VzID0gcmV0d2VldGVkICsgZmF2b3JpdGVkXG4gICAgICByZXNwb25zZS5kYXRhLm9nVGl0bGUgPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvb24gVHdpdHRlciQvLCAnJylcbiAgICAgIHJldHVybiByZXNwb25zZVxuICAgIH1cbiAgfSxcbiAgcmVkZGl0OiB7XG4gICAgb2J0ZW5lckFwb3lvcyAoJCwgcmVzcG9uc2UpIHtcbiAgICAgIHJlc3BvbnNlLmRhdGEuY3JMaWtlcyA9IHBhcnNlSW50KHJlc3BvbnNlLmRhdGEub2dEZXNjcmlwdGlvbi5yZXBsYWNlKC8gLiokLywgJycpLnJlcGxhY2UoLywvLCAnJykpXG4gICAgICByZXNwb25zZS5kYXRhLm9nRGVzY3JpcHRpb24gPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvXi4qPy0gLywgJycpXG4gICAgICByZXNwb25zZS5kYXRhLm9nVGl0bGUgPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvIC0gLiokLywgJycpXG4gICAgICByZXR1cm4gcmVzcG9uc2VcbiAgICB9XG4gIH0sXG4gIFZpbWVvOiB7XG4gICAgb2J0ZW5lckFwb3lvcyAoJCwgcmVzcG9uc2UpIHtcbiAgICAgIGNvbnN0IGRhdGEgPSBKU09OLnBhcnNlKEhUVFAuZ2V0KGAke3Jlc3BvbnNlLmRhdGEub2dVcmx9P2FjdGlvbj1sb2FkX3N0YXRfY291bnRzYCwge1xuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ1VzZXItQWdlbnQnOiAnTW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0OyBydjo2Ny4wKSBHZWNrby8yMDEwMDEwMSBGaXJlZm94LzY3LjAnLFxuICAgICAgICAgICdSZWZlcmVyJzogcmVzcG9uc2UuZGF0YS5vZ1VybCxcbiAgICAgICAgICAnWC1SZXF1ZXN0ZWQtV2l0aCc6ICdYTUxIdHRwUmVxdWVzdCdcbiAgICAgICAgfVxuICAgICAgfSkuY29udGVudClcbiAgICAgIHJlc3BvbnNlLmRhdGEuY3JMaWtlcyA9IGRhdGEudG90YWxfbGlrZXMucmF3XG4gICAgICByZXR1cm4gcmVzcG9uc2VcbiAgICB9XG4gIH0sXG4gICdAbWVuZWFtZV9uZXQnOiB7XG4gICAgb2J0ZW5lckFwb3lvcyAoJCwgcmVzcG9uc2UpIHtcbiAgICAgIGNvbnN0IHZvdG9zID0gcGFyc2VJbnQoJCgnI25ld3N3cmFwJykuZmluZCgnLnZvdGVzJykuZmluZCgnYScpLnRleHQoKSlcbiAgICAgIHJlc3BvbnNlLmRhdGEuY3JMaWtlcyA9IHZvdG9zIHx8IDBcbiAgICAgIHJldHVybiByZXNwb25zZVxuICAgIH1cbiAgfVxufVxuXG5jb25zdCBhY3R1YWxpemFyID0gZnVuY3Rpb24gYWN0dWFsaXphciAodXJsKSB7XG4gIHZhciByZXNwb25zZVxuICB2YXIgaHRtbFxuICB2YXIgb3BjaW9uZXNcbiAgaWYgKHVybC5tYXRjaCgvaHR0cHM6XFwvXFwvd3d3LmZhY2Vib29rLykpIHtcbiAgICBvcGNpb25lcyA9IHtcbiAgICAgIGh0bWw6IEhUVFAuZ2V0KHVybCwge1xuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ1VzZXItQWdlbnQnOiAnRmVlZEZldGNoZXItR29vZ2xlOyAoK2h0dHA6Ly93d3cuZ29vZ2xlLmNvbS9mZWVkZmV0Y2hlci5odG1sKSdcbiAgICAgICAgfVxuICAgICAgfSkuY29udGVudFxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBvcGNpb25lcyA9IHtcbiAgICAgIHVybFxuICAgIH1cbiAgfVxuICBbcmVzcG9uc2UsIGh0bWxdID0gbWV0ZW9yT0dTKG9wY2lvbmVzKVxuXG4gIGlmICh1cmwubWF0Y2goL2h0dHBzOlxcL1xcL3d3dy5mYWNlYm9vay8pKSB7XG4gICAgcmVzcG9uc2UuZGF0YS5vZ1NpdGVOYW1lID0gJ0ZhY2Vib29rJ1xuICB9XG5cbiAgaWYgKHJyc3NbcmVzcG9uc2UuZGF0YS5vZ1NpdGVOYW1lIHx8IHJlc3BvbnNlLmRhdGEudHdpdHRlclNpdGVdKSB7XG4gICAgcmV0dXJuIHJyc3NbcmVzcG9uc2UuZGF0YS5vZ1NpdGVOYW1lIHx8IHJlc3BvbnNlLmRhdGEudHdpdHRlclNpdGVdLm9idGVuZXJBcG95b3MoaHRtbCwgcmVzcG9uc2UpXG4gIH1cbiAgcmV0dXJuIHJlc3BvbnNlXG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgYWN0dWFsaXphckFwb3lvcyAoY2xpcElkLCBmb3J6YXIpIHtcbiAgICBpZiAoIWZvcnphciAmJiBjbGlwcy5maW5kT25lKHtcbiAgICAgIF9pZDogY2xpcElkLFxuICAgICAgYWN0dWFsaXphY2lvbjoge1xuICAgICAgICAkZ3Q6IG1vbWVudCgpLnN1YnRyYWN0KDEsICdob3VyJykudG9EYXRlKClcbiAgICAgIH1cbiAgICB9KSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHZhciBhcG95b3MgPSAwXG4gICAgcG9zdHMuZmluZCh7XG4gICAgICBjbGlwSWQsXG4gICAgICBzdGF0dXM6ICdWSVNJQkxFJ1xuICAgIH0pLmZvckVhY2gocG9zdCA9PiB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGFjdHVhbGl6YXIocG9zdC5saW5rKVxuICAgICAgcG9zdHMudXBkYXRlKHtcbiAgICAgICAgX2lkOiBwb3N0Ll9pZFxuICAgICAgfSwge1xuICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgT0c6IHJlc3BvbnNlLmRhdGFcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICAgIGFwb3lvcyArPSAocmVzcG9uc2UuZGF0YS5jckxpa2VzIHx8IDApICogMVxuICAgIH0pXG4gICAgY2xpcHMudXBkYXRlKHtcbiAgICAgIF9pZDogY2xpcElkXG4gICAgfSwge1xuICAgICAgJHNldDoge1xuICAgICAgICBhcG95b3MsXG4gICAgICAgIGFjdHVhbGl6YWNpb246IG5ldyBEYXRlKClcbiAgICAgIH1cbiAgICB9KVxuICB9LFxuICBwcmV2aXN1YWxpemFyICh1cmwpIHtcbiAgICByZXR1cm4gYWN0dWFsaXphcih1cmwpXG4gIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgY2xpcHMsIHBvc3RzIH0gZnJvbSAnL2NvbW1vbi9iYXNlRGVEYXRvcydcbmltcG9ydCB7IHNhbGlyVmFsaWRhY2lvbiB9IGZyb20gJy9zZXJ2ZXIvY29tdW4nXG5pbXBvcnQgSm9pIGZyb20gJ2pvaSdcblxuY29uc3QgdmFsaWRhY2lvbmVzID0ge1xuICBwcmltZXJQb3N0OiBKb2kuc3RyaW5nKClcbn1cblxuTWV0ZW9yLnB1Ymxpc2goJ3JhbmtpbmcnLCBmdW5jdGlvbiAocGFnaW5hID0gMCkge1xuICByZXR1cm4gY2xpcHMuZmluZCh7XG4gICAgcG9zdHM6IHtcbiAgICAgICRndDogMFxuICAgIH1cbiAgfSwge1xuICAgIGZpZWxkczoge1xuICAgICAgc2VjcmV0bzogMCxcbiAgICAgIHNlZ3VyaWRhZDogMFxuICAgIH0sXG4gICAgc29ydDoge1xuICAgICAgYXBveW9zOiAtMVxuICAgIH0sXG4gICAgc2tpcDogMTAgKiBwYWdpbmEsXG4gICAgbGltaXQ6IDEwXG4gIH0pXG59KVxuXG5NZXRlb3IucHVibGlzaCgnYnVzcXVlZGEnLCBmdW5jdGlvbiAoYnVzcXVlZGEsIHBhZ2luYSA9IDApIHtcbiAgdmFyIHJlZ2V4ID0gLyg/OikvXG4gIHRyeSB7XG4gICAgcmVnZXggPSBuZXcgUmVnRXhwKGJ1c3F1ZWRhKVxuICB9IGNhdGNoIChlKSB7XG4gICAgcmVnZXggPSAvJF4vXG4gIH1cbiAgcmV0dXJuIGNsaXBzLmZpbmQoe1xuICAgIHRpdHVsbzogcmVnZXgsXG4gICAgcG9zdHM6IHtcbiAgICAgICRndDogMFxuICAgIH1cbiAgfSwge1xuICAgIGZpZWxkczoge1xuICAgICAgc2VjcmV0bzogMCxcbiAgICAgIHNlZ3VyaWRhZDogMFxuICAgIH0sXG4gICAgc29ydDoge1xuICAgICAgYXBveW9zOiAtMVxuICAgIH0sXG4gICAgc2tpcDogMTAgKiBwYWdpbmEsXG4gICAgbGltaXQ6IDEwXG4gIH0pXG59KVxuXG5NZXRlb3IucHVibGlzaCgncHJpbWVyUG9zdCcsIGZ1bmN0aW9uIChjbGlwSWQpIHtcbiAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICBkYXRhOiBjbGlwSWQsXG4gICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMucHJpbWVyUG9zdCxcbiAgICBkZWJ1Zzoge1xuICAgICAgZG9uZGU6ICdwdWJsaXNoIGNsaXAnXG4gICAgfVxuICB9KVxuXG4gIHJldHVybiBwb3N0cy5maW5kKHtcbiAgICBjbGlwSWQsXG4gICAgc3RhdHVzOiAnVklTSUJMRSdcbiAgfSwge1xuICAgIHNvcnQ6IHtcbiAgICAgIHByaW9yaWRhZDogLTEsXG4gICAgICB0aW1lc3RhbXA6IC0xXG4gICAgfSxcbiAgICBsaW1pdDogMVxuICB9KVxufSlcbiJdfQ==
