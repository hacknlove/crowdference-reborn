var require = meteorInstall({"common":{"baseDeDatos.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/baseDeDatos.js                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  clips: () => clips,
  posts: () => posts,
  misClips: () => misClips
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
const clips = new Mongo.Collection('clips');
const posts = new Mongo.Collection('posts');
var misClips;

if (Meteor.isClient) {
  module.runSetters(misClips = new Mongo.Collection(null));
  /* eslint-disable-next-line */

  new PersistentMinimongo2(misClips, 'misClips');
}

if (Meteor.isDevelopment) {
  global.misClips = misClips;
  global.clips = clips;
  global.posts = posts;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"traducciones.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/traducciones.js                                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  traducciones: () => traducciones,
  idiomas: () => idiomas
});
const traducciones = {
  "Aceptar": {
    "en": "Accept",
    "es": "Aceptar"
  },
  "Agrega enlaces al clip.": {
    "en": "Add links to clip.",
    "es": "Agrega enlaces al clip."
  },
  "Agregar": {
    "en": "Add",
    "es": "Agregar"
  },
  "Agregar enlace": {
    "en": "Add link",
    "es": "Agregar enlace"
  },
  "Aprobar": {
    "en": "Approve",
    "es": "Aprobar"
  },
  "Atrás": {
    "en": "Back",
    "es": "Atrás"
  },
  "Buscar clip": {
    "en": "Search clip",
    "es": "Buscar clip"
  },
  "Busqueda:": {
    "en": "Search",
    "es": "Busqueda:"
  },
  "Cancelar": {
    "en": "Cancel",
    "es": "Cancelar"
  },
  "Clip vacío": {
    "en": "Empty clip",
    "es": "Clip vacío"
  },
  "Compartir": {
    "en": "Share",
    "es": "Compartir"
  },
  "Con esta llave se puede administrar el clip": {
    "en": "This key allows to admin the clip",
    "es": "Con esta llave se puede administrar el clip"
  },
  "Con esta llave se pueden revocar las llaves de administración y seguridad.": {
    "en": "This key allows to revoke the keys",
    "es": "Con esta llave se pueden revocar las llaves de administración y seguridad."
  },
  "Crear": {
    "en": "Create",
    "es": "Crear"
  },
  "Crear clip": {
    "en": "Create clip",
    "es": "Crear clip"
  },
  "Eliminar": {
    "en": "Remove",
    "es": "Eliminar"
  },
  "Escribe un título para el clip": {
    "en": "Enter a title for the clip",
    "es": "Escribe un título para el clip"
  },
  "Favoritos": {
    "en": "Favorites",
    "es": "Favoritos"
  },
  "Hecho": {
    "en": "Done",
    "es": "Hecho"
  },
  "Idioma": {
    "en": "Language",
    "es": "Idioma"
  },
  "Llave de administración": {
    "en": "Admin key",
    "es": "Llave de administración"
  },
  "Llave de seguridad": {
    "en": "Safe key",
    "es": "Llave de seguridad"
  },
  "Llaves": {
    "en": "Keys",
    "es": "Llaves"
  },
  "Los enlaces se ordenan por su prioridad, de mayor a menor, y por la fecha en la que han sido agregados.": {
    "en": "The links are ordered by their priority and then by the addition date",
    "es": "Los enlaces se ordenan por su prioridad, de mayor a menor, y por la fecha en la que han sido agregados."
  },
  "Mostrar": {
    "en": "Show",
    "es": "Mostrar"
  },
  "Ocultar": {
    "en": "Hide",
    "es": "Ocultar"
  },
  "Olvidar": {
    "en": "Forget",
    "es": "Olvidar"
  },
  "organiza las": {
    "en": "organize the",
    "es": "organiza las"
  },
  "Prioridad": {
    "en": "Priority",
    "es": "Prioridad"
  },
  "Ranking": {
    "en": "Ranking",
    "es": "Ranking"
  },
  "Rechazar": {
    "en": "Refuse",
    "es": "Rechazar"
  },
  "Recordar": {
    "en": "Remember",
    "es": "Recordar"
  },
  "Siguiente": {
    "en": "Next",
    "es": "Siguiente"
  },
  "Tienes que indicar un título para poder continuar": {
    "en": "You need to add a title to continue",
    "es": "Tienes que indicar un título para poder continuar"
  },
  "Titulo": {
    "en": "Title",
    "es": "Titulo"
  },
  "Una vez creado el clip, no se podrá modificar su título ni su url.": {
    "en": "After created, the title cannot be altered",
    "es": "Una vez creado el clip, no se podrá modificar su título ni su url."
  },
  "Ver clip": {
    "en": "View clip",
    "es": "Ver clip"
  },
  "Ya hay un clip con esa url": {
    "en": "A clip exists with this url",
    "es": "Ya hay un clip con esa url"
  },
  "Ya hay un clip con ese título": {
    "en": "A clip exists with this title",
    "es": "Ya hay un clip con ese título"
  },
  "redes": {
    "en": "networks",
    "es": "redes"
  }
};
const idiomas = {
  "en": 1,
  "es": 1
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"varios.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/varios.js                                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  tituloAUrl: () => tituloAUrl
});
const diacriticas = {
  á: 'a',
  é: 'e',
  í: 'i',
  ó: 'o',
  ú: 'u',
  ñ: 'n',
  ç: 'c'
};

const tituloAUrl = function tituloAUrl(titulo) {
  return (titulo || '').toLowerCase().replace(/[ ]/g, '-').replace(/[áéíúóüñ]/g, function (letra) {
    return diacriticas[letra];
  }).replace(/[^a-z0-9 _.-]/g, '');
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"clip.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/clip.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 1);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 2);
let salirValidacion, salir;
module.link("/server/comun", {
  salirValidacion(v) {
    salirValidacion = v;
  },

  salir(v) {
    salir = v;
  }

}, 3);
let tituloAUrl;
module.link("/common/varios", {
  tituloAUrl(v) {
    tituloAUrl = v;
  }

}, 4);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 5);
const validaciones = {
  cambiarPrioridad: Joi.object().keys({
    clipId: Joi.string().required(),
    postId: Joi.string().required(),
    secreto: Joi.string().required(),
    prioridad: Joi.number().required()
  }),
  revocar: Joi.object().keys({
    clipId: Joi.string().required(),
    seguridad: Joi.string().required(),
    llave: Joi.string().valid(['seguridad', 'secreto']).required()
  }),
  obtenerSecreto: Joi.object().keys({
    clipId: Joi.string().required(),
    seguridad: Joi.string().required()
  }),
  establecerStatus: Joi.object().keys({
    clipId: Joi.string().required(),
    postId: Joi.string().required(),
    secreto: Joi.string().required(),
    status: Joi.string().valid(['RECHAZADO', 'OCULTO', 'VISIBLE']).required()
  }),
  eliminarPost: Joi.object().keys({
    clipId: Joi.string().required(),
    postId: Joi.string().required(),
    secreto: Joi.string().required()
  }),
  clipPublish: Joi.object().keys({
    url: Joi.string().regex(/^[a-z-]+$/).required(),
    secreto: Joi.string()
  }),
  clipIdPublish: Joi.object().keys({
    clipId: Joi.string().required(),
    secreto: Joi.string().required()
  }),
  agregarLink: Joi.object().keys({
    url: Joi.string().regex(/^[a-z-]+$/).required(),
    link: Joi.string().required(),
    OG: Joi.object().required()
  }),
  titulo: Joi.string()
};
Meteor.methods({
  crearClip(titulo) {
    salirValidacion({
      data: titulo,
      schema: validaciones.titulo,
      debug: {
        donde: 'method crearClip'
      }
    });

    if (clips.find({
      titulo
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'titulo repetido');
    }

    const url = tituloAUrl(titulo);

    if (clips.find({
      url
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'url repetida');
    }

    const secreto = Random.secret();
    const seguridad = Random.secret();
    const clipId = clips.insert({
      creacion: new Date(),
      titulo,
      url,
      secreto,
      seguridad
    });
    return {
      clipId,
      secreto,
      seguridad
    };
  },

  agregarLink(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.agregarLink,
      debug: {
        donde: 'method agregarLink'
      }
    });
    const clip = clips.findOne({
      url: opciones.url
    }) || salir(404, 'Clip no encontrado', {
      donde: 'method agregarLink'
    });

    if (posts.findOne({
      clipId: clip._id,
      link: opciones.link
    })) {
      return;
    }

    posts.insert({
      clipId: clip._id,
      OG: opciones.OG,
      link: opciones.link,
      timestamp: new Date(),
      status: 'PENDIENTE',
      prioridad: 0
    });

    if (opciones.secreto) {
      clips.update({
        _id: clip._id
      }, {
        $inc: {
          posts: 1
        }
      });
    }
  },

  cambiarPrioridad(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.cambiarPrioridad,
      debug: {
        donde: 'method cambiarPrioridad'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method establecerStatus'
    });
    clips.find({
      _id: opciones.clipId,
      secreto: opciones.secreto
    }).count() || salir(401, 'No tienes permiso para administrar el clip', {
      donde: 'method establecerStatus'
    });
    posts.find({
      _id: opciones.postId,
      clipId: opciones.clipId
    }).count() || salir(404, 'Post no encontrado');
    posts.update(opciones.postId, {
      $set: {
        prioridad: opciones.prioridad
      }
    });
  },

  testTitulo(titulo) {
    salirValidacion({
      data: titulo,
      schema: validaciones.titulo,
      debug: {
        donde: 'method testTitulo'
      }
    }); // if (clips.find({
    //   titulo
    // }, {
    //   limit: 1
    // }).count()) {
    //   console.log('titulo repetido')
    //   throw new Meteor.Error(400, 'titulo repetido')
    // }

    const url = tituloAUrl(titulo);

    if (clips.find({
      url
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'url repetida');
    }
  },

  establecerStatus(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.establecerStatus,
      debug: {
        donde: 'method establecerStatus'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method establecerStatus'
    });
    clips.find({
      _id: opciones.clipId,
      secreto: opciones.secreto
    }).count() || salir(401, 'No tienes permiso para administrar el clip', {
      donde: 'method establecerStatus'
    });
    posts.find({
      _id: opciones.postId,
      clipId: opciones.clipId
    }).count() || salir(404, 'Post no encontrado');
    posts.update(opciones.postId, {
      $set: {
        status: opciones.status
      }
    });
  },

  eliminarPost(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.eliminarPost,
      debug: {
        donde: 'method establecerStatus'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method establecerStatus'
    });
    clips.find({
      _id: opciones.clipId,
      secreto: opciones.secreto
    }).count() || salir(401, 'No tienes permiso para administrar el clip', {
      donde: 'method establecerStatus'
    });
    posts.find({
      _id: opciones.postId,
      clipId: opciones.clipId
    }).count() || salir(404, 'Post no encontrado');
    posts.remove(opciones.postId);
  },

  revocar(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.revocar,
      debug: {
        donde: 'method revocar'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method revocar'
    });
    clips.find({
      _id: opciones.clipId,
      seguridad: opciones.seguridad
    }).count() || salir(400, 'No tienes permiso para revocar llaves', {
      donde: 'method revocar'
    });
    const llave = Random.secret();
    clips.update(opciones.clipId, {
      $set: {
        [opciones.llave]: llave
      }
    });
    return llave;
  },

  obtenerSecreto(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.obtenerSecreto,
      debug: {
        donde: 'method obtenerSecreto'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method revocar'
    });
    const clip = clips.findOne({
      _id: opciones.clipId,
      seguridad: opciones.seguridad
    }) || salir(401, 'No tienes permiso para obtener la llave de administración', {
      donde: 'method revocar'
    });
    return clip.secreto;
  }

});
Meteor.publish('clip', function (opciones) {
  salirValidacion({
    data: opciones,
    schema: validaciones.clipPublish,
    debug: {
      donde: 'publish clip'
    }
  });
  const clip = clips.findOne({
    url: opciones.url
  }) || salir(404, 'Clip no encontrado', {
    donde: 'publish clip'
  });
  opciones.secreto && clip.secreto !== opciones.secreto && salir(401, 'No tienes permiso', {
    donde: 'publish clip'
  });
  const postsQuery = {
    clipId: clip._id
  };

  if (!opciones.secreto) {
    postsQuery.status = 'VISIBLE';
  }

  return [clips.find(clip._id, {
    fields: {
      seguridad: 0,
      secreto: 0
    }
  }), posts.find(postsQuery)];
});
Meteor.publish('clipId', function (opciones) {
  salirValidacion({
    data: opciones,
    schema: validaciones.clipIdPublish,
    debug: {
      donde: 'publish clipId'
    }
  });
  return clips.find({
    _id: opciones.clipId,
    secreto: opciones.secreto
  }, {
    fields: {
      seguridad: 0,
      secreto: 0
    }
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comun.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/comun.js                                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  salir: () => salir,
  salirValidacion: () => salirValidacion
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 1);

const salir = function salir(codigo, mensaje, debug) {
  if (debug) {
    console.log(codigo, mensaje);
    console.log(JSON.stringify(debug, null, 2));
  }

  throw new Meteor.Error(codigo, mensaje);
};

const salirValidacion = function (opciones) {
  const validacion = Joi.validate(opciones.data, opciones.schema);

  if (!validacion.error) {
    return;
  }

  opciones = Object.assign({
    codigo: 400,
    mensaje: validacion.error.details[0].message
  }, opciones);

  if (opciones.debug) {
    opciones.debug.details = validacion.error.details;
    opciones.debug._object = validacion.error._object;
  }

  salir(opciones.codigo, opciones.mensaje, opciones.debug);
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"externo.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/externo.js                                                                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let cheerio;
module.link("cheerio", {
  default(v) {
    cheerio = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 3);
let moment;
module.link("moment", {
  default(v) {
    moment = v;
  }

}, 4);
let ogs;
module.link("open-graph-scraper", {
  default(v) {
    ogs = v;
  }

}, 5);
const meteorOGS = Meteor.wrapAsync(function (opciones, callback) {
  ogs(opciones, function (e, r, h) {
    callback(e, [r, cheerio.load(h ? h.body : opciones.html)]);
  });
});
const rrss = {
  Instagram: {
    obtenerApoyos($, response) {
      response.data.crLikes = JSON.parse($('script[type="application/ld+json"]').html()).interactionStatistic.userInteractionCount;
      response.data.ogDescription = response.data.ogTitle.replace(/^.*?on Instagram: /, '');
      response.data.ogTitle = response.data.ogTitle.replace(/on Instagram:.*$/, '');
      return response;
    }

  },
  YouTube: {
    regex: /(^|=|\/)([0-9A-Za-z_-]{11})(\/|&|$|\?|#)/,

    obtenerApoyos($, response) {
      const youtube = response.data.ogUrl.match(rrss.YouTube.regex);

      if (!youtube) {
        return response;
      }

      const data = JSON.parse(HTTP.get(`https://www.googleapis.com/youtube/v3/videos?id=${youtube[2]}&key=${Meteor.settings.private.youtubeAPI}&part=statistics`).content).items[0].statistics;
      response.data.crLikes = data.likeCount - data.dislikeCount;
      return response;
    }

  },
  Twitter: {
    obtenerApoyos($, response) {
      var stats = $('ul.stats');
      const retweeted = (stats.find('.request-retweeted-popup').data() || {
        tweetStatCount: 0
      }).tweetStatCount * 1;
      const favorited = (stats.find('.request-favorited-popup').data() || {
        tweetStatCount: 0
      }).tweetStatCount * 1;
      response.data.crLikes = retweeted + favorited;
      response.data.ogTitle = response.data.ogTitle.replace(/on Twitter$/, '');
      return response;
    }

  },
  reddit: {
    obtenerApoyos($, response) {
      response.data.crLikes = parseInt(response.data.ogDescription.replace(/ .*$/, '').replace(/,/, ''));
      response.data.ogDescription = response.data.ogTitle.replace(/^.*?- /, '');
      response.data.ogTitle = response.data.ogTitle.replace(/ - .*$/, '');
      return response;
    }

  },
  Vimeo: {
    obtenerApoyos($, response) {
      const data = JSON.parse(HTTP.get(`${response.data.ogUrl}?action=load_stat_counts`, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:67.0) Gecko/20100101 Firefox/67.0',
          'Referer': response.data.ogUrl,
          'X-Requested-With': 'XMLHttpRequest'
        }
      }).content);
      response.data.crLikes = data.total_likes.raw;
      return response;
    }

  },
  '@meneame_net': {
    obtenerApoyos($, response) {
      const votos = parseInt($('#newswrap').find('.votes').find('a').text());
      response.data.crLikes = votos || 0;
      return response;
    }

  }
};

const actualizar = function actualizar(url) {
  var response;
  var html;
  var opciones;

  if (url.match(/https:\/\/www.facebook/)) {
    opciones = {
      html: HTTP.get(url, {
        headers: {
          'User-Agent': 'FeedFetcher-Google; (+http://www.google.com/feedfetcher.html)'
        }
      }).content
    };
  } else {
    opciones = {
      url
    };
  }

  [response, html] = meteorOGS(opciones);

  if (url.match(/https:\/\/www.facebook/)) {
    response.data.ogSiteName = 'Facebook';
  }

  if (rrss[response.data.ogSiteName || response.data.twitterSite]) {
    return rrss[response.data.ogSiteName || response.data.twitterSite].obtenerApoyos(html, response);
  }

  return response;
};

Meteor.methods({
  actualizarApoyos(clipId, forzar) {
    if (!forzar && clips.findOne({
      _id: clipId,
      actualizacion: {
        $gt: moment().subtract(1, 'hour').toDate()
      }
    })) {
      return;
    }

    var apoyos = 0;
    posts.find({
      clipId,
      status: 'VISIBLE'
    }).forEach(post => {
      const response = actualizar(post.link);
      posts.update({
        _id: post._id
      }, {
        $set: {
          OG: response.data
        }
      });
      apoyos += (response.data.crLikes || 0) * 1;
    });
    clips.update({
      _id: clipId
    }, {
      $set: {
        apoyos,
        actualizacion: new Date()
      }
    });
  },

  previsualizar(url) {
    return actualizar(url);
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"listas.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/listas.js                                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 1);
let salirValidacion;
module.link("/server/comun", {
  salirValidacion(v) {
    salirValidacion = v;
  }

}, 2);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 3);
const validaciones = {
  primerPost: Joi.string()
};
Meteor.publish('ranking', function (pagina = 0) {
  return clips.find({
    posts: {
      $gt: 0
    }
  }, {
    fields: {
      secreto: 0,
      seguridad: 0
    },
    sort: {
      apoyos: -1
    },
    skip: 10 * pagina,
    limit: 10
  });
});
Meteor.publish('busqueda', function (busqueda, pagina = 0) {
  var regex = /(?:)/;

  try {
    regex = new RegExp(busqueda);
  } catch (e) {
    regex = /$^/;
  }

  return clips.find({
    titulo: regex,
    posts: {
      $gt: 0
    }
  }, {
    fields: {
      secreto: 0,
      seguridad: 0
    },
    sort: {
      apoyos: -1
    },
    skip: 10 * pagina,
    limit: 10
  });
});
Meteor.publish('primerPost', function (clipId) {
  salirValidacion({
    data: clipId,
    schema: validaciones.primerPost,
    debug: {
      donde: 'publish clip'
    }
  });
  return posts.find({
    clipId,
    status: 'VISIBLE'
  }, {
    sort: {
      prioridad: -1,
      timestamp: -1
    },
    limit: 1
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/common/baseDeDatos.js");
require("/common/traducciones.js");
require("/common/varios.js");
require("/server/clip.js");
require("/server/comun.js");
require("/server/externo.js");
require("/server/listas.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29tbW9uL2Jhc2VEZURhdG9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb21tb24vdHJhZHVjY2lvbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb21tb24vdmFyaW9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY2xpcC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbXVuLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZXh0ZXJuby5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2xpc3Rhcy5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJjbGlwcyIsInBvc3RzIiwibWlzQ2xpcHMiLCJNb25nbyIsImxpbmsiLCJ2IiwiTWV0ZW9yIiwiQ29sbGVjdGlvbiIsImlzQ2xpZW50IiwiUGVyc2lzdGVudE1pbmltb25nbzIiLCJpc0RldmVsb3BtZW50IiwiZ2xvYmFsIiwidHJhZHVjY2lvbmVzIiwiaWRpb21hcyIsInRpdHVsb0FVcmwiLCJkaWFjcml0aWNhcyIsIsOhIiwiw6kiLCLDrSIsIsOzIiwiw7oiLCLDsSIsIsOnIiwidGl0dWxvIiwidG9Mb3dlckNhc2UiLCJyZXBsYWNlIiwibGV0cmEiLCJSYW5kb20iLCJzYWxpclZhbGlkYWNpb24iLCJzYWxpciIsIkpvaSIsImRlZmF1bHQiLCJ2YWxpZGFjaW9uZXMiLCJjYW1iaWFyUHJpb3JpZGFkIiwib2JqZWN0Iiwia2V5cyIsImNsaXBJZCIsInN0cmluZyIsInJlcXVpcmVkIiwicG9zdElkIiwic2VjcmV0byIsInByaW9yaWRhZCIsIm51bWJlciIsInJldm9jYXIiLCJzZWd1cmlkYWQiLCJsbGF2ZSIsInZhbGlkIiwib2J0ZW5lclNlY3JldG8iLCJlc3RhYmxlY2VyU3RhdHVzIiwic3RhdHVzIiwiZWxpbWluYXJQb3N0IiwiY2xpcFB1Ymxpc2giLCJ1cmwiLCJyZWdleCIsImNsaXBJZFB1Ymxpc2giLCJhZ3JlZ2FyTGluayIsIk9HIiwibWV0aG9kcyIsImNyZWFyQ2xpcCIsImRhdGEiLCJzY2hlbWEiLCJkZWJ1ZyIsImRvbmRlIiwiZmluZCIsImxpbWl0IiwiY291bnQiLCJFcnJvciIsInNlY3JldCIsImluc2VydCIsImNyZWFjaW9uIiwiRGF0ZSIsIm9wY2lvbmVzIiwiY2xpcCIsImZpbmRPbmUiLCJfaWQiLCJ0aW1lc3RhbXAiLCJ1cGRhdGUiLCIkaW5jIiwiJHNldCIsInRlc3RUaXR1bG8iLCJyZW1vdmUiLCJwdWJsaXNoIiwicG9zdHNRdWVyeSIsImZpZWxkcyIsImNvZGlnbyIsIm1lbnNhamUiLCJjb25zb2xlIiwibG9nIiwiSlNPTiIsInN0cmluZ2lmeSIsInZhbGlkYWNpb24iLCJ2YWxpZGF0ZSIsImVycm9yIiwiT2JqZWN0IiwiYXNzaWduIiwiZGV0YWlscyIsIm1lc3NhZ2UiLCJfb2JqZWN0IiwiY2hlZXJpbyIsIkhUVFAiLCJtb21lbnQiLCJvZ3MiLCJtZXRlb3JPR1MiLCJ3cmFwQXN5bmMiLCJjYWxsYmFjayIsImUiLCJyIiwiaCIsImxvYWQiLCJib2R5IiwiaHRtbCIsInJyc3MiLCJJbnN0YWdyYW0iLCJvYnRlbmVyQXBveW9zIiwiJCIsInJlc3BvbnNlIiwiY3JMaWtlcyIsInBhcnNlIiwiaW50ZXJhY3Rpb25TdGF0aXN0aWMiLCJ1c2VySW50ZXJhY3Rpb25Db3VudCIsIm9nRGVzY3JpcHRpb24iLCJvZ1RpdGxlIiwiWW91VHViZSIsInlvdXR1YmUiLCJvZ1VybCIsIm1hdGNoIiwiZ2V0Iiwic2V0dGluZ3MiLCJwcml2YXRlIiwieW91dHViZUFQSSIsImNvbnRlbnQiLCJpdGVtcyIsInN0YXRpc3RpY3MiLCJsaWtlQ291bnQiLCJkaXNsaWtlQ291bnQiLCJUd2l0dGVyIiwic3RhdHMiLCJyZXR3ZWV0ZWQiLCJ0d2VldFN0YXRDb3VudCIsImZhdm9yaXRlZCIsInJlZGRpdCIsInBhcnNlSW50IiwiVmltZW8iLCJoZWFkZXJzIiwidG90YWxfbGlrZXMiLCJyYXciLCJ2b3RvcyIsInRleHQiLCJhY3R1YWxpemFyIiwib2dTaXRlTmFtZSIsInR3aXR0ZXJTaXRlIiwiYWN0dWFsaXphckFwb3lvcyIsImZvcnphciIsImFjdHVhbGl6YWNpb24iLCIkZ3QiLCJzdWJ0cmFjdCIsInRvRGF0ZSIsImFwb3lvcyIsImZvckVhY2giLCJwb3N0IiwicHJldmlzdWFsaXphciIsInByaW1lclBvc3QiLCJwYWdpbmEiLCJzb3J0Iiwic2tpcCIsImJ1c3F1ZWRhIiwiUmVnRXhwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxPQUFLLEVBQUMsTUFBSUEsS0FBWDtBQUFpQkMsT0FBSyxFQUFDLE1BQUlBLEtBQTNCO0FBQWlDQyxVQUFRLEVBQUMsTUFBSUE7QUFBOUMsQ0FBZDtBQUF1RSxJQUFJQyxLQUFKO0FBQVVMLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0QsT0FBSyxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsU0FBSyxHQUFDRSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlDLE1BQUo7QUFBV1IsTUFBTSxDQUFDTSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFHdkksTUFBTUwsS0FBSyxHQUFHLElBQUlHLEtBQUssQ0FBQ0ksVUFBVixDQUFxQixPQUFyQixDQUFkO0FBQ0EsTUFBTU4sS0FBSyxHQUFHLElBQUlFLEtBQUssQ0FBQ0ksVUFBVixDQUFxQixPQUFyQixDQUFkO0FBQ0EsSUFBSUwsUUFBSjs7QUFFUCxJQUFJSSxNQUFNLENBQUNFLFFBQVgsRUFBcUI7QUFDbkIsb0JBQUFOLFFBQVEsR0FBRyxJQUFJQyxLQUFLLENBQUNJLFVBQVYsQ0FBcUIsSUFBckIsQ0FBWDtBQUNBOztBQUNBLE1BQUlFLG9CQUFKLENBQXlCUCxRQUF6QixFQUFtQyxVQUFuQztBQUNEOztBQUVELElBQUlJLE1BQU0sQ0FBQ0ksYUFBWCxFQUEwQjtBQUN4QkMsUUFBTSxDQUFDVCxRQUFQLEdBQWtCQSxRQUFsQjtBQUNBUyxRQUFNLENBQUNYLEtBQVAsR0FBZUEsS0FBZjtBQUNBVyxRQUFNLENBQUNWLEtBQVAsR0FBZUEsS0FBZjtBQUNELEM7Ozs7Ozs7Ozs7O0FDakJESCxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDYSxjQUFZLEVBQUMsTUFBSUEsWUFBbEI7QUFBK0JDLFNBQU8sRUFBQyxNQUFJQTtBQUEzQyxDQUFkO0FBRU8sTUFBTUQsWUFBWSxHQUFHO0FBQzFCLGFBQVc7QUFDVCxVQUFNLFFBREc7QUFFVCxVQUFNO0FBRkcsR0FEZTtBQUsxQiw2QkFBMkI7QUFDekIsVUFBTSxvQkFEbUI7QUFFekIsVUFBTTtBQUZtQixHQUxEO0FBUzFCLGFBQVc7QUFDVCxVQUFNLEtBREc7QUFFVCxVQUFNO0FBRkcsR0FUZTtBQWExQixvQkFBa0I7QUFDaEIsVUFBTSxVQURVO0FBRWhCLFVBQU07QUFGVSxHQWJRO0FBaUIxQixhQUFXO0FBQ1QsVUFBTSxTQURHO0FBRVQsVUFBTTtBQUZHLEdBakJlO0FBcUIxQixXQUFTO0FBQ1AsVUFBTSxNQURDO0FBRVAsVUFBTTtBQUZDLEdBckJpQjtBQXlCMUIsaUJBQWU7QUFDYixVQUFNLGFBRE87QUFFYixVQUFNO0FBRk8sR0F6Qlc7QUE2QjFCLGVBQWE7QUFDWCxVQUFNLFFBREs7QUFFWCxVQUFNO0FBRkssR0E3QmE7QUFpQzFCLGNBQVk7QUFDVixVQUFNLFFBREk7QUFFVixVQUFNO0FBRkksR0FqQ2M7QUFxQzFCLGdCQUFjO0FBQ1osVUFBTSxZQURNO0FBRVosVUFBTTtBQUZNLEdBckNZO0FBeUMxQixlQUFhO0FBQ1gsVUFBTSxPQURLO0FBRVgsVUFBTTtBQUZLLEdBekNhO0FBNkMxQixpREFBK0M7QUFDN0MsVUFBTSxtQ0FEdUM7QUFFN0MsVUFBTTtBQUZ1QyxHQTdDckI7QUFpRDFCLGdGQUE4RTtBQUM1RSxVQUFNLG9DQURzRTtBQUU1RSxVQUFNO0FBRnNFLEdBakRwRDtBQXFEMUIsV0FBUztBQUNQLFVBQU0sUUFEQztBQUVQLFVBQU07QUFGQyxHQXJEaUI7QUF5RDFCLGdCQUFjO0FBQ1osVUFBTSxhQURNO0FBRVosVUFBTTtBQUZNLEdBekRZO0FBNkQxQixjQUFZO0FBQ1YsVUFBTSxRQURJO0FBRVYsVUFBTTtBQUZJLEdBN0RjO0FBaUUxQixvQ0FBa0M7QUFDaEMsVUFBTSw0QkFEMEI7QUFFaEMsVUFBTTtBQUYwQixHQWpFUjtBQXFFMUIsZUFBYTtBQUNYLFVBQU0sV0FESztBQUVYLFVBQU07QUFGSyxHQXJFYTtBQXlFMUIsV0FBUztBQUNQLFVBQU0sTUFEQztBQUVQLFVBQU07QUFGQyxHQXpFaUI7QUE2RTFCLFlBQVU7QUFDUixVQUFNLFVBREU7QUFFUixVQUFNO0FBRkUsR0E3RWdCO0FBaUYxQiw2QkFBMkI7QUFDekIsVUFBTSxXQURtQjtBQUV6QixVQUFNO0FBRm1CLEdBakZEO0FBcUYxQix3QkFBc0I7QUFDcEIsVUFBTSxVQURjO0FBRXBCLFVBQU07QUFGYyxHQXJGSTtBQXlGMUIsWUFBVTtBQUNSLFVBQU0sTUFERTtBQUVSLFVBQU07QUFGRSxHQXpGZ0I7QUE2RjFCLDZHQUEyRztBQUN6RyxVQUFNLHVFQURtRztBQUV6RyxVQUFNO0FBRm1HLEdBN0ZqRjtBQWlHMUIsYUFBVztBQUNULFVBQU0sTUFERztBQUVULFVBQU07QUFGRyxHQWpHZTtBQXFHMUIsYUFBVztBQUNULFVBQU0sTUFERztBQUVULFVBQU07QUFGRyxHQXJHZTtBQXlHMUIsYUFBVztBQUNULFVBQU0sUUFERztBQUVULFVBQU07QUFGRyxHQXpHZTtBQTZHMUIsa0JBQWdCO0FBQ2QsVUFBTSxjQURRO0FBRWQsVUFBTTtBQUZRLEdBN0dVO0FBaUgxQixlQUFhO0FBQ1gsVUFBTSxVQURLO0FBRVgsVUFBTTtBQUZLLEdBakhhO0FBcUgxQixhQUFXO0FBQ1QsVUFBTSxTQURHO0FBRVQsVUFBTTtBQUZHLEdBckhlO0FBeUgxQixjQUFZO0FBQ1YsVUFBTSxRQURJO0FBRVYsVUFBTTtBQUZJLEdBekhjO0FBNkgxQixjQUFZO0FBQ1YsVUFBTSxVQURJO0FBRVYsVUFBTTtBQUZJLEdBN0hjO0FBaUkxQixlQUFhO0FBQ1gsVUFBTSxNQURLO0FBRVgsVUFBTTtBQUZLLEdBaklhO0FBcUkxQix1REFBcUQ7QUFDbkQsVUFBTSxxQ0FENkM7QUFFbkQsVUFBTTtBQUY2QyxHQXJJM0I7QUF5STFCLFlBQVU7QUFDUixVQUFNLE9BREU7QUFFUixVQUFNO0FBRkUsR0F6SWdCO0FBNkkxQix3RUFBc0U7QUFDcEUsVUFBTSw0Q0FEOEQ7QUFFcEUsVUFBTTtBQUY4RCxHQTdJNUM7QUFpSjFCLGNBQVk7QUFDVixVQUFNLFdBREk7QUFFVixVQUFNO0FBRkksR0FqSmM7QUFxSjFCLGdDQUE4QjtBQUM1QixVQUFNLDZCQURzQjtBQUU1QixVQUFNO0FBRnNCLEdBckpKO0FBeUoxQixtQ0FBaUM7QUFDL0IsVUFBTSwrQkFEeUI7QUFFL0IsVUFBTTtBQUZ5QixHQXpKUDtBQTZKMUIsV0FBUztBQUNQLFVBQU0sVUFEQztBQUVQLFVBQU07QUFGQztBQTdKaUIsQ0FBckI7QUFtS0EsTUFBTUMsT0FBTyxHQUFHO0FBQ3JCLFFBQU0sQ0FEZTtBQUVyQixRQUFNO0FBRmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNyS1BmLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNlLFlBQVUsRUFBQyxNQUFJQTtBQUFoQixDQUFkO0FBQUEsTUFBTUMsV0FBVyxHQUFHO0FBQ2xCQyxHQUFDLEVBQUUsR0FEZTtBQUVsQkMsR0FBQyxFQUFFLEdBRmU7QUFHbEJDLEdBQUMsRUFBRSxHQUhlO0FBSWxCQyxHQUFDLEVBQUUsR0FKZTtBQUtsQkMsR0FBQyxFQUFFLEdBTGU7QUFNbEJDLEdBQUMsRUFBRSxHQU5lO0FBT2xCQyxHQUFDLEVBQUU7QUFQZSxDQUFwQjs7QUFVTyxNQUFNUixVQUFVLEdBQUcsU0FBU0EsVUFBVCxDQUFxQlMsTUFBckIsRUFBNkI7QUFDckQsU0FBTyxDQUFDQSxNQUFNLElBQUksRUFBWCxFQUFlQyxXQUFmLEdBQTZCQyxPQUE3QixDQUFxQyxNQUFyQyxFQUE2QyxHQUE3QyxFQUFrREEsT0FBbEQsQ0FBMEQsWUFBMUQsRUFBd0UsVUFBVUMsS0FBVixFQUFpQjtBQUM5RixXQUFPWCxXQUFXLENBQUNXLEtBQUQsQ0FBbEI7QUFDRCxHQUZNLEVBRUpELE9BRkksQ0FFSSxnQkFGSixFQUVzQixFQUZ0QixDQUFQO0FBR0QsQ0FKTSxDOzs7Ozs7Ozs7OztBQ1ZQLElBQUluQixNQUFKO0FBQVdSLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlzQixNQUFKO0FBQVc3QixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUN1QixRQUFNLENBQUN0QixDQUFELEVBQUc7QUFBQ3NCLFVBQU0sR0FBQ3RCLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUwsS0FBSixFQUFVQyxLQUFWO0FBQWdCSCxNQUFNLENBQUNNLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDSixPQUFLLENBQUNLLENBQUQsRUFBRztBQUFDTCxTQUFLLEdBQUNLLENBQU47QUFBUSxHQUFsQjs7QUFBbUJKLE9BQUssQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNKLFNBQUssR0FBQ0ksQ0FBTjtBQUFROztBQUFwQyxDQUFsQyxFQUF3RSxDQUF4RTtBQUEyRSxJQUFJdUIsZUFBSixFQUFvQkMsS0FBcEI7QUFBMEIvQixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUN3QixpQkFBZSxDQUFDdkIsQ0FBRCxFQUFHO0FBQUN1QixtQkFBZSxHQUFDdkIsQ0FBaEI7QUFBa0IsR0FBdEM7O0FBQXVDd0IsT0FBSyxDQUFDeEIsQ0FBRCxFQUFHO0FBQUN3QixTQUFLLEdBQUN4QixDQUFOO0FBQVE7O0FBQXhELENBQTVCLEVBQXNGLENBQXRGO0FBQXlGLElBQUlTLFVBQUo7QUFBZWhCLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNVLFlBQVUsQ0FBQ1QsQ0FBRCxFQUFHO0FBQUNTLGNBQVUsR0FBQ1QsQ0FBWDtBQUFhOztBQUE1QixDQUE3QixFQUEyRCxDQUEzRDtBQUE4RCxJQUFJeUIsR0FBSjtBQUFRaEMsTUFBTSxDQUFDTSxJQUFQLENBQVksS0FBWixFQUFrQjtBQUFDMkIsU0FBTyxDQUFDMUIsQ0FBRCxFQUFHO0FBQUN5QixPQUFHLEdBQUN6QixDQUFKO0FBQU07O0FBQWxCLENBQWxCLEVBQXNDLENBQXRDO0FBUW5hLE1BQU0yQixZQUFZLEdBQUc7QUFDbkJDLGtCQUFnQixFQUFFSCxHQUFHLENBQUNJLE1BQUosR0FBYUMsSUFBYixDQUFrQjtBQUNsQ0MsVUFBTSxFQUFFTixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUQwQjtBQUVsQ0MsVUFBTSxFQUFFVCxHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUYwQjtBQUdsQ0UsV0FBTyxFQUFFVixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUh5QjtBQUlsQ0csYUFBUyxFQUFFWCxHQUFHLENBQUNZLE1BQUosR0FBYUosUUFBYjtBQUp1QixHQUFsQixDQURDO0FBT25CSyxTQUFPLEVBQUViLEdBQUcsQ0FBQ0ksTUFBSixHQUFhQyxJQUFiLENBQWtCO0FBQ3pCQyxVQUFNLEVBQUVOLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRGlCO0FBRXpCTSxhQUFTLEVBQUVkLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRmM7QUFHekJPLFNBQUssRUFBRWYsR0FBRyxDQUFDTyxNQUFKLEdBQWFTLEtBQWIsQ0FBbUIsQ0FBQyxXQUFELEVBQWMsU0FBZCxDQUFuQixFQUE2Q1IsUUFBN0M7QUFIa0IsR0FBbEIsQ0FQVTtBQVluQlMsZ0JBQWMsRUFBRWpCLEdBQUcsQ0FBQ0ksTUFBSixHQUFhQyxJQUFiLENBQWtCO0FBQ2hDQyxVQUFNLEVBQUVOLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRHdCO0FBRWhDTSxhQUFTLEVBQUVkLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiO0FBRnFCLEdBQWxCLENBWkc7QUFnQm5CVSxrQkFBZ0IsRUFBRWxCLEdBQUcsQ0FBQ0ksTUFBSixHQUFhQyxJQUFiLENBQWtCO0FBQ2xDQyxVQUFNLEVBQUVOLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRDBCO0FBRWxDQyxVQUFNLEVBQUVULEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRjBCO0FBR2xDRSxXQUFPLEVBQUVWLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBSHlCO0FBSWxDVyxVQUFNLEVBQUVuQixHQUFHLENBQUNPLE1BQUosR0FBYVMsS0FBYixDQUFtQixDQUFDLFdBQUQsRUFBYyxRQUFkLEVBQXdCLFNBQXhCLENBQW5CLEVBQXVEUixRQUF2RDtBQUowQixHQUFsQixDQWhCQztBQXNCbkJZLGNBQVksRUFBRXBCLEdBQUcsQ0FBQ0ksTUFBSixHQUFhQyxJQUFiLENBQWtCO0FBQzlCQyxVQUFNLEVBQUVOLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRHNCO0FBRTlCQyxVQUFNLEVBQUVULEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRnNCO0FBRzlCRSxXQUFPLEVBQUVWLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiO0FBSHFCLEdBQWxCLENBdEJLO0FBMkJuQmEsYUFBVyxFQUFFckIsR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDN0JpQixPQUFHLEVBQUV0QixHQUFHLENBQUNPLE1BQUosR0FBYWdCLEtBQWIsQ0FBbUIsV0FBbkIsRUFBZ0NmLFFBQWhDLEVBRHdCO0FBRTdCRSxXQUFPLEVBQUVWLEdBQUcsQ0FBQ08sTUFBSjtBQUZvQixHQUFsQixDQTNCTTtBQStCbkJpQixlQUFhLEVBQUV4QixHQUFHLENBQUNJLE1BQUosR0FBYUMsSUFBYixDQUFrQjtBQUMvQkMsVUFBTSxFQUFFTixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUR1QjtBQUUvQkUsV0FBTyxFQUFFVixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYjtBQUZzQixHQUFsQixDQS9CSTtBQW1DbkJpQixhQUFXLEVBQUV6QixHQUFHLENBQUNJLE1BQUosR0FBYUMsSUFBYixDQUFrQjtBQUM3QmlCLE9BQUcsRUFBRXRCLEdBQUcsQ0FBQ08sTUFBSixHQUFhZ0IsS0FBYixDQUFtQixXQUFuQixFQUFnQ2YsUUFBaEMsRUFEd0I7QUFFN0JsQyxRQUFJLEVBQUUwQixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUZ1QjtBQUc3QmtCLE1BQUUsRUFBRTFCLEdBQUcsQ0FBQ0ksTUFBSixHQUFhSSxRQUFiO0FBSHlCLEdBQWxCLENBbkNNO0FBd0NuQmYsUUFBTSxFQUFFTyxHQUFHLENBQUNPLE1BQUo7QUF4Q1csQ0FBckI7QUEyQ0EvQixNQUFNLENBQUNtRCxPQUFQLENBQWU7QUFDYkMsV0FBUyxDQUFFbkMsTUFBRixFQUFVO0FBQ2pCSyxtQkFBZSxDQUFDO0FBQ2QrQixVQUFJLEVBQUVwQyxNQURRO0FBRWRxQyxZQUFNLEVBQUU1QixZQUFZLENBQUNULE1BRlA7QUFHZHNDLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZjs7QUFRQSxRQUFJOUQsS0FBSyxDQUFDK0QsSUFBTixDQUFXO0FBQ2J4QztBQURhLEtBQVgsRUFFRDtBQUNEeUMsV0FBSyxFQUFFO0FBRE4sS0FGQyxFQUlEQyxLQUpDLEVBQUosRUFJWTtBQUNWLFlBQU0sSUFBSTNELE1BQU0sQ0FBQzRELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsaUJBQXRCLENBQU47QUFDRDs7QUFDRCxVQUFNZCxHQUFHLEdBQUd0QyxVQUFVLENBQUNTLE1BQUQsQ0FBdEI7O0FBQ0EsUUFBSXZCLEtBQUssQ0FBQytELElBQU4sQ0FBVztBQUNiWDtBQURhLEtBQVgsRUFFRDtBQUNEWSxXQUFLLEVBQUU7QUFETixLQUZDLEVBSURDLEtBSkMsRUFBSixFQUlZO0FBQ1YsWUFBTSxJQUFJM0QsTUFBTSxDQUFDNEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixjQUF0QixDQUFOO0FBQ0Q7O0FBRUQsVUFBTTFCLE9BQU8sR0FBR2IsTUFBTSxDQUFDd0MsTUFBUCxFQUFoQjtBQUNBLFVBQU12QixTQUFTLEdBQUdqQixNQUFNLENBQUN3QyxNQUFQLEVBQWxCO0FBQ0EsVUFBTS9CLE1BQU0sR0FBR3BDLEtBQUssQ0FBQ29FLE1BQU4sQ0FBYTtBQUMxQkMsY0FBUSxFQUFFLElBQUlDLElBQUosRUFEZ0I7QUFFMUIvQyxZQUYwQjtBQUcxQjZCLFNBSDBCO0FBSTFCWixhQUowQjtBQUsxQkk7QUFMMEIsS0FBYixDQUFmO0FBUUEsV0FBTztBQUNMUixZQURLO0FBRUxJLGFBRks7QUFHTEk7QUFISyxLQUFQO0FBS0QsR0F6Q1k7O0FBMENiVyxhQUFXLENBQUVnQixRQUFGLEVBQVk7QUFDckIzQyxtQkFBZSxDQUFDO0FBQ2QrQixVQUFJLEVBQUVZLFFBRFE7QUFFZFgsWUFBTSxFQUFFNUIsWUFBWSxDQUFDdUIsV0FGUDtBQUdkTSxXQUFLLEVBQUU7QUFDTEMsYUFBSyxFQUFFO0FBREY7QUFITyxLQUFELENBQWY7QUFPQSxVQUFNVSxJQUFJLEdBQUd4RSxLQUFLLENBQUN5RSxPQUFOLENBQWM7QUFDekJyQixTQUFHLEVBQUVtQixRQUFRLENBQUNuQjtBQURXLEtBQWQsS0FFUHZCLEtBQUssQ0FBQyxHQUFELEVBQU0sb0JBQU4sRUFBNEI7QUFDckNpQyxXQUFLLEVBQUU7QUFEOEIsS0FBNUIsQ0FGWDs7QUFNQSxRQUFJN0QsS0FBSyxDQUFDd0UsT0FBTixDQUFjO0FBQ2hCckMsWUFBTSxFQUFFb0MsSUFBSSxDQUFDRSxHQURHO0FBRWhCdEUsVUFBSSxFQUFFbUUsUUFBUSxDQUFDbkU7QUFGQyxLQUFkLENBQUosRUFHSTtBQUNGO0FBQ0Q7O0FBQ0RILFNBQUssQ0FBQ21FLE1BQU4sQ0FBYTtBQUNYaEMsWUFBTSxFQUFFb0MsSUFBSSxDQUFDRSxHQURGO0FBRVhsQixRQUFFLEVBQUVlLFFBQVEsQ0FBQ2YsRUFGRjtBQUdYcEQsVUFBSSxFQUFFbUUsUUFBUSxDQUFDbkUsSUFISjtBQUlYdUUsZUFBUyxFQUFFLElBQUlMLElBQUosRUFKQTtBQUtYckIsWUFBTSxFQUFFLFdBTEc7QUFNWFIsZUFBUyxFQUFFO0FBTkEsS0FBYjs7QUFRQSxRQUFJOEIsUUFBUSxDQUFDL0IsT0FBYixFQUFzQjtBQUNwQnhDLFdBQUssQ0FBQzRFLE1BQU4sQ0FBYTtBQUNYRixXQUFHLEVBQUVGLElBQUksQ0FBQ0U7QUFEQyxPQUFiLEVBRUc7QUFDREcsWUFBSSxFQUFFO0FBQ0o1RSxlQUFLLEVBQUU7QUFESDtBQURMLE9BRkg7QUFPRDtBQUNGLEdBL0VZOztBQWdGYmdDLGtCQUFnQixDQUFFc0MsUUFBRixFQUFZO0FBQzFCM0MsbUJBQWUsQ0FBQztBQUNkK0IsVUFBSSxFQUFFWSxRQURRO0FBRWRYLFlBQU0sRUFBRTVCLFlBQVksQ0FBQ0MsZ0JBRlA7QUFHZDRCLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZjtBQU9BOUQsU0FBSyxDQUFDK0QsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDbkM7QUFETCxLQUFYLEVBRUc2QixLQUZILE1BRWNwQyxLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLEVBQTRCO0FBQzdDaUMsV0FBSyxFQUFFO0FBRHNDLEtBQTVCLENBRm5CO0FBTUE5RCxTQUFLLENBQUMrRCxJQUFOLENBQVc7QUFDVFcsU0FBRyxFQUFFSCxRQUFRLENBQUNuQyxNQURMO0FBRVRJLGFBQU8sRUFBRStCLFFBQVEsQ0FBQy9CO0FBRlQsS0FBWCxFQUdHeUIsS0FISCxNQUdjcEMsS0FBSyxDQUFDLEdBQUQsRUFBTSw0Q0FBTixFQUFvRDtBQUNyRWlDLFdBQUssRUFBRTtBQUQ4RCxLQUFwRCxDQUhuQjtBQU9BN0QsU0FBSyxDQUFDOEQsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDaEMsTUFETDtBQUVUSCxZQUFNLEVBQUVtQyxRQUFRLENBQUNuQztBQUZSLEtBQVgsRUFHRzZCLEtBSEgsTUFHY3BDLEtBQUssQ0FBQyxHQUFELEVBQU0sb0JBQU4sQ0FIbkI7QUFLQTVCLFNBQUssQ0FBQzJFLE1BQU4sQ0FBYUwsUUFBUSxDQUFDaEMsTUFBdEIsRUFBOEI7QUFDNUJ1QyxVQUFJLEVBQUU7QUFDSnJDLGlCQUFTLEVBQUU4QixRQUFRLENBQUM5QjtBQURoQjtBQURzQixLQUE5QjtBQUtELEdBL0dZOztBQWdIYnNDLFlBQVUsQ0FBRXhELE1BQUYsRUFBVTtBQUNsQkssbUJBQWUsQ0FBQztBQUNkK0IsVUFBSSxFQUFFcEMsTUFEUTtBQUVkcUMsWUFBTSxFQUFFNUIsWUFBWSxDQUFDVCxNQUZQO0FBR2RzQyxXQUFLLEVBQUU7QUFDTEMsYUFBSyxFQUFFO0FBREY7QUFITyxLQUFELENBQWYsQ0FEa0IsQ0FRbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxVQUFNVixHQUFHLEdBQUd0QyxVQUFVLENBQUNTLE1BQUQsQ0FBdEI7O0FBQ0EsUUFBSXZCLEtBQUssQ0FBQytELElBQU4sQ0FBVztBQUNiWDtBQURhLEtBQVgsRUFFRDtBQUNEWSxXQUFLLEVBQUU7QUFETixLQUZDLEVBSURDLEtBSkMsRUFBSixFQUlZO0FBQ1YsWUFBTSxJQUFJM0QsTUFBTSxDQUFDNEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixjQUF0QixDQUFOO0FBQ0Q7QUFDRixHQXhJWTs7QUF5SWJsQixrQkFBZ0IsQ0FBRXVCLFFBQUYsRUFBWTtBQUMxQjNDLG1CQUFlLENBQUM7QUFDZCtCLFVBQUksRUFBRVksUUFEUTtBQUVkWCxZQUFNLEVBQUU1QixZQUFZLENBQUNnQixnQkFGUDtBQUdkYSxXQUFLLEVBQUU7QUFDTEMsYUFBSyxFQUFFO0FBREY7QUFITyxLQUFELENBQWY7QUFRQTlELFNBQUssQ0FBQytELElBQU4sQ0FBVztBQUNUVyxTQUFHLEVBQUVILFFBQVEsQ0FBQ25DO0FBREwsS0FBWCxFQUVHNkIsS0FGSCxNQUVjcEMsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixFQUE0QjtBQUM3Q2lDLFdBQUssRUFBRTtBQURzQyxLQUE1QixDQUZuQjtBQU1BOUQsU0FBSyxDQUFDK0QsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDbkMsTUFETDtBQUVUSSxhQUFPLEVBQUUrQixRQUFRLENBQUMvQjtBQUZULEtBQVgsRUFHR3lCLEtBSEgsTUFHY3BDLEtBQUssQ0FBQyxHQUFELEVBQU0sNENBQU4sRUFBb0Q7QUFDckVpQyxXQUFLLEVBQUU7QUFEOEQsS0FBcEQsQ0FIbkI7QUFPQTdELFNBQUssQ0FBQzhELElBQU4sQ0FBVztBQUNUVyxTQUFHLEVBQUVILFFBQVEsQ0FBQ2hDLE1BREw7QUFFVEgsWUFBTSxFQUFFbUMsUUFBUSxDQUFDbkM7QUFGUixLQUFYLEVBR0c2QixLQUhILE1BR2NwQyxLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLENBSG5CO0FBS0E1QixTQUFLLENBQUMyRSxNQUFOLENBQWFMLFFBQVEsQ0FBQ2hDLE1BQXRCLEVBQThCO0FBQzVCdUMsVUFBSSxFQUFFO0FBQ0o3QixjQUFNLEVBQUVzQixRQUFRLENBQUN0QjtBQURiO0FBRHNCLEtBQTlCO0FBS0QsR0F6S1k7O0FBMEtiQyxjQUFZLENBQUVxQixRQUFGLEVBQVk7QUFDdEIzQyxtQkFBZSxDQUFDO0FBQ2QrQixVQUFJLEVBQUVZLFFBRFE7QUFFZFgsWUFBTSxFQUFFNUIsWUFBWSxDQUFDa0IsWUFGUDtBQUdkVyxXQUFLLEVBQUU7QUFDTEMsYUFBSyxFQUFFO0FBREY7QUFITyxLQUFELENBQWY7QUFRQTlELFNBQUssQ0FBQytELElBQU4sQ0FBVztBQUNUVyxTQUFHLEVBQUVILFFBQVEsQ0FBQ25DO0FBREwsS0FBWCxFQUVHNkIsS0FGSCxNQUVjcEMsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixFQUE0QjtBQUM3Q2lDLFdBQUssRUFBRTtBQURzQyxLQUE1QixDQUZuQjtBQU1BOUQsU0FBSyxDQUFDK0QsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDbkMsTUFETDtBQUVUSSxhQUFPLEVBQUUrQixRQUFRLENBQUMvQjtBQUZULEtBQVgsRUFHR3lCLEtBSEgsTUFHY3BDLEtBQUssQ0FBQyxHQUFELEVBQU0sNENBQU4sRUFBb0Q7QUFDckVpQyxXQUFLLEVBQUU7QUFEOEQsS0FBcEQsQ0FIbkI7QUFPQTdELFNBQUssQ0FBQzhELElBQU4sQ0FBVztBQUNUVyxTQUFHLEVBQUVILFFBQVEsQ0FBQ2hDLE1BREw7QUFFVEgsWUFBTSxFQUFFbUMsUUFBUSxDQUFDbkM7QUFGUixLQUFYLEVBR0c2QixLQUhILE1BR2NwQyxLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLENBSG5CO0FBS0E1QixTQUFLLENBQUMrRSxNQUFOLENBQWFULFFBQVEsQ0FBQ2hDLE1BQXRCO0FBQ0QsR0F0TVk7O0FBdU1iSSxTQUFPLENBQUU0QixRQUFGLEVBQVk7QUFDakIzQyxtQkFBZSxDQUFDO0FBQ2QrQixVQUFJLEVBQUVZLFFBRFE7QUFFZFgsWUFBTSxFQUFFNUIsWUFBWSxDQUFDVyxPQUZQO0FBR2RrQixXQUFLLEVBQUU7QUFDTEMsYUFBSyxFQUFFO0FBREY7QUFITyxLQUFELENBQWY7QUFRQTlELFNBQUssQ0FBQytELElBQU4sQ0FBVztBQUNUVyxTQUFHLEVBQUVILFFBQVEsQ0FBQ25DO0FBREwsS0FBWCxFQUVHNkIsS0FGSCxNQUVjcEMsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixFQUE0QjtBQUM3Q2lDLFdBQUssRUFBRTtBQURzQyxLQUE1QixDQUZuQjtBQU1BOUQsU0FBSyxDQUFDK0QsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDbkMsTUFETDtBQUVUUSxlQUFTLEVBQUUyQixRQUFRLENBQUMzQjtBQUZYLEtBQVgsRUFHR3FCLEtBSEgsTUFHY3BDLEtBQUssQ0FBQyxHQUFELEVBQU0sdUNBQU4sRUFBK0M7QUFDaEVpQyxXQUFLLEVBQUU7QUFEeUQsS0FBL0MsQ0FIbkI7QUFPQSxVQUFNakIsS0FBSyxHQUFHbEIsTUFBTSxDQUFDd0MsTUFBUCxFQUFkO0FBRUFuRSxTQUFLLENBQUM0RSxNQUFOLENBQWFMLFFBQVEsQ0FBQ25DLE1BQXRCLEVBQThCO0FBQzVCMEMsVUFBSSxFQUFFO0FBQ0osU0FBQ1AsUUFBUSxDQUFDMUIsS0FBVixHQUFrQkE7QUFEZDtBQURzQixLQUE5QjtBQUtBLFdBQU9BLEtBQVA7QUFDRCxHQXJPWTs7QUFzT2JFLGdCQUFjLENBQUV3QixRQUFGLEVBQVk7QUFDeEIzQyxtQkFBZSxDQUFDO0FBQ2QrQixVQUFJLEVBQUVZLFFBRFE7QUFFZFgsWUFBTSxFQUFFNUIsWUFBWSxDQUFDZSxjQUZQO0FBR2RjLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZjtBQVFBOUQsU0FBSyxDQUFDK0QsSUFBTixDQUFXO0FBQ1RXLFNBQUcsRUFBRUgsUUFBUSxDQUFDbkM7QUFETCxLQUFYLEVBRUc2QixLQUZILE1BRWNwQyxLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLEVBQTRCO0FBQzdDaUMsV0FBSyxFQUFFO0FBRHNDLEtBQTVCLENBRm5CO0FBTUEsVUFBTVUsSUFBSSxHQUFHeEUsS0FBSyxDQUFDeUUsT0FBTixDQUFjO0FBQ3pCQyxTQUFHLEVBQUVILFFBQVEsQ0FBQ25DLE1BRFc7QUFFekJRLGVBQVMsRUFBRTJCLFFBQVEsQ0FBQzNCO0FBRkssS0FBZCxLQUdQZixLQUFLLENBQUMsR0FBRCxFQUFNLDJEQUFOLEVBQW1FO0FBQzVFaUMsV0FBSyxFQUFFO0FBRHFFLEtBQW5FLENBSFg7QUFPQSxXQUFPVSxJQUFJLENBQUNoQyxPQUFaO0FBQ0Q7O0FBN1BZLENBQWY7QUFnUUFsQyxNQUFNLENBQUMyRSxPQUFQLENBQWUsTUFBZixFQUF1QixVQUFVVixRQUFWLEVBQW9CO0FBQ3pDM0MsaUJBQWUsQ0FBQztBQUNkK0IsUUFBSSxFQUFFWSxRQURRO0FBRWRYLFVBQU0sRUFBRTVCLFlBQVksQ0FBQ21CLFdBRlA7QUFHZFUsU0FBSyxFQUFFO0FBQ0xDLFdBQUssRUFBRTtBQURGO0FBSE8sR0FBRCxDQUFmO0FBT0EsUUFBTVUsSUFBSSxHQUFHeEUsS0FBSyxDQUFDeUUsT0FBTixDQUFjO0FBQ3pCckIsT0FBRyxFQUFFbUIsUUFBUSxDQUFDbkI7QUFEVyxHQUFkLEtBRVB2QixLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLEVBQTRCO0FBQ3JDaUMsU0FBSyxFQUFFO0FBRDhCLEdBQTVCLENBRlg7QUFNQVMsVUFBUSxDQUFDL0IsT0FBVCxJQUFvQmdDLElBQUksQ0FBQ2hDLE9BQUwsS0FBaUIrQixRQUFRLENBQUMvQixPQUE5QyxJQUF5RFgsS0FBSyxDQUFDLEdBQUQsRUFBTSxtQkFBTixFQUEyQjtBQUN2RmlDLFNBQUssRUFBRTtBQURnRixHQUEzQixDQUE5RDtBQUlBLFFBQU1vQixVQUFVLEdBQUc7QUFDakI5QyxVQUFNLEVBQUVvQyxJQUFJLENBQUNFO0FBREksR0FBbkI7O0FBSUEsTUFBSSxDQUFDSCxRQUFRLENBQUMvQixPQUFkLEVBQXVCO0FBQ3JCMEMsY0FBVSxDQUFDakMsTUFBWCxHQUFvQixTQUFwQjtBQUNEOztBQUVELFNBQU8sQ0FDTGpELEtBQUssQ0FBQytELElBQU4sQ0FBV1MsSUFBSSxDQUFDRSxHQUFoQixFQUFxQjtBQUNuQlMsVUFBTSxFQUFFO0FBQ052QyxlQUFTLEVBQUUsQ0FETDtBQUVOSixhQUFPLEVBQUU7QUFGSDtBQURXLEdBQXJCLENBREssRUFPTHZDLEtBQUssQ0FBQzhELElBQU4sQ0FBV21CLFVBQVgsQ0FQSyxDQUFQO0FBU0QsQ0FuQ0Q7QUFvQ0E1RSxNQUFNLENBQUMyRSxPQUFQLENBQWUsUUFBZixFQUF5QixVQUFVVixRQUFWLEVBQW9CO0FBQzNDM0MsaUJBQWUsQ0FBQztBQUNkK0IsUUFBSSxFQUFFWSxRQURRO0FBRWRYLFVBQU0sRUFBRTVCLFlBQVksQ0FBQ3NCLGFBRlA7QUFHZE8sU0FBSyxFQUFFO0FBQ0xDLFdBQUssRUFBRTtBQURGO0FBSE8sR0FBRCxDQUFmO0FBUUEsU0FBTzlELEtBQUssQ0FBQytELElBQU4sQ0FBVztBQUNoQlcsT0FBRyxFQUFFSCxRQUFRLENBQUNuQyxNQURFO0FBRWhCSSxXQUFPLEVBQUUrQixRQUFRLENBQUMvQjtBQUZGLEdBQVgsRUFHSjtBQUNEMkMsVUFBTSxFQUFFO0FBQ052QyxlQUFTLEVBQUUsQ0FETDtBQUVOSixhQUFPLEVBQUU7QUFGSDtBQURQLEdBSEksQ0FBUDtBQVNELENBbEJELEU7Ozs7Ozs7Ozs7O0FDdlZBMUMsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQzhCLE9BQUssRUFBQyxNQUFJQSxLQUFYO0FBQWlCRCxpQkFBZSxFQUFDLE1BQUlBO0FBQXJDLENBQWQ7QUFBcUUsSUFBSXRCLE1BQUo7QUFBV1IsTUFBTSxDQUFDTSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXlCLEdBQUo7QUFBUWhDLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLEtBQVosRUFBa0I7QUFBQzJCLFNBQU8sQ0FBQzFCLENBQUQsRUFBRztBQUFDeUIsT0FBRyxHQUFDekIsQ0FBSjtBQUFNOztBQUFsQixDQUFsQixFQUFzQyxDQUF0Qzs7QUFHdEksTUFBTXdCLEtBQUssR0FBRyxTQUFTQSxLQUFULENBQWdCdUQsTUFBaEIsRUFBd0JDLE9BQXhCLEVBQWlDeEIsS0FBakMsRUFBd0M7QUFDM0QsTUFBSUEsS0FBSixFQUFXO0FBQ1R5QixXQUFPLENBQUNDLEdBQVIsQ0FBWUgsTUFBWixFQUFvQkMsT0FBcEI7QUFDQUMsV0FBTyxDQUFDQyxHQUFSLENBQVlDLElBQUksQ0FBQ0MsU0FBTCxDQUFlNUIsS0FBZixFQUFzQixJQUF0QixFQUE0QixDQUE1QixDQUFaO0FBQ0Q7O0FBQ0QsUUFBTSxJQUFJdkQsTUFBTSxDQUFDNEQsS0FBWCxDQUFpQmtCLE1BQWpCLEVBQXlCQyxPQUF6QixDQUFOO0FBQ0QsQ0FOTTs7QUFRQSxNQUFNekQsZUFBZSxHQUFHLFVBQVUyQyxRQUFWLEVBQW9CO0FBQ2pELFFBQU1tQixVQUFVLEdBQUc1RCxHQUFHLENBQUM2RCxRQUFKLENBQWFwQixRQUFRLENBQUNaLElBQXRCLEVBQTRCWSxRQUFRLENBQUNYLE1BQXJDLENBQW5COztBQUNBLE1BQUksQ0FBQzhCLFVBQVUsQ0FBQ0UsS0FBaEIsRUFBdUI7QUFDckI7QUFDRDs7QUFDRHJCLFVBQVEsR0FBR3NCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQ3ZCVixVQUFNLEVBQUUsR0FEZTtBQUV2QkMsV0FBTyxFQUFFSyxVQUFVLENBQUNFLEtBQVgsQ0FBaUJHLE9BQWpCLENBQXlCLENBQXpCLEVBQTRCQztBQUZkLEdBQWQsRUFHUnpCLFFBSFEsQ0FBWDs7QUFJQSxNQUFJQSxRQUFRLENBQUNWLEtBQWIsRUFBb0I7QUFDbEJVLFlBQVEsQ0FBQ1YsS0FBVCxDQUFla0MsT0FBZixHQUF5QkwsVUFBVSxDQUFDRSxLQUFYLENBQWlCRyxPQUExQztBQUNBeEIsWUFBUSxDQUFDVixLQUFULENBQWVvQyxPQUFmLEdBQXlCUCxVQUFVLENBQUNFLEtBQVgsQ0FBaUJLLE9BQTFDO0FBQ0Q7O0FBQ0RwRSxPQUFLLENBQUMwQyxRQUFRLENBQUNhLE1BQVYsRUFBa0JiLFFBQVEsQ0FBQ2MsT0FBM0IsRUFBb0NkLFFBQVEsQ0FBQ1YsS0FBN0MsQ0FBTDtBQUNELENBZE0sQzs7Ozs7Ozs7Ozs7QUNYUCxJQUFJcUMsT0FBSjtBQUFZcEcsTUFBTSxDQUFDTSxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDMkIsU0FBTyxDQUFDMUIsQ0FBRCxFQUFHO0FBQUM2RixXQUFPLEdBQUM3RixDQUFSO0FBQVU7O0FBQXRCLENBQXRCLEVBQThDLENBQTlDO0FBQWlELElBQUk4RixJQUFKO0FBQVNyRyxNQUFNLENBQUNNLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUMrRixNQUFJLENBQUM5RixDQUFELEVBQUc7QUFBQzhGLFFBQUksR0FBQzlGLENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSUMsTUFBSjtBQUFXUixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJTCxLQUFKLEVBQVVDLEtBQVY7QUFBZ0JILE1BQU0sQ0FBQ00sSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNKLE9BQUssQ0FBQ0ssQ0FBRCxFQUFHO0FBQUNMLFNBQUssR0FBQ0ssQ0FBTjtBQUFRLEdBQWxCOztBQUFtQkosT0FBSyxDQUFDSSxDQUFELEVBQUc7QUFBQ0osU0FBSyxHQUFDSSxDQUFOO0FBQVE7O0FBQXBDLENBQWxDLEVBQXdFLENBQXhFO0FBQTJFLElBQUkrRixNQUFKO0FBQVd0RyxNQUFNLENBQUNNLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUMyQixTQUFPLENBQUMxQixDQUFELEVBQUc7QUFBQytGLFVBQU0sR0FBQy9GLENBQVA7QUFBUzs7QUFBckIsQ0FBckIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSWdHLEdBQUo7QUFBUXZHLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUMyQixTQUFPLENBQUMxQixDQUFELEVBQUc7QUFBQ2dHLE9BQUcsR0FBQ2hHLENBQUo7QUFBTTs7QUFBbEIsQ0FBakMsRUFBcUQsQ0FBckQ7QUFPbFYsTUFBTWlHLFNBQVMsR0FBR2hHLE1BQU0sQ0FBQ2lHLFNBQVAsQ0FBaUIsVUFBVWhDLFFBQVYsRUFBb0JpQyxRQUFwQixFQUE4QjtBQUMvREgsS0FBRyxDQUFDOUIsUUFBRCxFQUFXLFVBQVVrQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0JDLENBQWhCLEVBQW1CO0FBQy9CSCxZQUFRLENBQUNDLENBQUQsRUFBSSxDQUFDQyxDQUFELEVBQUlSLE9BQU8sQ0FBQ1UsSUFBUixDQUFhRCxDQUFDLEdBQUdBLENBQUMsQ0FBQ0UsSUFBTCxHQUFZdEMsUUFBUSxDQUFDdUMsSUFBbkMsQ0FBSixDQUFKLENBQVI7QUFDRCxHQUZFLENBQUg7QUFHRCxDQUppQixDQUFsQjtBQU1BLE1BQU1DLElBQUksR0FBRztBQUNYQyxXQUFTLEVBQUU7QUFDVEMsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUJBLGNBQVEsQ0FBQ3hELElBQVQsQ0FBY3lELE9BQWQsR0FBd0I1QixJQUFJLENBQUM2QixLQUFMLENBQVdILENBQUMsQ0FBQyxvQ0FBRCxDQUFELENBQXdDSixJQUF4QyxFQUFYLEVBQTJEUSxvQkFBM0QsQ0FBZ0ZDLG9CQUF4RztBQUNBSixjQUFRLENBQUN4RCxJQUFULENBQWM2RCxhQUFkLEdBQThCTCxRQUFRLENBQUN4RCxJQUFULENBQWM4RCxPQUFkLENBQXNCaEcsT0FBdEIsQ0FBOEIsb0JBQTlCLEVBQW9ELEVBQXBELENBQTlCO0FBQ0EwRixjQUFRLENBQUN4RCxJQUFULENBQWM4RCxPQUFkLEdBQXdCTixRQUFRLENBQUN4RCxJQUFULENBQWM4RCxPQUFkLENBQXNCaEcsT0FBdEIsQ0FBOEIsa0JBQTlCLEVBQWtELEVBQWxELENBQXhCO0FBQ0EsYUFBTzBGLFFBQVA7QUFDRDs7QUFOUSxHQURBO0FBU1hPLFNBQU8sRUFBRTtBQUNQckUsU0FBSyxFQUFFLDBDQURBOztBQUVQNEQsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUIsWUFBTVEsT0FBTyxHQUFHUixRQUFRLENBQUN4RCxJQUFULENBQWNpRSxLQUFkLENBQW9CQyxLQUFwQixDQUEwQmQsSUFBSSxDQUFDVyxPQUFMLENBQWFyRSxLQUF2QyxDQUFoQjs7QUFDQSxVQUFJLENBQUNzRSxPQUFMLEVBQWM7QUFDWixlQUFPUixRQUFQO0FBQ0Q7O0FBQ0QsWUFBTXhELElBQUksR0FBRzZCLElBQUksQ0FBQzZCLEtBQUwsQ0FBV2xCLElBQUksQ0FBQzJCLEdBQUwsQ0FBVSxtREFBa0RILE9BQU8sQ0FBQyxDQUFELENBQUksUUFBT3JILE1BQU0sQ0FBQ3lILFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCQyxVQUFXLGtCQUFqSCxFQUFvSUMsT0FBL0ksRUFBd0pDLEtBQXhKLENBQThKLENBQTlKLEVBQWlLQyxVQUE5SztBQUVBakIsY0FBUSxDQUFDeEQsSUFBVCxDQUFjeUQsT0FBZCxHQUF3QnpELElBQUksQ0FBQzBFLFNBQUwsR0FBaUIxRSxJQUFJLENBQUMyRSxZQUE5QztBQUNBLGFBQU9uQixRQUFQO0FBQ0Q7O0FBWE0sR0FURTtBQXNCWG9CLFNBQU8sRUFBRTtBQUNQdEIsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUIsVUFBSXFCLEtBQUssR0FBR3RCLENBQUMsQ0FBQyxVQUFELENBQWI7QUFDQSxZQUFNdUIsU0FBUyxHQUFHLENBQUNELEtBQUssQ0FBQ3pFLElBQU4sQ0FBVywwQkFBWCxFQUF1Q0osSUFBdkMsTUFBaUQ7QUFBRStFLHNCQUFjLEVBQUU7QUFBbEIsT0FBbEQsRUFBeUVBLGNBQXpFLEdBQTBGLENBQTVHO0FBQ0EsWUFBTUMsU0FBUyxHQUFHLENBQUNILEtBQUssQ0FBQ3pFLElBQU4sQ0FBVywwQkFBWCxFQUF1Q0osSUFBdkMsTUFBaUQ7QUFBRStFLHNCQUFjLEVBQUU7QUFBbEIsT0FBbEQsRUFBeUVBLGNBQXpFLEdBQTBGLENBQTVHO0FBQ0F2QixjQUFRLENBQUN4RCxJQUFULENBQWN5RCxPQUFkLEdBQXdCcUIsU0FBUyxHQUFHRSxTQUFwQztBQUNBeEIsY0FBUSxDQUFDeEQsSUFBVCxDQUFjOEQsT0FBZCxHQUF3Qk4sUUFBUSxDQUFDeEQsSUFBVCxDQUFjOEQsT0FBZCxDQUFzQmhHLE9BQXRCLENBQThCLGFBQTlCLEVBQTZDLEVBQTdDLENBQXhCO0FBQ0EsYUFBTzBGLFFBQVA7QUFDRDs7QUFSTSxHQXRCRTtBQWdDWHlCLFFBQU0sRUFBRTtBQUNOM0IsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUJBLGNBQVEsQ0FBQ3hELElBQVQsQ0FBY3lELE9BQWQsR0FBd0J5QixRQUFRLENBQUMxQixRQUFRLENBQUN4RCxJQUFULENBQWM2RCxhQUFkLENBQTRCL0YsT0FBNUIsQ0FBb0MsTUFBcEMsRUFBNEMsRUFBNUMsRUFBZ0RBLE9BQWhELENBQXdELEdBQXhELEVBQTZELEVBQTdELENBQUQsQ0FBaEM7QUFDQTBGLGNBQVEsQ0FBQ3hELElBQVQsQ0FBYzZELGFBQWQsR0FBOEJMLFFBQVEsQ0FBQ3hELElBQVQsQ0FBYzhELE9BQWQsQ0FBc0JoRyxPQUF0QixDQUE4QixRQUE5QixFQUF3QyxFQUF4QyxDQUE5QjtBQUNBMEYsY0FBUSxDQUFDeEQsSUFBVCxDQUFjOEQsT0FBZCxHQUF3Qk4sUUFBUSxDQUFDeEQsSUFBVCxDQUFjOEQsT0FBZCxDQUFzQmhHLE9BQXRCLENBQThCLFFBQTlCLEVBQXdDLEVBQXhDLENBQXhCO0FBQ0EsYUFBTzBGLFFBQVA7QUFDRDs7QUFOSyxHQWhDRztBQXdDWDJCLE9BQUssRUFBRTtBQUNMN0IsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUIsWUFBTXhELElBQUksR0FBRzZCLElBQUksQ0FBQzZCLEtBQUwsQ0FBV2xCLElBQUksQ0FBQzJCLEdBQUwsQ0FBVSxHQUFFWCxRQUFRLENBQUN4RCxJQUFULENBQWNpRSxLQUFNLDBCQUFoQyxFQUEyRDtBQUNqRm1CLGVBQU8sRUFBRTtBQUNQLHdCQUFjLHNFQURQO0FBRVAscUJBQVc1QixRQUFRLENBQUN4RCxJQUFULENBQWNpRSxLQUZsQjtBQUdQLDhCQUFvQjtBQUhiO0FBRHdFLE9BQTNELEVBTXJCTSxPQU5VLENBQWI7QUFPQWYsY0FBUSxDQUFDeEQsSUFBVCxDQUFjeUQsT0FBZCxHQUF3QnpELElBQUksQ0FBQ3FGLFdBQUwsQ0FBaUJDLEdBQXpDO0FBQ0EsYUFBTzlCLFFBQVA7QUFDRDs7QUFYSSxHQXhDSTtBQXFEWCxrQkFBZ0I7QUFDZEYsaUJBQWEsQ0FBRUMsQ0FBRixFQUFLQyxRQUFMLEVBQWU7QUFDMUIsWUFBTStCLEtBQUssR0FBR0wsUUFBUSxDQUFDM0IsQ0FBQyxDQUFDLFdBQUQsQ0FBRCxDQUFlbkQsSUFBZixDQUFvQixRQUFwQixFQUE4QkEsSUFBOUIsQ0FBbUMsR0FBbkMsRUFBd0NvRixJQUF4QyxFQUFELENBQXRCO0FBQ0FoQyxjQUFRLENBQUN4RCxJQUFULENBQWN5RCxPQUFkLEdBQXdCOEIsS0FBSyxJQUFJLENBQWpDO0FBQ0EsYUFBTy9CLFFBQVA7QUFDRDs7QUFMYTtBQXJETCxDQUFiOztBQThEQSxNQUFNaUMsVUFBVSxHQUFHLFNBQVNBLFVBQVQsQ0FBcUJoRyxHQUFyQixFQUEwQjtBQUMzQyxNQUFJK0QsUUFBSjtBQUNBLE1BQUlMLElBQUo7QUFDQSxNQUFJdkMsUUFBSjs7QUFDQSxNQUFJbkIsR0FBRyxDQUFDeUUsS0FBSixDQUFVLHdCQUFWLENBQUosRUFBeUM7QUFDdkN0RCxZQUFRLEdBQUc7QUFDVHVDLFVBQUksRUFBRVgsSUFBSSxDQUFDMkIsR0FBTCxDQUFTMUUsR0FBVCxFQUFjO0FBQ2xCMkYsZUFBTyxFQUFFO0FBQ1Asd0JBQWM7QUFEUDtBQURTLE9BQWQsRUFJSGI7QUFMTSxLQUFYO0FBT0QsR0FSRCxNQVFPO0FBQ0wzRCxZQUFRLEdBQUc7QUFDVG5CO0FBRFMsS0FBWDtBQUdEOztBQUNELEdBQUMrRCxRQUFELEVBQVdMLElBQVgsSUFBbUJSLFNBQVMsQ0FBQy9CLFFBQUQsQ0FBNUI7O0FBRUEsTUFBSW5CLEdBQUcsQ0FBQ3lFLEtBQUosQ0FBVSx3QkFBVixDQUFKLEVBQXlDO0FBQ3ZDVixZQUFRLENBQUN4RCxJQUFULENBQWMwRixVQUFkLEdBQTJCLFVBQTNCO0FBQ0Q7O0FBRUQsTUFBSXRDLElBQUksQ0FBQ0ksUUFBUSxDQUFDeEQsSUFBVCxDQUFjMEYsVUFBZCxJQUE0QmxDLFFBQVEsQ0FBQ3hELElBQVQsQ0FBYzJGLFdBQTNDLENBQVIsRUFBaUU7QUFDL0QsV0FBT3ZDLElBQUksQ0FBQ0ksUUFBUSxDQUFDeEQsSUFBVCxDQUFjMEYsVUFBZCxJQUE0QmxDLFFBQVEsQ0FBQ3hELElBQVQsQ0FBYzJGLFdBQTNDLENBQUosQ0FBNERyQyxhQUE1RCxDQUEwRUgsSUFBMUUsRUFBZ0ZLLFFBQWhGLENBQVA7QUFDRDs7QUFDRCxTQUFPQSxRQUFQO0FBQ0QsQ0EzQkQ7O0FBNkJBN0csTUFBTSxDQUFDbUQsT0FBUCxDQUFlO0FBQ2I4RixrQkFBZ0IsQ0FBRW5ILE1BQUYsRUFBVW9ILE1BQVYsRUFBa0I7QUFDaEMsUUFBSSxDQUFDQSxNQUFELElBQVd4SixLQUFLLENBQUN5RSxPQUFOLENBQWM7QUFDM0JDLFNBQUcsRUFBRXRDLE1BRHNCO0FBRTNCcUgsbUJBQWEsRUFBRTtBQUNiQyxXQUFHLEVBQUV0RCxNQUFNLEdBQUd1RCxRQUFULENBQWtCLENBQWxCLEVBQXFCLE1BQXJCLEVBQTZCQyxNQUE3QjtBQURRO0FBRlksS0FBZCxDQUFmLEVBS0k7QUFDRjtBQUNEOztBQUNELFFBQUlDLE1BQU0sR0FBRyxDQUFiO0FBQ0E1SixTQUFLLENBQUM4RCxJQUFOLENBQVc7QUFDVDNCLFlBRFM7QUFFVGEsWUFBTSxFQUFFO0FBRkMsS0FBWCxFQUdHNkcsT0FISCxDQUdXQyxJQUFJLElBQUk7QUFDakIsWUFBTTVDLFFBQVEsR0FBR2lDLFVBQVUsQ0FBQ1csSUFBSSxDQUFDM0osSUFBTixDQUEzQjtBQUNBSCxXQUFLLENBQUMyRSxNQUFOLENBQWE7QUFDWEYsV0FBRyxFQUFFcUYsSUFBSSxDQUFDckY7QUFEQyxPQUFiLEVBRUc7QUFDREksWUFBSSxFQUFFO0FBQ0p0QixZQUFFLEVBQUUyRCxRQUFRLENBQUN4RDtBQURUO0FBREwsT0FGSDtBQU9Ba0csWUFBTSxJQUFJLENBQUMxQyxRQUFRLENBQUN4RCxJQUFULENBQWN5RCxPQUFkLElBQXlCLENBQTFCLElBQStCLENBQXpDO0FBQ0QsS0FiRDtBQWNBcEgsU0FBSyxDQUFDNEUsTUFBTixDQUFhO0FBQ1hGLFNBQUcsRUFBRXRDO0FBRE0sS0FBYixFQUVHO0FBQ0QwQyxVQUFJLEVBQUU7QUFDSitFLGNBREk7QUFFSkoscUJBQWEsRUFBRSxJQUFJbkYsSUFBSjtBQUZYO0FBREwsS0FGSDtBQVFELEdBakNZOztBQWtDYjBGLGVBQWEsQ0FBRTVHLEdBQUYsRUFBTztBQUNsQixXQUFPZ0csVUFBVSxDQUFDaEcsR0FBRCxDQUFqQjtBQUNEOztBQXBDWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDeEdBLElBQUk5QyxNQUFKO0FBQVdSLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlMLEtBQUosRUFBVUMsS0FBVjtBQUFnQkgsTUFBTSxDQUFDTSxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ0osT0FBSyxDQUFDSyxDQUFELEVBQUc7QUFBQ0wsU0FBSyxHQUFDSyxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CSixPQUFLLENBQUNJLENBQUQsRUFBRztBQUFDSixTQUFLLEdBQUNJLENBQU47QUFBUTs7QUFBcEMsQ0FBbEMsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSXVCLGVBQUo7QUFBb0I5QixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUN3QixpQkFBZSxDQUFDdkIsQ0FBRCxFQUFHO0FBQUN1QixtQkFBZSxHQUFDdkIsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQTVCLEVBQW9FLENBQXBFO0FBQXVFLElBQUl5QixHQUFKO0FBQVFoQyxNQUFNLENBQUNNLElBQVAsQ0FBWSxLQUFaLEVBQWtCO0FBQUMyQixTQUFPLENBQUMxQixDQUFELEVBQUc7QUFBQ3lCLE9BQUcsR0FBQ3pCLENBQUo7QUFBTTs7QUFBbEIsQ0FBbEIsRUFBc0MsQ0FBdEM7QUFLOVAsTUFBTTJCLFlBQVksR0FBRztBQUNuQmlJLFlBQVUsRUFBRW5JLEdBQUcsQ0FBQ08sTUFBSjtBQURPLENBQXJCO0FBSUEvQixNQUFNLENBQUMyRSxPQUFQLENBQWUsU0FBZixFQUEwQixVQUFVaUYsTUFBTSxHQUFHLENBQW5CLEVBQXNCO0FBQzlDLFNBQU9sSyxLQUFLLENBQUMrRCxJQUFOLENBQVc7QUFDaEI5RCxTQUFLLEVBQUU7QUFDTHlKLFNBQUcsRUFBRTtBQURBO0FBRFMsR0FBWCxFQUlKO0FBQ0R2RSxVQUFNLEVBQUU7QUFDTjNDLGFBQU8sRUFBRSxDQURIO0FBRU5JLGVBQVMsRUFBRTtBQUZMLEtBRFA7QUFLRHVILFFBQUksRUFBRTtBQUNKTixZQUFNLEVBQUUsQ0FBQztBQURMLEtBTEw7QUFRRE8sUUFBSSxFQUFFLEtBQUtGLE1BUlY7QUFTRGxHLFNBQUssRUFBRTtBQVROLEdBSkksQ0FBUDtBQWVELENBaEJEO0FBa0JBMUQsTUFBTSxDQUFDMkUsT0FBUCxDQUFlLFVBQWYsRUFBMkIsVUFBVW9GLFFBQVYsRUFBb0JILE1BQU0sR0FBRyxDQUE3QixFQUFnQztBQUN6RCxNQUFJN0csS0FBSyxHQUFHLE1BQVo7O0FBQ0EsTUFBSTtBQUNGQSxTQUFLLEdBQUcsSUFBSWlILE1BQUosQ0FBV0QsUUFBWCxDQUFSO0FBQ0QsR0FGRCxDQUVFLE9BQU81RCxDQUFQLEVBQVU7QUFDVnBELFNBQUssR0FBRyxJQUFSO0FBQ0Q7O0FBQ0QsU0FBT3JELEtBQUssQ0FBQytELElBQU4sQ0FBVztBQUNoQnhDLFVBQU0sRUFBRThCLEtBRFE7QUFFaEJwRCxTQUFLLEVBQUU7QUFDTHlKLFNBQUcsRUFBRTtBQURBO0FBRlMsR0FBWCxFQUtKO0FBQ0R2RSxVQUFNLEVBQUU7QUFDTjNDLGFBQU8sRUFBRSxDQURIO0FBRU5JLGVBQVMsRUFBRTtBQUZMLEtBRFA7QUFLRHVILFFBQUksRUFBRTtBQUNKTixZQUFNLEVBQUUsQ0FBQztBQURMLEtBTEw7QUFRRE8sUUFBSSxFQUFFLEtBQUtGLE1BUlY7QUFTRGxHLFNBQUssRUFBRTtBQVROLEdBTEksQ0FBUDtBQWdCRCxDQXZCRDtBQXlCQTFELE1BQU0sQ0FBQzJFLE9BQVAsQ0FBZSxZQUFmLEVBQTZCLFVBQVU3QyxNQUFWLEVBQWtCO0FBQzdDUixpQkFBZSxDQUFDO0FBQ2QrQixRQUFJLEVBQUV2QixNQURRO0FBRWR3QixVQUFNLEVBQUU1QixZQUFZLENBQUNpSSxVQUZQO0FBR2RwRyxTQUFLLEVBQUU7QUFDTEMsV0FBSyxFQUFFO0FBREY7QUFITyxHQUFELENBQWY7QUFRQSxTQUFPN0QsS0FBSyxDQUFDOEQsSUFBTixDQUFXO0FBQ2hCM0IsVUFEZ0I7QUFFaEJhLFVBQU0sRUFBRTtBQUZRLEdBQVgsRUFHSjtBQUNEa0gsUUFBSSxFQUFFO0FBQ0oxSCxlQUFTLEVBQUUsQ0FBQyxDQURSO0FBRUprQyxlQUFTLEVBQUUsQ0FBQztBQUZSLEtBREw7QUFLRFgsU0FBSyxFQUFFO0FBTE4sR0FISSxDQUFQO0FBVUQsQ0FuQkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuXG5leHBvcnQgY29uc3QgY2xpcHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2xpcHMnKVxuZXhwb3J0IGNvbnN0IHBvc3RzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3Bvc3RzJylcbmV4cG9ydCB2YXIgbWlzQ2xpcHNcblxuaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICBtaXNDbGlwcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKG51bGwpXG4gIC8qIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSAqL1xuICBuZXcgUGVyc2lzdGVudE1pbmltb25nbzIobWlzQ2xpcHMsICdtaXNDbGlwcycpXG59XG5cbmlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCkge1xuICBnbG9iYWwubWlzQ2xpcHMgPSBtaXNDbGlwc1xuICBnbG9iYWwuY2xpcHMgPSBjbGlwc1xuICBnbG9iYWwucG9zdHMgPSBwb3N0c1xufVxuIiwiXG5cbmV4cG9ydCBjb25zdCB0cmFkdWNjaW9uZXMgPSB7XG4gIFwiQWNlcHRhclwiOiB7XG4gICAgXCJlblwiOiBcIkFjY2VwdFwiLFxuICAgIFwiZXNcIjogXCJBY2VwdGFyXCJcbiAgfSxcbiAgXCJBZ3JlZ2EgZW5sYWNlcyBhbCBjbGlwLlwiOiB7XG4gICAgXCJlblwiOiBcIkFkZCBsaW5rcyB0byBjbGlwLlwiLFxuICAgIFwiZXNcIjogXCJBZ3JlZ2EgZW5sYWNlcyBhbCBjbGlwLlwiXG4gIH0sXG4gIFwiQWdyZWdhclwiOiB7XG4gICAgXCJlblwiOiBcIkFkZFwiLFxuICAgIFwiZXNcIjogXCJBZ3JlZ2FyXCJcbiAgfSxcbiAgXCJBZ3JlZ2FyIGVubGFjZVwiOiB7XG4gICAgXCJlblwiOiBcIkFkZCBsaW5rXCIsXG4gICAgXCJlc1wiOiBcIkFncmVnYXIgZW5sYWNlXCJcbiAgfSxcbiAgXCJBcHJvYmFyXCI6IHtcbiAgICBcImVuXCI6IFwiQXBwcm92ZVwiLFxuICAgIFwiZXNcIjogXCJBcHJvYmFyXCJcbiAgfSxcbiAgXCJBdHLDoXNcIjoge1xuICAgIFwiZW5cIjogXCJCYWNrXCIsXG4gICAgXCJlc1wiOiBcIkF0csOhc1wiXG4gIH0sXG4gIFwiQnVzY2FyIGNsaXBcIjoge1xuICAgIFwiZW5cIjogXCJTZWFyY2ggY2xpcFwiLFxuICAgIFwiZXNcIjogXCJCdXNjYXIgY2xpcFwiXG4gIH0sXG4gIFwiQnVzcXVlZGE6XCI6IHtcbiAgICBcImVuXCI6IFwiU2VhcmNoXCIsXG4gICAgXCJlc1wiOiBcIkJ1c3F1ZWRhOlwiXG4gIH0sXG4gIFwiQ2FuY2VsYXJcIjoge1xuICAgIFwiZW5cIjogXCJDYW5jZWxcIixcbiAgICBcImVzXCI6IFwiQ2FuY2VsYXJcIlxuICB9LFxuICBcIkNsaXAgdmFjw61vXCI6IHtcbiAgICBcImVuXCI6IFwiRW1wdHkgY2xpcFwiLFxuICAgIFwiZXNcIjogXCJDbGlwIHZhY8Otb1wiXG4gIH0sXG4gIFwiQ29tcGFydGlyXCI6IHtcbiAgICBcImVuXCI6IFwiU2hhcmVcIixcbiAgICBcImVzXCI6IFwiQ29tcGFydGlyXCJcbiAgfSxcbiAgXCJDb24gZXN0YSBsbGF2ZSBzZSBwdWVkZSBhZG1pbmlzdHJhciBlbCBjbGlwXCI6IHtcbiAgICBcImVuXCI6IFwiVGhpcyBrZXkgYWxsb3dzIHRvIGFkbWluIHRoZSBjbGlwXCIsXG4gICAgXCJlc1wiOiBcIkNvbiBlc3RhIGxsYXZlIHNlIHB1ZWRlIGFkbWluaXN0cmFyIGVsIGNsaXBcIlxuICB9LFxuICBcIkNvbiBlc3RhIGxsYXZlIHNlIHB1ZWRlbiByZXZvY2FyIGxhcyBsbGF2ZXMgZGUgYWRtaW5pc3RyYWNpw7NuIHkgc2VndXJpZGFkLlwiOiB7XG4gICAgXCJlblwiOiBcIlRoaXMga2V5IGFsbG93cyB0byByZXZva2UgdGhlIGtleXNcIixcbiAgICBcImVzXCI6IFwiQ29uIGVzdGEgbGxhdmUgc2UgcHVlZGVuIHJldm9jYXIgbGFzIGxsYXZlcyBkZSBhZG1pbmlzdHJhY2nDs24geSBzZWd1cmlkYWQuXCJcbiAgfSxcbiAgXCJDcmVhclwiOiB7XG4gICAgXCJlblwiOiBcIkNyZWF0ZVwiLFxuICAgIFwiZXNcIjogXCJDcmVhclwiXG4gIH0sXG4gIFwiQ3JlYXIgY2xpcFwiOiB7XG4gICAgXCJlblwiOiBcIkNyZWF0ZSBjbGlwXCIsXG4gICAgXCJlc1wiOiBcIkNyZWFyIGNsaXBcIlxuICB9LFxuICBcIkVsaW1pbmFyXCI6IHtcbiAgICBcImVuXCI6IFwiUmVtb3ZlXCIsXG4gICAgXCJlc1wiOiBcIkVsaW1pbmFyXCJcbiAgfSxcbiAgXCJFc2NyaWJlIHVuIHTDrXR1bG8gcGFyYSBlbCBjbGlwXCI6IHtcbiAgICBcImVuXCI6IFwiRW50ZXIgYSB0aXRsZSBmb3IgdGhlIGNsaXBcIixcbiAgICBcImVzXCI6IFwiRXNjcmliZSB1biB0w610dWxvIHBhcmEgZWwgY2xpcFwiXG4gIH0sXG4gIFwiRmF2b3JpdG9zXCI6IHtcbiAgICBcImVuXCI6IFwiRmF2b3JpdGVzXCIsXG4gICAgXCJlc1wiOiBcIkZhdm9yaXRvc1wiXG4gIH0sXG4gIFwiSGVjaG9cIjoge1xuICAgIFwiZW5cIjogXCJEb25lXCIsXG4gICAgXCJlc1wiOiBcIkhlY2hvXCJcbiAgfSxcbiAgXCJJZGlvbWFcIjoge1xuICAgIFwiZW5cIjogXCJMYW5ndWFnZVwiLFxuICAgIFwiZXNcIjogXCJJZGlvbWFcIlxuICB9LFxuICBcIkxsYXZlIGRlIGFkbWluaXN0cmFjacOzblwiOiB7XG4gICAgXCJlblwiOiBcIkFkbWluIGtleVwiLFxuICAgIFwiZXNcIjogXCJMbGF2ZSBkZSBhZG1pbmlzdHJhY2nDs25cIlxuICB9LFxuICBcIkxsYXZlIGRlIHNlZ3VyaWRhZFwiOiB7XG4gICAgXCJlblwiOiBcIlNhZmUga2V5XCIsXG4gICAgXCJlc1wiOiBcIkxsYXZlIGRlIHNlZ3VyaWRhZFwiXG4gIH0sXG4gIFwiTGxhdmVzXCI6IHtcbiAgICBcImVuXCI6IFwiS2V5c1wiLFxuICAgIFwiZXNcIjogXCJMbGF2ZXNcIlxuICB9LFxuICBcIkxvcyBlbmxhY2VzIHNlIG9yZGVuYW4gcG9yIHN1IHByaW9yaWRhZCwgZGUgbWF5b3IgYSBtZW5vciwgeSBwb3IgbGEgZmVjaGEgZW4gbGEgcXVlIGhhbiBzaWRvIGFncmVnYWRvcy5cIjoge1xuICAgIFwiZW5cIjogXCJUaGUgbGlua3MgYXJlIG9yZGVyZWQgYnkgdGhlaXIgcHJpb3JpdHkgYW5kIHRoZW4gYnkgdGhlIGFkZGl0aW9uIGRhdGVcIixcbiAgICBcImVzXCI6IFwiTG9zIGVubGFjZXMgc2Ugb3JkZW5hbiBwb3Igc3UgcHJpb3JpZGFkLCBkZSBtYXlvciBhIG1lbm9yLCB5IHBvciBsYSBmZWNoYSBlbiBsYSBxdWUgaGFuIHNpZG8gYWdyZWdhZG9zLlwiXG4gIH0sXG4gIFwiTW9zdHJhclwiOiB7XG4gICAgXCJlblwiOiBcIlNob3dcIixcbiAgICBcImVzXCI6IFwiTW9zdHJhclwiXG4gIH0sXG4gIFwiT2N1bHRhclwiOiB7XG4gICAgXCJlblwiOiBcIkhpZGVcIixcbiAgICBcImVzXCI6IFwiT2N1bHRhclwiXG4gIH0sXG4gIFwiT2x2aWRhclwiOiB7XG4gICAgXCJlblwiOiBcIkZvcmdldFwiLFxuICAgIFwiZXNcIjogXCJPbHZpZGFyXCJcbiAgfSxcbiAgXCJvcmdhbml6YSBsYXNcIjoge1xuICAgIFwiZW5cIjogXCJvcmdhbml6ZSB0aGVcIixcbiAgICBcImVzXCI6IFwib3JnYW5pemEgbGFzXCJcbiAgfSxcbiAgXCJQcmlvcmlkYWRcIjoge1xuICAgIFwiZW5cIjogXCJQcmlvcml0eVwiLFxuICAgIFwiZXNcIjogXCJQcmlvcmlkYWRcIlxuICB9LFxuICBcIlJhbmtpbmdcIjoge1xuICAgIFwiZW5cIjogXCJSYW5raW5nXCIsXG4gICAgXCJlc1wiOiBcIlJhbmtpbmdcIlxuICB9LFxuICBcIlJlY2hhemFyXCI6IHtcbiAgICBcImVuXCI6IFwiUmVmdXNlXCIsXG4gICAgXCJlc1wiOiBcIlJlY2hhemFyXCJcbiAgfSxcbiAgXCJSZWNvcmRhclwiOiB7XG4gICAgXCJlblwiOiBcIlJlbWVtYmVyXCIsXG4gICAgXCJlc1wiOiBcIlJlY29yZGFyXCJcbiAgfSxcbiAgXCJTaWd1aWVudGVcIjoge1xuICAgIFwiZW5cIjogXCJOZXh0XCIsXG4gICAgXCJlc1wiOiBcIlNpZ3VpZW50ZVwiXG4gIH0sXG4gIFwiVGllbmVzIHF1ZSBpbmRpY2FyIHVuIHTDrXR1bG8gcGFyYSBwb2RlciBjb250aW51YXJcIjoge1xuICAgIFwiZW5cIjogXCJZb3UgbmVlZCB0byBhZGQgYSB0aXRsZSB0byBjb250aW51ZVwiLFxuICAgIFwiZXNcIjogXCJUaWVuZXMgcXVlIGluZGljYXIgdW4gdMOtdHVsbyBwYXJhIHBvZGVyIGNvbnRpbnVhclwiXG4gIH0sXG4gIFwiVGl0dWxvXCI6IHtcbiAgICBcImVuXCI6IFwiVGl0bGVcIixcbiAgICBcImVzXCI6IFwiVGl0dWxvXCJcbiAgfSxcbiAgXCJVbmEgdmV6IGNyZWFkbyBlbCBjbGlwLCBubyBzZSBwb2Ryw6EgbW9kaWZpY2FyIHN1IHTDrXR1bG8gbmkgc3UgdXJsLlwiOiB7XG4gICAgXCJlblwiOiBcIkFmdGVyIGNyZWF0ZWQsIHRoZSB0aXRsZSBjYW5ub3QgYmUgYWx0ZXJlZFwiLFxuICAgIFwiZXNcIjogXCJVbmEgdmV6IGNyZWFkbyBlbCBjbGlwLCBubyBzZSBwb2Ryw6EgbW9kaWZpY2FyIHN1IHTDrXR1bG8gbmkgc3UgdXJsLlwiXG4gIH0sXG4gIFwiVmVyIGNsaXBcIjoge1xuICAgIFwiZW5cIjogXCJWaWV3IGNsaXBcIixcbiAgICBcImVzXCI6IFwiVmVyIGNsaXBcIlxuICB9LFxuICBcIllhIGhheSB1biBjbGlwIGNvbiBlc2EgdXJsXCI6IHtcbiAgICBcImVuXCI6IFwiQSBjbGlwIGV4aXN0cyB3aXRoIHRoaXMgdXJsXCIsXG4gICAgXCJlc1wiOiBcIllhIGhheSB1biBjbGlwIGNvbiBlc2EgdXJsXCJcbiAgfSxcbiAgXCJZYSBoYXkgdW4gY2xpcCBjb24gZXNlIHTDrXR1bG9cIjoge1xuICAgIFwiZW5cIjogXCJBIGNsaXAgZXhpc3RzIHdpdGggdGhpcyB0aXRsZVwiLFxuICAgIFwiZXNcIjogXCJZYSBoYXkgdW4gY2xpcCBjb24gZXNlIHTDrXR1bG9cIlxuICB9LFxuICBcInJlZGVzXCI6IHtcbiAgICBcImVuXCI6IFwibmV0d29ya3NcIixcbiAgICBcImVzXCI6IFwicmVkZXNcIlxuICB9XG59XG5cbmV4cG9ydCBjb25zdCBpZGlvbWFzID0ge1xuICBcImVuXCI6IDEsXG4gIFwiZXNcIjogMVxufVxuXG4iLCJjb25zdCBkaWFjcml0aWNhcyA9IHtcbiAgw6E6ICdhJyxcbiAgw6k6ICdlJyxcbiAgw606ICdpJyxcbiAgw7M6ICdvJyxcbiAgw7o6ICd1JyxcbiAgw7E6ICduJyxcbiAgw6c6ICdjJ1xufVxuXG5leHBvcnQgY29uc3QgdGl0dWxvQVVybCA9IGZ1bmN0aW9uIHRpdHVsb0FVcmwgKHRpdHVsbykge1xuICByZXR1cm4gKHRpdHVsbyB8fCAnJykudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bIF0vZywgJy0nKS5yZXBsYWNlKC9bw6HDqcOtw7rDs8O8w7FdL2csIGZ1bmN0aW9uIChsZXRyYSkge1xuICAgIHJldHVybiBkaWFjcml0aWNhc1tsZXRyYV1cbiAgfSkucmVwbGFjZSgvW15hLXowLTkgXy4tXS9nLCAnJylcbn1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuaW1wb3J0IHsgY2xpcHMsIHBvc3RzIH0gZnJvbSAnL2NvbW1vbi9iYXNlRGVEYXRvcydcbmltcG9ydCB7IHNhbGlyVmFsaWRhY2lvbiwgc2FsaXIgfSBmcm9tICcvc2VydmVyL2NvbXVuJ1xuaW1wb3J0IHsgdGl0dWxvQVVybCB9IGZyb20gJy9jb21tb24vdmFyaW9zJ1xuXG5pbXBvcnQgSm9pIGZyb20gJ2pvaSdcblxuY29uc3QgdmFsaWRhY2lvbmVzID0ge1xuICBjYW1iaWFyUHJpb3JpZGFkOiBKb2kub2JqZWN0KCkua2V5cyh7XG4gICAgY2xpcElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBwb3N0SWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlY3JldG86IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHByaW9yaWRhZDogSm9pLm51bWJlcigpLnJlcXVpcmVkKClcbiAgfSksXG4gIHJldm9jYXI6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICBjbGlwSWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlZ3VyaWRhZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgbGxhdmU6IEpvaS5zdHJpbmcoKS52YWxpZChbJ3NlZ3VyaWRhZCcsICdzZWNyZXRvJ10pLnJlcXVpcmVkKClcbiAgfSksXG4gIG9idGVuZXJTZWNyZXRvOiBKb2kub2JqZWN0KCkua2V5cyh7XG4gICAgY2xpcElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBzZWd1cmlkYWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpXG4gIH0pLFxuICBlc3RhYmxlY2VyU3RhdHVzOiBKb2kub2JqZWN0KCkua2V5cyh7XG4gICAgY2xpcElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBwb3N0SWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlY3JldG86IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHN0YXR1czogSm9pLnN0cmluZygpLnZhbGlkKFsnUkVDSEFaQURPJywgJ09DVUxUTycsICdWSVNJQkxFJ10pLnJlcXVpcmVkKClcbiAgfSksXG4gIGVsaW1pbmFyUG9zdDogSm9pLm9iamVjdCgpLmtleXMoe1xuICAgIGNsaXBJZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgcG9zdElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBzZWNyZXRvOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKVxuICB9KSxcbiAgY2xpcFB1Ymxpc2g6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICB1cmw6IEpvaS5zdHJpbmcoKS5yZWdleCgvXlthLXotXSskLykucmVxdWlyZWQoKSxcbiAgICBzZWNyZXRvOiBKb2kuc3RyaW5nKClcbiAgfSksXG4gIGNsaXBJZFB1Ymxpc2g6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICBjbGlwSWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlY3JldG86IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpXG4gIH0pLFxuICBhZ3JlZ2FyTGluazogSm9pLm9iamVjdCgpLmtleXMoe1xuICAgIHVybDogSm9pLnN0cmluZygpLnJlZ2V4KC9eW2Etei1dKyQvKS5yZXF1aXJlZCgpLFxuICAgIGxpbms6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIE9HOiBKb2kub2JqZWN0KCkucmVxdWlyZWQoKVxuICB9KSxcbiAgdGl0dWxvOiBKb2kuc3RyaW5nKClcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBjcmVhckNsaXAgKHRpdHVsbykge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiB0aXR1bG8sXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy50aXR1bG8sXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCBjcmVhckNsaXAnXG4gICAgICB9XG4gICAgfSlcblxuICAgIGlmIChjbGlwcy5maW5kKHtcbiAgICAgIHRpdHVsb1xuICAgIH0sIHtcbiAgICAgIGxpbWl0OiAxXG4gICAgfSkuY291bnQoKSkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsICd0aXR1bG8gcmVwZXRpZG8nKVxuICAgIH1cbiAgICBjb25zdCB1cmwgPSB0aXR1bG9BVXJsKHRpdHVsbylcbiAgICBpZiAoY2xpcHMuZmluZCh7XG4gICAgICB1cmxcbiAgICB9LCB7XG4gICAgICBsaW1pdDogMVxuICAgIH0pLmNvdW50KCkpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCAndXJsIHJlcGV0aWRhJylcbiAgICB9XG5cbiAgICBjb25zdCBzZWNyZXRvID0gUmFuZG9tLnNlY3JldCgpXG4gICAgY29uc3Qgc2VndXJpZGFkID0gUmFuZG9tLnNlY3JldCgpXG4gICAgY29uc3QgY2xpcElkID0gY2xpcHMuaW5zZXJ0KHtcbiAgICAgIGNyZWFjaW9uOiBuZXcgRGF0ZSgpLFxuICAgICAgdGl0dWxvLFxuICAgICAgdXJsLFxuICAgICAgc2VjcmV0byxcbiAgICAgIHNlZ3VyaWRhZFxuICAgIH0pXG5cbiAgICByZXR1cm4ge1xuICAgICAgY2xpcElkLFxuICAgICAgc2VjcmV0byxcbiAgICAgIHNlZ3VyaWRhZFxuICAgIH1cbiAgfSxcbiAgYWdyZWdhckxpbmsgKG9wY2lvbmVzKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMuYWdyZWdhckxpbmssXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCBhZ3JlZ2FyTGluaydcbiAgICAgIH1cbiAgICB9KVxuICAgIGNvbnN0IGNsaXAgPSBjbGlwcy5maW5kT25lKHtcbiAgICAgIHVybDogb3BjaW9uZXMudXJsXG4gICAgfSkgfHwgc2FsaXIoNDA0LCAnQ2xpcCBubyBlbmNvbnRyYWRvJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgYWdyZWdhckxpbmsnXG4gICAgfSlcblxuICAgIGlmIChwb3N0cy5maW5kT25lKHtcbiAgICAgIGNsaXBJZDogY2xpcC5faWQsXG4gICAgICBsaW5rOiBvcGNpb25lcy5saW5rXG4gICAgfSkpIHtcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBwb3N0cy5pbnNlcnQoe1xuICAgICAgY2xpcElkOiBjbGlwLl9pZCxcbiAgICAgIE9HOiBvcGNpb25lcy5PRyxcbiAgICAgIGxpbms6IG9wY2lvbmVzLmxpbmssXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCksXG4gICAgICBzdGF0dXM6ICdQRU5ESUVOVEUnLFxuICAgICAgcHJpb3JpZGFkOiAwXG4gICAgfSlcbiAgICBpZiAob3BjaW9uZXMuc2VjcmV0bykge1xuICAgICAgY2xpcHMudXBkYXRlKHtcbiAgICAgICAgX2lkOiBjbGlwLl9pZFxuICAgICAgfSwge1xuICAgICAgICAkaW5jOiB7XG4gICAgICAgICAgcG9zdHM6IDFcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gIH0sXG4gIGNhbWJpYXJQcmlvcmlkYWQgKG9wY2lvbmVzKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMuY2FtYmlhclByaW9yaWRhZCxcbiAgICAgIGRlYnVnOiB7XG4gICAgICAgIGRvbmRlOiAnbWV0aG9kIGNhbWJpYXJQcmlvcmlkYWQnXG4gICAgICB9XG4gICAgfSlcbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkLFxuICAgICAgc2VjcmV0bzogb3BjaW9uZXMuc2VjcmV0b1xuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDAxLCAnTm8gdGllbmVzIHBlcm1pc28gcGFyYSBhZG1pbmlzdHJhciBlbCBjbGlwJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICB9KVxuXG4gICAgcG9zdHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLnBvc3RJZCxcbiAgICAgIGNsaXBJZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdQb3N0IG5vIGVuY29udHJhZG8nKVxuXG4gICAgcG9zdHMudXBkYXRlKG9wY2lvbmVzLnBvc3RJZCwge1xuICAgICAgJHNldDoge1xuICAgICAgICBwcmlvcmlkYWQ6IG9wY2lvbmVzLnByaW9yaWRhZFxuICAgICAgfVxuICAgIH0pXG4gIH0sXG4gIHRlc3RUaXR1bG8gKHRpdHVsbykge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiB0aXR1bG8sXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy50aXR1bG8sXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCB0ZXN0VGl0dWxvJ1xuICAgICAgfVxuICAgIH0pXG4gICAgLy8gaWYgKGNsaXBzLmZpbmQoe1xuICAgIC8vICAgdGl0dWxvXG4gICAgLy8gfSwge1xuICAgIC8vICAgbGltaXQ6IDFcbiAgICAvLyB9KS5jb3VudCgpKSB7XG4gICAgLy8gICBjb25zb2xlLmxvZygndGl0dWxvIHJlcGV0aWRvJylcbiAgICAvLyAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCAndGl0dWxvIHJlcGV0aWRvJylcbiAgICAvLyB9XG4gICAgY29uc3QgdXJsID0gdGl0dWxvQVVybCh0aXR1bG8pXG4gICAgaWYgKGNsaXBzLmZpbmQoe1xuICAgICAgdXJsXG4gICAgfSwge1xuICAgICAgbGltaXQ6IDFcbiAgICB9KS5jb3VudCgpKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMCwgJ3VybCByZXBldGlkYScpXG4gICAgfVxuICB9LFxuICBlc3RhYmxlY2VyU3RhdHVzIChvcGNpb25lcykge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiBvcGNpb25lcyxcbiAgICAgIHNjaGVtYTogdmFsaWRhY2lvbmVzLmVzdGFibGVjZXJTdGF0dXMsXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgICAgfVxuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkLFxuICAgICAgc2VjcmV0bzogb3BjaW9uZXMuc2VjcmV0b1xuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDAxLCAnTm8gdGllbmVzIHBlcm1pc28gcGFyYSBhZG1pbmlzdHJhciBlbCBjbGlwJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICB9KVxuXG4gICAgcG9zdHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLnBvc3RJZCxcbiAgICAgIGNsaXBJZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdQb3N0IG5vIGVuY29udHJhZG8nKVxuXG4gICAgcG9zdHMudXBkYXRlKG9wY2lvbmVzLnBvc3RJZCwge1xuICAgICAgJHNldDoge1xuICAgICAgICBzdGF0dXM6IG9wY2lvbmVzLnN0YXR1c1xuICAgICAgfVxuICAgIH0pXG4gIH0sXG4gIGVsaW1pbmFyUG9zdCAob3BjaW9uZXMpIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogb3BjaW9uZXMsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5lbGltaW5hclBvc3QsXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgICAgfVxuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkLFxuICAgICAgc2VjcmV0bzogb3BjaW9uZXMuc2VjcmV0b1xuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDAxLCAnTm8gdGllbmVzIHBlcm1pc28gcGFyYSBhZG1pbmlzdHJhciBlbCBjbGlwJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICB9KVxuXG4gICAgcG9zdHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLnBvc3RJZCxcbiAgICAgIGNsaXBJZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdQb3N0IG5vIGVuY29udHJhZG8nKVxuXG4gICAgcG9zdHMucmVtb3ZlKG9wY2lvbmVzLnBvc3RJZClcbiAgfSxcbiAgcmV2b2NhciAob3BjaW9uZXMpIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogb3BjaW9uZXMsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5yZXZvY2FyLFxuICAgICAgZGVidWc6IHtcbiAgICAgICAgZG9uZGU6ICdtZXRob2QgcmV2b2NhcidcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgY2xpcHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZFxuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDA0LCAnQ2xpcCBubyBlbmNvbnRyYWRvJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgcmV2b2NhcidcbiAgICB9KVxuXG4gICAgY2xpcHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZCxcbiAgICAgIHNlZ3VyaWRhZDogb3BjaW9uZXMuc2VndXJpZGFkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDAsICdObyB0aWVuZXMgcGVybWlzbyBwYXJhIHJldm9jYXIgbGxhdmVzJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgcmV2b2NhcidcbiAgICB9KVxuXG4gICAgY29uc3QgbGxhdmUgPSBSYW5kb20uc2VjcmV0KClcblxuICAgIGNsaXBzLnVwZGF0ZShvcGNpb25lcy5jbGlwSWQsIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgW29wY2lvbmVzLmxsYXZlXTogbGxhdmVcbiAgICAgIH1cbiAgICB9KVxuICAgIHJldHVybiBsbGF2ZVxuICB9LFxuICBvYnRlbmVyU2VjcmV0byAob3BjaW9uZXMpIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogb3BjaW9uZXMsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5vYnRlbmVyU2VjcmV0byxcbiAgICAgIGRlYnVnOiB7XG4gICAgICAgIGRvbmRlOiAnbWV0aG9kIG9idGVuZXJTZWNyZXRvJ1xuICAgICAgfVxuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgICBkb25kZTogJ21ldGhvZCByZXZvY2FyJ1xuICAgIH0pXG5cbiAgICBjb25zdCBjbGlwID0gY2xpcHMuZmluZE9uZSh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZCxcbiAgICAgIHNlZ3VyaWRhZDogb3BjaW9uZXMuc2VndXJpZGFkXG4gICAgfSkgfHwgc2FsaXIoNDAxLCAnTm8gdGllbmVzIHBlcm1pc28gcGFyYSBvYnRlbmVyIGxhIGxsYXZlIGRlIGFkbWluaXN0cmFjacOzbicsIHtcbiAgICAgIGRvbmRlOiAnbWV0aG9kIHJldm9jYXInXG4gICAgfSlcblxuICAgIHJldHVybiBjbGlwLnNlY3JldG9cbiAgfVxufSlcblxuTWV0ZW9yLnB1Ymxpc2goJ2NsaXAnLCBmdW5jdGlvbiAob3BjaW9uZXMpIHtcbiAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICBkYXRhOiBvcGNpb25lcyxcbiAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5jbGlwUHVibGlzaCxcbiAgICBkZWJ1Zzoge1xuICAgICAgZG9uZGU6ICdwdWJsaXNoIGNsaXAnXG4gICAgfVxuICB9KVxuICBjb25zdCBjbGlwID0gY2xpcHMuZmluZE9uZSh7XG4gICAgdXJsOiBvcGNpb25lcy51cmxcbiAgfSkgfHwgc2FsaXIoNDA0LCAnQ2xpcCBubyBlbmNvbnRyYWRvJywge1xuICAgIGRvbmRlOiAncHVibGlzaCBjbGlwJ1xuICB9KVxuXG4gIG9wY2lvbmVzLnNlY3JldG8gJiYgY2xpcC5zZWNyZXRvICE9PSBvcGNpb25lcy5zZWNyZXRvICYmIHNhbGlyKDQwMSwgJ05vIHRpZW5lcyBwZXJtaXNvJywge1xuICAgIGRvbmRlOiAncHVibGlzaCBjbGlwJ1xuICB9KVxuXG4gIGNvbnN0IHBvc3RzUXVlcnkgPSB7XG4gICAgY2xpcElkOiBjbGlwLl9pZFxuICB9XG5cbiAgaWYgKCFvcGNpb25lcy5zZWNyZXRvKSB7XG4gICAgcG9zdHNRdWVyeS5zdGF0dXMgPSAnVklTSUJMRSdcbiAgfVxuXG4gIHJldHVybiBbXG4gICAgY2xpcHMuZmluZChjbGlwLl9pZCwge1xuICAgICAgZmllbGRzOiB7XG4gICAgICAgIHNlZ3VyaWRhZDogMCxcbiAgICAgICAgc2VjcmV0bzogMFxuICAgICAgfVxuICAgIH0pLFxuICAgIHBvc3RzLmZpbmQocG9zdHNRdWVyeSlcbiAgXVxufSlcbk1ldGVvci5wdWJsaXNoKCdjbGlwSWQnLCBmdW5jdGlvbiAob3BjaW9uZXMpIHtcbiAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICBkYXRhOiBvcGNpb25lcyxcbiAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5jbGlwSWRQdWJsaXNoLFxuICAgIGRlYnVnOiB7XG4gICAgICBkb25kZTogJ3B1Ymxpc2ggY2xpcElkJ1xuICAgIH1cbiAgfSlcblxuICByZXR1cm4gY2xpcHMuZmluZCh7XG4gICAgX2lkOiBvcGNpb25lcy5jbGlwSWQsXG4gICAgc2VjcmV0bzogb3BjaW9uZXMuc2VjcmV0b1xuICB9LCB7XG4gICAgZmllbGRzOiB7XG4gICAgICBzZWd1cmlkYWQ6IDAsXG4gICAgICBzZWNyZXRvOiAwXG4gICAgfVxuICB9KVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgSm9pIGZyb20gJ2pvaSdcblxuZXhwb3J0IGNvbnN0IHNhbGlyID0gZnVuY3Rpb24gc2FsaXIgKGNvZGlnbywgbWVuc2FqZSwgZGVidWcpIHtcbiAgaWYgKGRlYnVnKSB7XG4gICAgY29uc29sZS5sb2coY29kaWdvLCBtZW5zYWplKVxuICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KGRlYnVnLCBudWxsLCAyKSlcbiAgfVxuICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGNvZGlnbywgbWVuc2FqZSlcbn1cblxuZXhwb3J0IGNvbnN0IHNhbGlyVmFsaWRhY2lvbiA9IGZ1bmN0aW9uIChvcGNpb25lcykge1xuICBjb25zdCB2YWxpZGFjaW9uID0gSm9pLnZhbGlkYXRlKG9wY2lvbmVzLmRhdGEsIG9wY2lvbmVzLnNjaGVtYSlcbiAgaWYgKCF2YWxpZGFjaW9uLmVycm9yKSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgb3BjaW9uZXMgPSBPYmplY3QuYXNzaWduKHtcbiAgICBjb2RpZ286IDQwMCxcbiAgICBtZW5zYWplOiB2YWxpZGFjaW9uLmVycm9yLmRldGFpbHNbMF0ubWVzc2FnZVxuICB9LCBvcGNpb25lcylcbiAgaWYgKG9wY2lvbmVzLmRlYnVnKSB7XG4gICAgb3BjaW9uZXMuZGVidWcuZGV0YWlscyA9IHZhbGlkYWNpb24uZXJyb3IuZGV0YWlsc1xuICAgIG9wY2lvbmVzLmRlYnVnLl9vYmplY3QgPSB2YWxpZGFjaW9uLmVycm9yLl9vYmplY3RcbiAgfVxuICBzYWxpcihvcGNpb25lcy5jb2RpZ28sIG9wY2lvbmVzLm1lbnNhamUsIG9wY2lvbmVzLmRlYnVnKVxufVxuIiwiaW1wb3J0IGNoZWVyaW8gZnJvbSAnY2hlZXJpbydcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCdcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBjbGlwcywgcG9zdHMgfSBmcm9tICcvY29tbW9uL2Jhc2VEZURhdG9zJ1xuaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnXG5pbXBvcnQgb2dzIGZyb20gJ29wZW4tZ3JhcGgtc2NyYXBlcidcblxuY29uc3QgbWV0ZW9yT0dTID0gTWV0ZW9yLndyYXBBc3luYyhmdW5jdGlvbiAob3BjaW9uZXMsIGNhbGxiYWNrKSB7XG4gIG9ncyhvcGNpb25lcywgZnVuY3Rpb24gKGUsIHIsIGgpIHtcbiAgICBjYWxsYmFjayhlLCBbciwgY2hlZXJpby5sb2FkKGggPyBoLmJvZHkgOiBvcGNpb25lcy5odG1sKV0pXG4gIH0pXG59KVxuXG5jb25zdCBycnNzID0ge1xuICBJbnN0YWdyYW06IHtcbiAgICBvYnRlbmVyQXBveW9zICgkLCByZXNwb25zZSkge1xuICAgICAgcmVzcG9uc2UuZGF0YS5jckxpa2VzID0gSlNPTi5wYXJzZSgkKCdzY3JpcHRbdHlwZT1cImFwcGxpY2F0aW9uL2xkK2pzb25cIl0nKS5odG1sKCkpLmludGVyYWN0aW9uU3RhdGlzdGljLnVzZXJJbnRlcmFjdGlvbkNvdW50XG4gICAgICByZXNwb25zZS5kYXRhLm9nRGVzY3JpcHRpb24gPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvXi4qP29uIEluc3RhZ3JhbTogLywgJycpXG4gICAgICByZXNwb25zZS5kYXRhLm9nVGl0bGUgPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvb24gSW5zdGFncmFtOi4qJC8sICcnKVxuICAgICAgcmV0dXJuIHJlc3BvbnNlXG4gICAgfVxuICB9LFxuICBZb3VUdWJlOiB7XG4gICAgcmVnZXg6IC8oXnw9fFxcLykoWzAtOUEtWmEtel8tXXsxMX0pKFxcL3wmfCR8XFw/fCMpLyxcbiAgICBvYnRlbmVyQXBveW9zICgkLCByZXNwb25zZSkge1xuICAgICAgY29uc3QgeW91dHViZSA9IHJlc3BvbnNlLmRhdGEub2dVcmwubWF0Y2gocnJzcy5Zb3VUdWJlLnJlZ2V4KVxuICAgICAgaWYgKCF5b3V0dWJlKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZVxuICAgICAgfVxuICAgICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UoSFRUUC5nZXQoYGh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL3lvdXR1YmUvdjMvdmlkZW9zP2lkPSR7eW91dHViZVsyXX0ma2V5PSR7TWV0ZW9yLnNldHRpbmdzLnByaXZhdGUueW91dHViZUFQSX0mcGFydD1zdGF0aXN0aWNzYCkuY29udGVudCkuaXRlbXNbMF0uc3RhdGlzdGljc1xuXG4gICAgICByZXNwb25zZS5kYXRhLmNyTGlrZXMgPSBkYXRhLmxpa2VDb3VudCAtIGRhdGEuZGlzbGlrZUNvdW50XG4gICAgICByZXR1cm4gcmVzcG9uc2VcbiAgICB9XG4gIH0sXG4gIFR3aXR0ZXI6IHtcbiAgICBvYnRlbmVyQXBveW9zICgkLCByZXNwb25zZSkge1xuICAgICAgdmFyIHN0YXRzID0gJCgndWwuc3RhdHMnKVxuICAgICAgY29uc3QgcmV0d2VldGVkID0gKHN0YXRzLmZpbmQoJy5yZXF1ZXN0LXJldHdlZXRlZC1wb3B1cCcpLmRhdGEoKSB8fCB7IHR3ZWV0U3RhdENvdW50OiAwIH0pLnR3ZWV0U3RhdENvdW50ICogMVxuICAgICAgY29uc3QgZmF2b3JpdGVkID0gKHN0YXRzLmZpbmQoJy5yZXF1ZXN0LWZhdm9yaXRlZC1wb3B1cCcpLmRhdGEoKSB8fCB7IHR3ZWV0U3RhdENvdW50OiAwIH0pLnR3ZWV0U3RhdENvdW50ICogMVxuICAgICAgcmVzcG9uc2UuZGF0YS5jckxpa2VzID0gcmV0d2VldGVkICsgZmF2b3JpdGVkXG4gICAgICByZXNwb25zZS5kYXRhLm9nVGl0bGUgPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvb24gVHdpdHRlciQvLCAnJylcbiAgICAgIHJldHVybiByZXNwb25zZVxuICAgIH1cbiAgfSxcbiAgcmVkZGl0OiB7XG4gICAgb2J0ZW5lckFwb3lvcyAoJCwgcmVzcG9uc2UpIHtcbiAgICAgIHJlc3BvbnNlLmRhdGEuY3JMaWtlcyA9IHBhcnNlSW50KHJlc3BvbnNlLmRhdGEub2dEZXNjcmlwdGlvbi5yZXBsYWNlKC8gLiokLywgJycpLnJlcGxhY2UoLywvLCAnJykpXG4gICAgICByZXNwb25zZS5kYXRhLm9nRGVzY3JpcHRpb24gPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvXi4qPy0gLywgJycpXG4gICAgICByZXNwb25zZS5kYXRhLm9nVGl0bGUgPSByZXNwb25zZS5kYXRhLm9nVGl0bGUucmVwbGFjZSgvIC0gLiokLywgJycpXG4gICAgICByZXR1cm4gcmVzcG9uc2VcbiAgICB9XG4gIH0sXG4gIFZpbWVvOiB7XG4gICAgb2J0ZW5lckFwb3lvcyAoJCwgcmVzcG9uc2UpIHtcbiAgICAgIGNvbnN0IGRhdGEgPSBKU09OLnBhcnNlKEhUVFAuZ2V0KGAke3Jlc3BvbnNlLmRhdGEub2dVcmx9P2FjdGlvbj1sb2FkX3N0YXRfY291bnRzYCwge1xuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ1VzZXItQWdlbnQnOiAnTW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0OyBydjo2Ny4wKSBHZWNrby8yMDEwMDEwMSBGaXJlZm94LzY3LjAnLFxuICAgICAgICAgICdSZWZlcmVyJzogcmVzcG9uc2UuZGF0YS5vZ1VybCxcbiAgICAgICAgICAnWC1SZXF1ZXN0ZWQtV2l0aCc6ICdYTUxIdHRwUmVxdWVzdCdcbiAgICAgICAgfVxuICAgICAgfSkuY29udGVudClcbiAgICAgIHJlc3BvbnNlLmRhdGEuY3JMaWtlcyA9IGRhdGEudG90YWxfbGlrZXMucmF3XG4gICAgICByZXR1cm4gcmVzcG9uc2VcbiAgICB9XG4gIH0sXG4gICdAbWVuZWFtZV9uZXQnOiB7XG4gICAgb2J0ZW5lckFwb3lvcyAoJCwgcmVzcG9uc2UpIHtcbiAgICAgIGNvbnN0IHZvdG9zID0gcGFyc2VJbnQoJCgnI25ld3N3cmFwJykuZmluZCgnLnZvdGVzJykuZmluZCgnYScpLnRleHQoKSlcbiAgICAgIHJlc3BvbnNlLmRhdGEuY3JMaWtlcyA9IHZvdG9zIHx8IDBcbiAgICAgIHJldHVybiByZXNwb25zZVxuICAgIH1cbiAgfVxufVxuXG5jb25zdCBhY3R1YWxpemFyID0gZnVuY3Rpb24gYWN0dWFsaXphciAodXJsKSB7XG4gIHZhciByZXNwb25zZVxuICB2YXIgaHRtbFxuICB2YXIgb3BjaW9uZXNcbiAgaWYgKHVybC5tYXRjaCgvaHR0cHM6XFwvXFwvd3d3LmZhY2Vib29rLykpIHtcbiAgICBvcGNpb25lcyA9IHtcbiAgICAgIGh0bWw6IEhUVFAuZ2V0KHVybCwge1xuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ1VzZXItQWdlbnQnOiAnRmVlZEZldGNoZXItR29vZ2xlOyAoK2h0dHA6Ly93d3cuZ29vZ2xlLmNvbS9mZWVkZmV0Y2hlci5odG1sKSdcbiAgICAgICAgfVxuICAgICAgfSkuY29udGVudFxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBvcGNpb25lcyA9IHtcbiAgICAgIHVybFxuICAgIH1cbiAgfVxuICBbcmVzcG9uc2UsIGh0bWxdID0gbWV0ZW9yT0dTKG9wY2lvbmVzKVxuXG4gIGlmICh1cmwubWF0Y2goL2h0dHBzOlxcL1xcL3d3dy5mYWNlYm9vay8pKSB7XG4gICAgcmVzcG9uc2UuZGF0YS5vZ1NpdGVOYW1lID0gJ0ZhY2Vib29rJ1xuICB9XG5cbiAgaWYgKHJyc3NbcmVzcG9uc2UuZGF0YS5vZ1NpdGVOYW1lIHx8IHJlc3BvbnNlLmRhdGEudHdpdHRlclNpdGVdKSB7XG4gICAgcmV0dXJuIHJyc3NbcmVzcG9uc2UuZGF0YS5vZ1NpdGVOYW1lIHx8IHJlc3BvbnNlLmRhdGEudHdpdHRlclNpdGVdLm9idGVuZXJBcG95b3MoaHRtbCwgcmVzcG9uc2UpXG4gIH1cbiAgcmV0dXJuIHJlc3BvbnNlXG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgYWN0dWFsaXphckFwb3lvcyAoY2xpcElkLCBmb3J6YXIpIHtcbiAgICBpZiAoIWZvcnphciAmJiBjbGlwcy5maW5kT25lKHtcbiAgICAgIF9pZDogY2xpcElkLFxuICAgICAgYWN0dWFsaXphY2lvbjoge1xuICAgICAgICAkZ3Q6IG1vbWVudCgpLnN1YnRyYWN0KDEsICdob3VyJykudG9EYXRlKClcbiAgICAgIH1cbiAgICB9KSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHZhciBhcG95b3MgPSAwXG4gICAgcG9zdHMuZmluZCh7XG4gICAgICBjbGlwSWQsXG4gICAgICBzdGF0dXM6ICdWSVNJQkxFJ1xuICAgIH0pLmZvckVhY2gocG9zdCA9PiB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGFjdHVhbGl6YXIocG9zdC5saW5rKVxuICAgICAgcG9zdHMudXBkYXRlKHtcbiAgICAgICAgX2lkOiBwb3N0Ll9pZFxuICAgICAgfSwge1xuICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgT0c6IHJlc3BvbnNlLmRhdGFcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICAgIGFwb3lvcyArPSAocmVzcG9uc2UuZGF0YS5jckxpa2VzIHx8IDApICogMVxuICAgIH0pXG4gICAgY2xpcHMudXBkYXRlKHtcbiAgICAgIF9pZDogY2xpcElkXG4gICAgfSwge1xuICAgICAgJHNldDoge1xuICAgICAgICBhcG95b3MsXG4gICAgICAgIGFjdHVhbGl6YWNpb246IG5ldyBEYXRlKClcbiAgICAgIH1cbiAgICB9KVxuICB9LFxuICBwcmV2aXN1YWxpemFyICh1cmwpIHtcbiAgICByZXR1cm4gYWN0dWFsaXphcih1cmwpXG4gIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgY2xpcHMsIHBvc3RzIH0gZnJvbSAnL2NvbW1vbi9iYXNlRGVEYXRvcydcbmltcG9ydCB7IHNhbGlyVmFsaWRhY2lvbiB9IGZyb20gJy9zZXJ2ZXIvY29tdW4nXG5pbXBvcnQgSm9pIGZyb20gJ2pvaSdcblxuY29uc3QgdmFsaWRhY2lvbmVzID0ge1xuICBwcmltZXJQb3N0OiBKb2kuc3RyaW5nKClcbn1cblxuTWV0ZW9yLnB1Ymxpc2goJ3JhbmtpbmcnLCBmdW5jdGlvbiAocGFnaW5hID0gMCkge1xuICByZXR1cm4gY2xpcHMuZmluZCh7XG4gICAgcG9zdHM6IHtcbiAgICAgICRndDogMFxuICAgIH1cbiAgfSwge1xuICAgIGZpZWxkczoge1xuICAgICAgc2VjcmV0bzogMCxcbiAgICAgIHNlZ3VyaWRhZDogMFxuICAgIH0sXG4gICAgc29ydDoge1xuICAgICAgYXBveW9zOiAtMVxuICAgIH0sXG4gICAgc2tpcDogMTAgKiBwYWdpbmEsXG4gICAgbGltaXQ6IDEwXG4gIH0pXG59KVxuXG5NZXRlb3IucHVibGlzaCgnYnVzcXVlZGEnLCBmdW5jdGlvbiAoYnVzcXVlZGEsIHBhZ2luYSA9IDApIHtcbiAgdmFyIHJlZ2V4ID0gLyg/OikvXG4gIHRyeSB7XG4gICAgcmVnZXggPSBuZXcgUmVnRXhwKGJ1c3F1ZWRhKVxuICB9IGNhdGNoIChlKSB7XG4gICAgcmVnZXggPSAvJF4vXG4gIH1cbiAgcmV0dXJuIGNsaXBzLmZpbmQoe1xuICAgIHRpdHVsbzogcmVnZXgsXG4gICAgcG9zdHM6IHtcbiAgICAgICRndDogMFxuICAgIH1cbiAgfSwge1xuICAgIGZpZWxkczoge1xuICAgICAgc2VjcmV0bzogMCxcbiAgICAgIHNlZ3VyaWRhZDogMFxuICAgIH0sXG4gICAgc29ydDoge1xuICAgICAgYXBveW9zOiAtMVxuICAgIH0sXG4gICAgc2tpcDogMTAgKiBwYWdpbmEsXG4gICAgbGltaXQ6IDEwXG4gIH0pXG59KVxuXG5NZXRlb3IucHVibGlzaCgncHJpbWVyUG9zdCcsIGZ1bmN0aW9uIChjbGlwSWQpIHtcbiAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICBkYXRhOiBjbGlwSWQsXG4gICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMucHJpbWVyUG9zdCxcbiAgICBkZWJ1Zzoge1xuICAgICAgZG9uZGU6ICdwdWJsaXNoIGNsaXAnXG4gICAgfVxuICB9KVxuXG4gIHJldHVybiBwb3N0cy5maW5kKHtcbiAgICBjbGlwSWQsXG4gICAgc3RhdHVzOiAnVklTSUJMRSdcbiAgfSwge1xuICAgIHNvcnQ6IHtcbiAgICAgIHByaW9yaWRhZDogLTEsXG4gICAgICB0aW1lc3RhbXA6IC0xXG4gICAgfSxcbiAgICBsaW1pdDogMVxuICB9KVxufSlcbiJdfQ==
