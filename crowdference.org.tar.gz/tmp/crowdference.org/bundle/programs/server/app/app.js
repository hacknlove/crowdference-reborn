var require = meteorInstall({"common":{"baseDeDatos.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// common/baseDeDatos.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  clips: () => clips,
  posts: () => posts,
  misClips: () => misClips
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
const clips = new Mongo.Collection('clips');
const posts = new Mongo.Collection('posts');
var misClips;

if (Meteor.isClient) {
  module.runSetters(misClips = new Mongo.Collection(null));
  /* eslint-disable-next-line */

  new PersistentMinimongo2(misClips, 'misClips');
}

if (Meteor.isDevelopment) {
  global.misClips = misClips;
  global.clips = clips;
  global.posts = posts;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"varios.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// common/varios.js                                                                                                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  tituloAUrl: () => tituloAUrl
});
const diacriticas = {
  á: 'a',
  é: 'e',
  í: 'i',
  ó: 'o',
  ú: 'u',
  ñ: 'n',
  ç: 'c'
};

const tituloAUrl = function tituloAUrl(titulo) {
  return (titulo || '').toLowerCase().replace(/[ ]/g, '-').replace(/[áéíúóüñ]/g, function (letra) {
    return diacriticas[letra];
  }).replace(/[^a-z0-9 _.-]/g, '');
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"busqueda.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/busqueda.js                                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let clips;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  }

}, 1);
Meteor.publish('busqueda', function (busqueda, pagina = 0) {
  var regex = /(?:)/;

  try {
    regex = new RegExp(busqueda);
  } catch (e) {
    regex = /$^/;
  }

  return clips.find({
    titulo: regex,
    posts: {
      $gt: 0
    }
  }, {
    sort: {
      apoyos: -1
    },
    skip: 10 * pagina,
    limit: 10
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"clip.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/clip.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 1);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 2);
let salirValidacion, salir;
module.link("/server/comun", {
  salirValidacion(v) {
    salirValidacion = v;
  },

  salir(v) {
    salir = v;
  }

}, 3);
let tituloAUrl;
module.link("/common/varios", {
  tituloAUrl(v) {
    tituloAUrl = v;
  }

}, 4);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 5);
const validaciones = {
  revocar: Joi.object().keys({
    clipId: Joi.string().required(),
    seguridad: Joi.string().required(),
    llave: Joi.string().valid(['seguridad', 'secreto']).required()
  }),
  establecerStatus: Joi.object().keys({
    clipId: Joi.string().required(),
    postId: Joi.string().required(),
    secreto: Joi.string().required(),
    status: Joi.string().valid(['RECHAZADO', 'OCULTO', 'VISIBLE']).required()
  }),
  eliminarPost: Joi.object().keys({
    clipId: Joi.string().required(),
    postId: Joi.string().required(),
    secreto: Joi.string().required()
  }),
  clipPublish: Joi.object().keys({
    url: Joi.string().regex(/^[a-z-]+$/).required(),
    secreto: Joi.string()
  }),
  agregarPost: Joi.object().keys({
    url: Joi.string().regex(/^[a-z-]+$/).required(),
    link: Joi.string().required(),
    rrss: Joi.string().valid(['facebook', 'instagram', 'twitter', 'youtube']).required(),
    secreto: Joi.string()
  }),
  titulo: Joi.string()
};
Meteor.methods({
  crearClip(titulo) {
    salirValidacion({
      data: titulo,
      schema: validaciones.titulo,
      debug: {
        donde: 'method crearClip'
      }
    });

    if (clips.find({
      titulo
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'titulo repetido');
    }

    const url = tituloAUrl(titulo);

    if (clips.find({
      url
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'url repetida');
    }

    const secreto = Random.secret();
    const seguridad = Random.secret();
    const clipId = clips.insert({
      creacion: new Date(),
      titulo,
      url,
      secreto,
      seguridad
    });
    return {
      clipId,
      secreto,
      seguridad
    };
  },

  agregarPost(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.agregarPost,
      debug: {
        donde: 'method agregarPost'
      }
    });
    const clip = clips.findOne({
      url: opciones.url,
      secreto: opciones.secreto || {
        $exists: 1
      }
    }) || salir(404, 'Clip no encontrado', {
      donde: 'method agregarPost'
    });

    if (posts.findOne({
      clipId: clip._id,
      link: opciones.link
    })) {
      return;
    }

    posts.insert({
      clipId: clip._id,
      rrss: opciones.rrss,
      link: opciones.link,
      timestamp: new Date(),
      status: opciones.secreto ? 'VISIBLE' : 'PENDIENTE'
    });

    if (opciones.secreto) {
      clips.update({
        _id: clip._id
      }, {
        $inc: {
          posts: 1
        }
      });
    }
  },

  testTitulo(titulo) {
    salirValidacion({
      data: titulo,
      schema: validaciones.titulo,
      debug: {
        donde: 'method testTitulo'
      }
    }); // if (clips.find({
    //   titulo
    // }, {
    //   limit: 1
    // }).count()) {
    //   console.log('titulo repetido')
    //   throw new Meteor.Error(400, 'titulo repetido')
    // }

    const url = tituloAUrl(titulo);

    if (clips.find({
      url
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'url repetida');
    }
  },

  establecerStatus(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.establecerStatus,
      debug: {
        donde: 'method establecerStatus'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method establecerStatus'
    });
    clips.find({
      _id: opciones.clipId,
      secreto: opciones.secreto
    }).count() || salir(401, 'No tienes permiso para administrar el clip', {
      donde: 'method establecerStatus'
    });
    posts.find({
      _id: opciones.postId,
      clipId: opciones.clipId
    }).count() || salir(404, 'Post no encontrado');
    posts.update(opciones.postId, {
      $set: {
        status: opciones.status
      }
    });
  },

  eliminarPost(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.eliminarPost,
      debug: {
        donde: 'method establecerStatus'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method establecerStatus'
    });
    clips.find({
      _id: opciones.clipId,
      secreto: opciones.secreto
    }).count() || salir(401, 'No tienes permiso para administrar el clip', {
      donde: 'method establecerStatus'
    });
    posts.find({
      _id: opciones.postId,
      clipId: opciones.clipId
    }).count() || salir(404, 'Post no encontrado');
    posts.remove(opciones.postId);
  },

  revocar(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.revocar,
      debug: {
        donde: 'method revocar'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado', {
      donde: 'method revocar'
    });
    clips.find({
      _id: opciones.clipId,
      seguridad: opciones.seguridad
    }).count() || salir(400, 'No tienes permiso para revocar llaves', {
      donde: 'method revocar'
    });
    const llave = Random.secret();
    clips.update(opciones.clipId, {
      $set: {
        [opciones.llave]: llave
      }
    });
    return llave;
  }

});
Meteor.publish('clip', function (opciones) {
  salirValidacion({
    data: opciones,
    schema: validaciones.clipPublish,
    debug: {
      donde: 'publish clip'
    }
  });
  const clip = clips.findOne({
    url: opciones.url
  }) || salir(404, 'Clip no encontrado', {
    donde: 'method agregarPost'
  });
  opciones.secreto && clip.secreto !== opciones.secreto && salir(401, 'No tienes permiso', {
    donde: 'method agregarPost'
  });
  const postsQuery = {
    clipId: clip._id
  };

  if (!opciones.secreto) {
    postsQuery.status = 'VISIBLE';
  }

  return [clips.find(clip._id, {
    fields: {
      seguridad: 0,
      secreto: 0
    }
  }), posts.find(postsQuery)];
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comun.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/comun.js                                                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  salir: () => salir,
  salirValidacion: () => salirValidacion
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 1);

const salir = function salir(codigo, mensaje, debug) {
  if (debug) {
    console.log(codigo, mensaje);
    console.log(JSON.stringify(debug, null, 2));
  }

  throw new Meteor.Error(codigo, mensaje);
};

const salirValidacion = function (opciones) {
  const validacion = Joi.validate(opciones.data, opciones.schema);

  if (!validacion.error) {
    return;
  }

  opciones = Object.assign({
    codigo: 400,
    mensaje: validacion.error.details[0].message
  }, opciones);

  if (opciones.debug) {
    opciones.debug.details = validacion.error.details;
    opciones.debug._object = validacion.error._object;
  }

  salir(opciones.codigo, opciones.mensaje, opciones.debug);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"likes.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/likes.js                                                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let cheerio;
module.link("cheerio", {
  default(v) {
    cheerio = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 3);
let moment;
module.link("moment", {
  default(v) {
    moment = v;
  }

}, 4);
const rrss = {
  instagram: {
    obtenerApoyos(url) {
      const html = HTTP.get(url);
      const $ = cheerio.load(html.content);
      return JSON.parse($('script[type="application/ld+json"]').html()).interactionStatistic.userInteractionCount;
    }

  },
  youtube: {
    regex: /(^|=|\/)([0-9A-Za-z_-]{11})(\/|&|$|\?|#)/,

    obtenerApoyos(url) {
      const youtube = url.match(rrss.youtube.regex);

      if (!youtube) {
        return;
      }

      const data = JSON.parse(HTTP.get(`https://www.googleapis.com/youtube/v3/videos?id=${youtube[2]}&key=${Meteor.settings.private.youtubeAPI}&part=statistics`).content).items[0].statistics;
      return data.likeCount - data.dislikeCount;
    }

  },
  twitter: {
    obtenerApoyos(url) {
      const html = HTTP.get(url);
      const $ = cheerio.load(html.content);
      var stats = $('ul.stats');
      const retweeted = (stats.find('.request-retweeted-popup').data() || {
        tweetStatCount: 0
      }).tweetStatCount * 1;
      const favorited = (stats.find('.request-favorited-popup').data() || {
        tweetStatCount: 0
      }).tweetStatCount * 1;
      return retweeted + favorited;
    }

  },
  facebook: {
    obtenerApoyos(url) {
      return 0;
    }

  }
};

const obtenerApoyos = function obtenerApoyos(post) {
  return (rrss[post.rrss].obtenerApoyos(post.link) || 0) * 1;
};

Meteor.methods({
  actualizarApoyos(clipId, forzar) {
    if (!forzar && clips.findOne({
      _id: clipId,
      actualizacion: {
        $gt: moment().subtract(1, 'hour').toDate()
      }
    })) {
      return;
    }

    var apoyos = 0;
    posts.find({
      clipId,
      status: 'VISIBLE'
    }).forEach(post => {
      const misApoyos = obtenerApoyos(post);
      posts.update({
        _id: post._id
      }, {
        $set: {
          apoyos: misApoyos
        }
      });
      apoyos += misApoyos;
    });
    clips.update({
      _id: clipId
    }, {
      $set: {
        apoyos,
        actualizacion: new Date()
      }
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ranking.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/ranking.js                                                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 1);
Meteor.publish('ranking', function (pagina = 0) {
  return clips.find({
    posts: {
      $gt: 0
    }
  }, {
    sort: {
      apoyos: -1
    },
    skip: 10 * pagina,
    limit: 10
  });
});
Meteor.publish('primerPost', function (clipId) {
  return posts.find({
    clipId,
    status: 'VISIBLE'
  }, {
    sort: {
      timestamp: -1
    },
    limit: 1
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/common/baseDeDatos.js");
require("/common/varios.js");
require("/server/busqueda.js");
require("/server/clip.js");
require("/server/comun.js");
require("/server/likes.js");
require("/server/ranking.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29tbW9uL2Jhc2VEZURhdG9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb21tb24vdmFyaW9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvYnVzcXVlZGEuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9jbGlwLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29tdW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9saWtlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JhbmtpbmcuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiY2xpcHMiLCJwb3N0cyIsIm1pc0NsaXBzIiwiTW9uZ28iLCJsaW5rIiwidiIsIk1ldGVvciIsIkNvbGxlY3Rpb24iLCJpc0NsaWVudCIsIlBlcnNpc3RlbnRNaW5pbW9uZ28yIiwiaXNEZXZlbG9wbWVudCIsImdsb2JhbCIsInRpdHVsb0FVcmwiLCJkaWFjcml0aWNhcyIsIsOhIiwiw6kiLCLDrSIsIsOzIiwiw7oiLCLDsSIsIsOnIiwidGl0dWxvIiwidG9Mb3dlckNhc2UiLCJyZXBsYWNlIiwibGV0cmEiLCJwdWJsaXNoIiwiYnVzcXVlZGEiLCJwYWdpbmEiLCJyZWdleCIsIlJlZ0V4cCIsImUiLCJmaW5kIiwiJGd0Iiwic29ydCIsImFwb3lvcyIsInNraXAiLCJsaW1pdCIsIlJhbmRvbSIsInNhbGlyVmFsaWRhY2lvbiIsInNhbGlyIiwiSm9pIiwiZGVmYXVsdCIsInZhbGlkYWNpb25lcyIsInJldm9jYXIiLCJvYmplY3QiLCJrZXlzIiwiY2xpcElkIiwic3RyaW5nIiwicmVxdWlyZWQiLCJzZWd1cmlkYWQiLCJsbGF2ZSIsInZhbGlkIiwiZXN0YWJsZWNlclN0YXR1cyIsInBvc3RJZCIsInNlY3JldG8iLCJzdGF0dXMiLCJlbGltaW5hclBvc3QiLCJjbGlwUHVibGlzaCIsInVybCIsImFncmVnYXJQb3N0IiwicnJzcyIsIm1ldGhvZHMiLCJjcmVhckNsaXAiLCJkYXRhIiwic2NoZW1hIiwiZGVidWciLCJkb25kZSIsImNvdW50IiwiRXJyb3IiLCJzZWNyZXQiLCJpbnNlcnQiLCJjcmVhY2lvbiIsIkRhdGUiLCJvcGNpb25lcyIsImNsaXAiLCJmaW5kT25lIiwiJGV4aXN0cyIsIl9pZCIsInRpbWVzdGFtcCIsInVwZGF0ZSIsIiRpbmMiLCJ0ZXN0VGl0dWxvIiwiJHNldCIsInJlbW92ZSIsInBvc3RzUXVlcnkiLCJmaWVsZHMiLCJjb2RpZ28iLCJtZW5zYWplIiwiY29uc29sZSIsImxvZyIsIkpTT04iLCJzdHJpbmdpZnkiLCJ2YWxpZGFjaW9uIiwidmFsaWRhdGUiLCJlcnJvciIsIk9iamVjdCIsImFzc2lnbiIsImRldGFpbHMiLCJtZXNzYWdlIiwiX29iamVjdCIsImNoZWVyaW8iLCJIVFRQIiwibW9tZW50IiwiaW5zdGFncmFtIiwib2J0ZW5lckFwb3lvcyIsImh0bWwiLCJnZXQiLCIkIiwibG9hZCIsImNvbnRlbnQiLCJwYXJzZSIsImludGVyYWN0aW9uU3RhdGlzdGljIiwidXNlckludGVyYWN0aW9uQ291bnQiLCJ5b3V0dWJlIiwibWF0Y2giLCJzZXR0aW5ncyIsInByaXZhdGUiLCJ5b3V0dWJlQVBJIiwiaXRlbXMiLCJzdGF0aXN0aWNzIiwibGlrZUNvdW50IiwiZGlzbGlrZUNvdW50IiwidHdpdHRlciIsInN0YXRzIiwicmV0d2VldGVkIiwidHdlZXRTdGF0Q291bnQiLCJmYXZvcml0ZWQiLCJmYWNlYm9vayIsInBvc3QiLCJhY3R1YWxpemFyQXBveW9zIiwiZm9yemFyIiwiYWN0dWFsaXphY2lvbiIsInN1YnRyYWN0IiwidG9EYXRlIiwiZm9yRWFjaCIsIm1pc0Fwb3lvcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsT0FBSyxFQUFDLE1BQUlBLEtBQVg7QUFBaUJDLE9BQUssRUFBQyxNQUFJQSxLQUEzQjtBQUFpQ0MsVUFBUSxFQUFDLE1BQUlBO0FBQTlDLENBQWQ7QUFBdUUsSUFBSUMsS0FBSjtBQUFVTCxNQUFNLENBQUNNLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNELE9BQUssQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFNBQUssR0FBQ0UsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJQyxNQUFKO0FBQVdSLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBR3ZJLE1BQU1MLEtBQUssR0FBRyxJQUFJRyxLQUFLLENBQUNJLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUNBLE1BQU1OLEtBQUssR0FBRyxJQUFJRSxLQUFLLENBQUNJLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUNBLElBQUlMLFFBQUo7O0FBRVAsSUFBSUksTUFBTSxDQUFDRSxRQUFYLEVBQXFCO0FBQ25CLG9CQUFBTixRQUFRLEdBQUcsSUFBSUMsS0FBSyxDQUFDSSxVQUFWLENBQXFCLElBQXJCLENBQVg7QUFDQTs7QUFDQSxNQUFJRSxvQkFBSixDQUF5QlAsUUFBekIsRUFBbUMsVUFBbkM7QUFDRDs7QUFFRCxJQUFJSSxNQUFNLENBQUNJLGFBQVgsRUFBMEI7QUFDeEJDLFFBQU0sQ0FBQ1QsUUFBUCxHQUFrQkEsUUFBbEI7QUFDQVMsUUFBTSxDQUFDWCxLQUFQLEdBQWVBLEtBQWY7QUFDQVcsUUFBTSxDQUFDVixLQUFQLEdBQWVBLEtBQWY7QUFDRCxDOzs7Ozs7Ozs7OztBQ2pCREgsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ2EsWUFBVSxFQUFDLE1BQUlBO0FBQWhCLENBQWQ7QUFBQSxNQUFNQyxXQUFXLEdBQUc7QUFDbEJDLEdBQUMsRUFBRSxHQURlO0FBRWxCQyxHQUFDLEVBQUUsR0FGZTtBQUdsQkMsR0FBQyxFQUFFLEdBSGU7QUFJbEJDLEdBQUMsRUFBRSxHQUplO0FBS2xCQyxHQUFDLEVBQUUsR0FMZTtBQU1sQkMsR0FBQyxFQUFFLEdBTmU7QUFPbEJDLEdBQUMsRUFBRTtBQVBlLENBQXBCOztBQVVPLE1BQU1SLFVBQVUsR0FBRyxTQUFTQSxVQUFULENBQXFCUyxNQUFyQixFQUE2QjtBQUNyRCxTQUFPLENBQUNBLE1BQU0sSUFBSSxFQUFYLEVBQWVDLFdBQWYsR0FBNkJDLE9BQTdCLENBQXFDLE1BQXJDLEVBQTZDLEdBQTdDLEVBQWtEQSxPQUFsRCxDQUEwRCxZQUExRCxFQUF3RSxVQUFVQyxLQUFWLEVBQWlCO0FBQzlGLFdBQU9YLFdBQVcsQ0FBQ1csS0FBRCxDQUFsQjtBQUNELEdBRk0sRUFFSkQsT0FGSSxDQUVJLGdCQUZKLEVBRXNCLEVBRnRCLENBQVA7QUFHRCxDQUpNLEM7Ozs7Ozs7Ozs7O0FDVlAsSUFBSWpCLE1BQUo7QUFBV1IsTUFBTSxDQUFDTSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUwsS0FBSjtBQUFVRixNQUFNLENBQUNNLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDSixPQUFLLENBQUNLLENBQUQsRUFBRztBQUFDTCxTQUFLLEdBQUNLLENBQU47QUFBUTs7QUFBbEIsQ0FBbEMsRUFBc0QsQ0FBdEQ7QUFHMUVDLE1BQU0sQ0FBQ21CLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLFVBQVVDLFFBQVYsRUFBb0JDLE1BQU0sR0FBRyxDQUE3QixFQUFnQztBQUN6RCxNQUFJQyxLQUFLLEdBQUcsTUFBWjs7QUFDQSxNQUFJO0FBQ0ZBLFNBQUssR0FBRyxJQUFJQyxNQUFKLENBQVdILFFBQVgsQ0FBUjtBQUNELEdBRkQsQ0FFRSxPQUFPSSxDQUFQLEVBQVU7QUFDVkYsU0FBSyxHQUFHLElBQVI7QUFDRDs7QUFDRCxTQUFPNUIsS0FBSyxDQUFDK0IsSUFBTixDQUFXO0FBQ2hCVixVQUFNLEVBQUVPLEtBRFE7QUFFaEIzQixTQUFLLEVBQUU7QUFDTCtCLFNBQUcsRUFBRTtBQURBO0FBRlMsR0FBWCxFQUtKO0FBQ0RDLFFBQUksRUFBRTtBQUNKQyxZQUFNLEVBQUUsQ0FBQztBQURMLEtBREw7QUFJREMsUUFBSSxFQUFFLEtBQUtSLE1BSlY7QUFLRFMsU0FBSyxFQUFFO0FBTE4sR0FMSSxDQUFQO0FBWUQsQ0FuQkQsRTs7Ozs7Ozs7Ozs7QUNIQSxJQUFJOUIsTUFBSjtBQUFXUixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJZ0MsTUFBSjtBQUFXdkMsTUFBTSxDQUFDTSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDaUMsUUFBTSxDQUFDaEMsQ0FBRCxFQUFHO0FBQUNnQyxVQUFNLEdBQUNoQyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlMLEtBQUosRUFBVUMsS0FBVjtBQUFnQkgsTUFBTSxDQUFDTSxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ0osT0FBSyxDQUFDSyxDQUFELEVBQUc7QUFBQ0wsU0FBSyxHQUFDSyxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CSixPQUFLLENBQUNJLENBQUQsRUFBRztBQUFDSixTQUFLLEdBQUNJLENBQU47QUFBUTs7QUFBcEMsQ0FBbEMsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSWlDLGVBQUosRUFBb0JDLEtBQXBCO0FBQTBCekMsTUFBTSxDQUFDTSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDa0MsaUJBQWUsQ0FBQ2pDLENBQUQsRUFBRztBQUFDaUMsbUJBQWUsR0FBQ2pDLENBQWhCO0FBQWtCLEdBQXRDOztBQUF1Q2tDLE9BQUssQ0FBQ2xDLENBQUQsRUFBRztBQUFDa0MsU0FBSyxHQUFDbEMsQ0FBTjtBQUFROztBQUF4RCxDQUE1QixFQUFzRixDQUF0RjtBQUF5RixJQUFJTyxVQUFKO0FBQWVkLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNRLFlBQVUsQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNPLGNBQVUsR0FBQ1AsQ0FBWDtBQUFhOztBQUE1QixDQUE3QixFQUEyRCxDQUEzRDtBQUE4RCxJQUFJbUMsR0FBSjtBQUFRMUMsTUFBTSxDQUFDTSxJQUFQLENBQVksS0FBWixFQUFrQjtBQUFDcUMsU0FBTyxDQUFDcEMsQ0FBRCxFQUFHO0FBQUNtQyxPQUFHLEdBQUNuQyxDQUFKO0FBQU07O0FBQWxCLENBQWxCLEVBQXNDLENBQXRDO0FBUW5hLE1BQU1xQyxZQUFZLEdBQUc7QUFDbkJDLFNBQU8sRUFBRUgsR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDekJDLFVBQU0sRUFBRU4sR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFEaUI7QUFFekJDLGFBQVMsRUFBRVQsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFGYztBQUd6QkUsU0FBSyxFQUFFVixHQUFHLENBQUNPLE1BQUosR0FBYUksS0FBYixDQUFtQixDQUFDLFdBQUQsRUFBYyxTQUFkLENBQW5CLEVBQTZDSCxRQUE3QztBQUhrQixHQUFsQixDQURVO0FBTW5CSSxrQkFBZ0IsRUFBRVosR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDbENDLFVBQU0sRUFBRU4sR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFEMEI7QUFFbENLLFVBQU0sRUFBRWIsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFGMEI7QUFHbENNLFdBQU8sRUFBRWQsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFIeUI7QUFJbENPLFVBQU0sRUFBRWYsR0FBRyxDQUFDTyxNQUFKLEdBQWFJLEtBQWIsQ0FBbUIsQ0FBQyxXQUFELEVBQWMsUUFBZCxFQUF3QixTQUF4QixDQUFuQixFQUF1REgsUUFBdkQ7QUFKMEIsR0FBbEIsQ0FOQztBQVluQlEsY0FBWSxFQUFFaEIsR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDOUJDLFVBQU0sRUFBRU4sR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFEc0I7QUFFOUJLLFVBQU0sRUFBRWIsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFGc0I7QUFHOUJNLFdBQU8sRUFBRWQsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWI7QUFIcUIsR0FBbEIsQ0FaSztBQWlCbkJTLGFBQVcsRUFBRWpCLEdBQUcsQ0FBQ0ksTUFBSixHQUFhQyxJQUFiLENBQWtCO0FBQzdCYSxPQUFHLEVBQUVsQixHQUFHLENBQUNPLE1BQUosR0FBYW5CLEtBQWIsQ0FBbUIsV0FBbkIsRUFBZ0NvQixRQUFoQyxFQUR3QjtBQUU3Qk0sV0FBTyxFQUFFZCxHQUFHLENBQUNPLE1BQUo7QUFGb0IsR0FBbEIsQ0FqQk07QUFxQm5CWSxhQUFXLEVBQUVuQixHQUFHLENBQUNJLE1BQUosR0FBYUMsSUFBYixDQUFrQjtBQUM3QmEsT0FBRyxFQUFFbEIsR0FBRyxDQUFDTyxNQUFKLEdBQWFuQixLQUFiLENBQW1CLFdBQW5CLEVBQWdDb0IsUUFBaEMsRUFEd0I7QUFFN0I1QyxRQUFJLEVBQUVvQyxHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUZ1QjtBQUc3QlksUUFBSSxFQUFFcEIsR0FBRyxDQUFDTyxNQUFKLEdBQWFJLEtBQWIsQ0FBbUIsQ0FBQyxVQUFELEVBQWEsV0FBYixFQUEwQixTQUExQixFQUFxQyxTQUFyQyxDQUFuQixFQUFvRUgsUUFBcEUsRUFIdUI7QUFJN0JNLFdBQU8sRUFBRWQsR0FBRyxDQUFDTyxNQUFKO0FBSm9CLEdBQWxCLENBckJNO0FBMkJuQjFCLFFBQU0sRUFBRW1CLEdBQUcsQ0FBQ08sTUFBSjtBQTNCVyxDQUFyQjtBQThCQXpDLE1BQU0sQ0FBQ3VELE9BQVAsQ0FBZTtBQUNiQyxXQUFTLENBQUV6QyxNQUFGLEVBQVU7QUFDakJpQixtQkFBZSxDQUFDO0FBQ2R5QixVQUFJLEVBQUUxQyxNQURRO0FBRWQyQyxZQUFNLEVBQUV0QixZQUFZLENBQUNyQixNQUZQO0FBR2Q0QyxXQUFLLEVBQUU7QUFDTEMsYUFBSyxFQUFFO0FBREY7QUFITyxLQUFELENBQWY7O0FBUUEsUUFBSWxFLEtBQUssQ0FBQytCLElBQU4sQ0FBVztBQUNiVjtBQURhLEtBQVgsRUFFRDtBQUNEZSxXQUFLLEVBQUU7QUFETixLQUZDLEVBSUQrQixLQUpDLEVBQUosRUFJWTtBQUNWLFlBQU0sSUFBSTdELE1BQU0sQ0FBQzhELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsaUJBQXRCLENBQU47QUFDRDs7QUFDRCxVQUFNVixHQUFHLEdBQUc5QyxVQUFVLENBQUNTLE1BQUQsQ0FBdEI7O0FBQ0EsUUFBSXJCLEtBQUssQ0FBQytCLElBQU4sQ0FBVztBQUNiMkI7QUFEYSxLQUFYLEVBRUQ7QUFDRHRCLFdBQUssRUFBRTtBQUROLEtBRkMsRUFJRCtCLEtBSkMsRUFBSixFQUlZO0FBQ1YsWUFBTSxJQUFJN0QsTUFBTSxDQUFDOEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixjQUF0QixDQUFOO0FBQ0Q7O0FBRUQsVUFBTWQsT0FBTyxHQUFHakIsTUFBTSxDQUFDZ0MsTUFBUCxFQUFoQjtBQUNBLFVBQU1wQixTQUFTLEdBQUdaLE1BQU0sQ0FBQ2dDLE1BQVAsRUFBbEI7QUFDQSxVQUFNdkIsTUFBTSxHQUFHOUMsS0FBSyxDQUFDc0UsTUFBTixDQUFhO0FBQzFCQyxjQUFRLEVBQUUsSUFBSUMsSUFBSixFQURnQjtBQUUxQm5ELFlBRjBCO0FBRzFCcUMsU0FIMEI7QUFJMUJKLGFBSjBCO0FBSzFCTDtBQUwwQixLQUFiLENBQWY7QUFRQSxXQUFPO0FBQ0xILFlBREs7QUFFTFEsYUFGSztBQUdMTDtBQUhLLEtBQVA7QUFLRCxHQXpDWTs7QUEwQ2JVLGFBQVcsQ0FBRWMsUUFBRixFQUFZO0FBQ3JCbkMsbUJBQWUsQ0FBQztBQUNkeUIsVUFBSSxFQUFFVSxRQURRO0FBRWRULFlBQU0sRUFBRXRCLFlBQVksQ0FBQ2lCLFdBRlA7QUFHZE0sV0FBSyxFQUFFO0FBQ0xDLGFBQUssRUFBRTtBQURGO0FBSE8sS0FBRCxDQUFmO0FBT0EsVUFBTVEsSUFBSSxHQUFHMUUsS0FBSyxDQUFDMkUsT0FBTixDQUFjO0FBQ3pCakIsU0FBRyxFQUFFZSxRQUFRLENBQUNmLEdBRFc7QUFFekJKLGFBQU8sRUFBRW1CLFFBQVEsQ0FBQ25CLE9BQVQsSUFBb0I7QUFDM0JzQixlQUFPLEVBQUU7QUFEa0I7QUFGSixLQUFkLEtBS1ByQyxLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLEVBQTRCO0FBQ3JDMkIsV0FBSyxFQUFFO0FBRDhCLEtBQTVCLENBTFg7O0FBU0EsUUFBSWpFLEtBQUssQ0FBQzBFLE9BQU4sQ0FBYztBQUNoQjdCLFlBQU0sRUFBRTRCLElBQUksQ0FBQ0csR0FERztBQUVoQnpFLFVBQUksRUFBRXFFLFFBQVEsQ0FBQ3JFO0FBRkMsS0FBZCxDQUFKLEVBR0k7QUFDRjtBQUNEOztBQUNESCxTQUFLLENBQUNxRSxNQUFOLENBQWE7QUFDWHhCLFlBQU0sRUFBRTRCLElBQUksQ0FBQ0csR0FERjtBQUVYakIsVUFBSSxFQUFFYSxRQUFRLENBQUNiLElBRko7QUFHWHhELFVBQUksRUFBRXFFLFFBQVEsQ0FBQ3JFLElBSEo7QUFJWDBFLGVBQVMsRUFBRSxJQUFJTixJQUFKLEVBSkE7QUFLWGpCLFlBQU0sRUFBRWtCLFFBQVEsQ0FBQ25CLE9BQVQsR0FBbUIsU0FBbkIsR0FBK0I7QUFMNUIsS0FBYjs7QUFPQSxRQUFJbUIsUUFBUSxDQUFDbkIsT0FBYixFQUFzQjtBQUNwQnRELFdBQUssQ0FBQytFLE1BQU4sQ0FBYTtBQUNYRixXQUFHLEVBQUVILElBQUksQ0FBQ0c7QUFEQyxPQUFiLEVBRUc7QUFDREcsWUFBSSxFQUFFO0FBQ0ovRSxlQUFLLEVBQUU7QUFESDtBQURMLE9BRkg7QUFPRDtBQUNGLEdBakZZOztBQWtGYmdGLFlBQVUsQ0FBRTVELE1BQUYsRUFBVTtBQUNsQmlCLG1CQUFlLENBQUM7QUFDZHlCLFVBQUksRUFBRTFDLE1BRFE7QUFFZDJDLFlBQU0sRUFBRXRCLFlBQVksQ0FBQ3JCLE1BRlA7QUFHZDRDLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZixDQURrQixDQVFsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFVBQU1SLEdBQUcsR0FBRzlDLFVBQVUsQ0FBQ1MsTUFBRCxDQUF0Qjs7QUFDQSxRQUFJckIsS0FBSyxDQUFDK0IsSUFBTixDQUFXO0FBQ2IyQjtBQURhLEtBQVgsRUFFRDtBQUNEdEIsV0FBSyxFQUFFO0FBRE4sS0FGQyxFQUlEK0IsS0FKQyxFQUFKLEVBSVk7QUFDVixZQUFNLElBQUk3RCxNQUFNLENBQUM4RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGNBQXRCLENBQU47QUFDRDtBQUNGLEdBMUdZOztBQTJHYmhCLGtCQUFnQixDQUFFcUIsUUFBRixFQUFZO0FBQzFCbkMsbUJBQWUsQ0FBQztBQUNkeUIsVUFBSSxFQUFFVSxRQURRO0FBRWRULFlBQU0sRUFBRXRCLFlBQVksQ0FBQ1UsZ0JBRlA7QUFHZGEsV0FBSyxFQUFFO0FBQ0xDLGFBQUssRUFBRTtBQURGO0FBSE8sS0FBRCxDQUFmO0FBUUFsRSxTQUFLLENBQUMrQixJQUFOLENBQVc7QUFDVDhDLFNBQUcsRUFBRUosUUFBUSxDQUFDM0I7QUFETCxLQUFYLEVBRUdxQixLQUZILE1BRWM1QixLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLEVBQTRCO0FBQzdDMkIsV0FBSyxFQUFFO0FBRHNDLEtBQTVCLENBRm5CO0FBTUFsRSxTQUFLLENBQUMrQixJQUFOLENBQVc7QUFDVDhDLFNBQUcsRUFBRUosUUFBUSxDQUFDM0IsTUFETDtBQUVUUSxhQUFPLEVBQUVtQixRQUFRLENBQUNuQjtBQUZULEtBQVgsRUFHR2EsS0FISCxNQUdjNUIsS0FBSyxDQUFDLEdBQUQsRUFBTSw0Q0FBTixFQUFvRDtBQUNyRTJCLFdBQUssRUFBRTtBQUQ4RCxLQUFwRCxDQUhuQjtBQU9BakUsU0FBSyxDQUFDOEIsSUFBTixDQUFXO0FBQ1Q4QyxTQUFHLEVBQUVKLFFBQVEsQ0FBQ3BCLE1BREw7QUFFVFAsWUFBTSxFQUFFMkIsUUFBUSxDQUFDM0I7QUFGUixLQUFYLEVBR0dxQixLQUhILE1BR2M1QixLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLENBSG5CO0FBS0F0QyxTQUFLLENBQUM4RSxNQUFOLENBQWFOLFFBQVEsQ0FBQ3BCLE1BQXRCLEVBQThCO0FBQzVCNkIsVUFBSSxFQUFFO0FBQ0ozQixjQUFNLEVBQUVrQixRQUFRLENBQUNsQjtBQURiO0FBRHNCLEtBQTlCO0FBS0QsR0EzSVk7O0FBNEliQyxjQUFZLENBQUVpQixRQUFGLEVBQVk7QUFDdEJuQyxtQkFBZSxDQUFDO0FBQ2R5QixVQUFJLEVBQUVVLFFBRFE7QUFFZFQsWUFBTSxFQUFFdEIsWUFBWSxDQUFDYyxZQUZQO0FBR2RTLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZjtBQVFBbEUsU0FBSyxDQUFDK0IsSUFBTixDQUFXO0FBQ1Q4QyxTQUFHLEVBQUVKLFFBQVEsQ0FBQzNCO0FBREwsS0FBWCxFQUVHcUIsS0FGSCxNQUVjNUIsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixFQUE0QjtBQUM3QzJCLFdBQUssRUFBRTtBQURzQyxLQUE1QixDQUZuQjtBQU1BbEUsU0FBSyxDQUFDK0IsSUFBTixDQUFXO0FBQ1Q4QyxTQUFHLEVBQUVKLFFBQVEsQ0FBQzNCLE1BREw7QUFFVFEsYUFBTyxFQUFFbUIsUUFBUSxDQUFDbkI7QUFGVCxLQUFYLEVBR0dhLEtBSEgsTUFHYzVCLEtBQUssQ0FBQyxHQUFELEVBQU0sNENBQU4sRUFBb0Q7QUFDckUyQixXQUFLLEVBQUU7QUFEOEQsS0FBcEQsQ0FIbkI7QUFPQWpFLFNBQUssQ0FBQzhCLElBQU4sQ0FBVztBQUNUOEMsU0FBRyxFQUFFSixRQUFRLENBQUNwQixNQURMO0FBRVRQLFlBQU0sRUFBRTJCLFFBQVEsQ0FBQzNCO0FBRlIsS0FBWCxFQUdHcUIsS0FISCxNQUdjNUIsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixDQUhuQjtBQUtBdEMsU0FBSyxDQUFDa0YsTUFBTixDQUFhVixRQUFRLENBQUNwQixNQUF0QjtBQUNELEdBeEtZOztBQXlLYlYsU0FBTyxDQUFFOEIsUUFBRixFQUFZO0FBQ2pCbkMsbUJBQWUsQ0FBQztBQUNkeUIsVUFBSSxFQUFFVSxRQURRO0FBRWRULFlBQU0sRUFBRXRCLFlBQVksQ0FBQ0MsT0FGUDtBQUdkc0IsV0FBSyxFQUFFO0FBQ0xDLGFBQUssRUFBRTtBQURGO0FBSE8sS0FBRCxDQUFmO0FBUUFsRSxTQUFLLENBQUMrQixJQUFOLENBQVc7QUFDVDhDLFNBQUcsRUFBRUosUUFBUSxDQUFDM0I7QUFETCxLQUFYLEVBRUdxQixLQUZILE1BRWM1QixLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLEVBQTRCO0FBQzdDMkIsV0FBSyxFQUFFO0FBRHNDLEtBQTVCLENBRm5CO0FBTUFsRSxTQUFLLENBQUMrQixJQUFOLENBQVc7QUFDVDhDLFNBQUcsRUFBRUosUUFBUSxDQUFDM0IsTUFETDtBQUVURyxlQUFTLEVBQUV3QixRQUFRLENBQUN4QjtBQUZYLEtBQVgsRUFHR2tCLEtBSEgsTUFHYzVCLEtBQUssQ0FBQyxHQUFELEVBQU0sdUNBQU4sRUFBK0M7QUFDaEUyQixXQUFLLEVBQUU7QUFEeUQsS0FBL0MsQ0FIbkI7QUFPQSxVQUFNaEIsS0FBSyxHQUFHYixNQUFNLENBQUNnQyxNQUFQLEVBQWQ7QUFFQXJFLFNBQUssQ0FBQytFLE1BQU4sQ0FBYU4sUUFBUSxDQUFDM0IsTUFBdEIsRUFBOEI7QUFDNUJvQyxVQUFJLEVBQUU7QUFDSixTQUFDVCxRQUFRLENBQUN2QixLQUFWLEdBQWtCQTtBQURkO0FBRHNCLEtBQTlCO0FBS0EsV0FBT0EsS0FBUDtBQUNEOztBQXZNWSxDQUFmO0FBME1BNUMsTUFBTSxDQUFDbUIsT0FBUCxDQUFlLE1BQWYsRUFBdUIsVUFBVWdELFFBQVYsRUFBb0I7QUFDekNuQyxpQkFBZSxDQUFDO0FBQ2R5QixRQUFJLEVBQUVVLFFBRFE7QUFFZFQsVUFBTSxFQUFFdEIsWUFBWSxDQUFDZSxXQUZQO0FBR2RRLFNBQUssRUFBRTtBQUNMQyxXQUFLLEVBQUU7QUFERjtBQUhPLEdBQUQsQ0FBZjtBQU9BLFFBQU1RLElBQUksR0FBRzFFLEtBQUssQ0FBQzJFLE9BQU4sQ0FBYztBQUN6QmpCLE9BQUcsRUFBRWUsUUFBUSxDQUFDZjtBQURXLEdBQWQsS0FFUG5CLEtBQUssQ0FBQyxHQUFELEVBQU0sb0JBQU4sRUFBNEI7QUFDckMyQixTQUFLLEVBQUU7QUFEOEIsR0FBNUIsQ0FGWDtBQU1BTyxVQUFRLENBQUNuQixPQUFULElBQW9Cb0IsSUFBSSxDQUFDcEIsT0FBTCxLQUFpQm1CLFFBQVEsQ0FBQ25CLE9BQTlDLElBQXlEZixLQUFLLENBQUMsR0FBRCxFQUFNLG1CQUFOLEVBQTJCO0FBQ3ZGMkIsU0FBSyxFQUFFO0FBRGdGLEdBQTNCLENBQTlEO0FBSUEsUUFBTWtCLFVBQVUsR0FBRztBQUNqQnRDLFVBQU0sRUFBRTRCLElBQUksQ0FBQ0c7QUFESSxHQUFuQjs7QUFJQSxNQUFJLENBQUNKLFFBQVEsQ0FBQ25CLE9BQWQsRUFBdUI7QUFDckI4QixjQUFVLENBQUM3QixNQUFYLEdBQW9CLFNBQXBCO0FBQ0Q7O0FBRUQsU0FBTyxDQUNMdkQsS0FBSyxDQUFDK0IsSUFBTixDQUFXMkMsSUFBSSxDQUFDRyxHQUFoQixFQUFxQjtBQUNuQlEsVUFBTSxFQUFFO0FBQ05wQyxlQUFTLEVBQUUsQ0FETDtBQUVOSyxhQUFPLEVBQUU7QUFGSDtBQURXLEdBQXJCLENBREssRUFPTHJELEtBQUssQ0FBQzhCLElBQU4sQ0FBV3FELFVBQVgsQ0FQSyxDQUFQO0FBU0QsQ0FuQ0QsRTs7Ozs7Ozs7Ozs7QUNoUEF0RixNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDd0MsT0FBSyxFQUFDLE1BQUlBLEtBQVg7QUFBaUJELGlCQUFlLEVBQUMsTUFBSUE7QUFBckMsQ0FBZDtBQUFxRSxJQUFJaEMsTUFBSjtBQUFXUixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJbUMsR0FBSjtBQUFRMUMsTUFBTSxDQUFDTSxJQUFQLENBQVksS0FBWixFQUFrQjtBQUFDcUMsU0FBTyxDQUFDcEMsQ0FBRCxFQUFHO0FBQUNtQyxPQUFHLEdBQUNuQyxDQUFKO0FBQU07O0FBQWxCLENBQWxCLEVBQXNDLENBQXRDOztBQUd0SSxNQUFNa0MsS0FBSyxHQUFHLFNBQVNBLEtBQVQsQ0FBZ0IrQyxNQUFoQixFQUF3QkMsT0FBeEIsRUFBaUN0QixLQUFqQyxFQUF3QztBQUMzRCxNQUFJQSxLQUFKLEVBQVc7QUFDVHVCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSCxNQUFaLEVBQW9CQyxPQUFwQjtBQUNBQyxXQUFPLENBQUNDLEdBQVIsQ0FBWUMsSUFBSSxDQUFDQyxTQUFMLENBQWUxQixLQUFmLEVBQXNCLElBQXRCLEVBQTRCLENBQTVCLENBQVo7QUFDRDs7QUFDRCxRQUFNLElBQUkzRCxNQUFNLENBQUM4RCxLQUFYLENBQWlCa0IsTUFBakIsRUFBeUJDLE9BQXpCLENBQU47QUFDRCxDQU5NOztBQVFBLE1BQU1qRCxlQUFlLEdBQUcsVUFBVW1DLFFBQVYsRUFBb0I7QUFDakQsUUFBTW1CLFVBQVUsR0FBR3BELEdBQUcsQ0FBQ3FELFFBQUosQ0FBYXBCLFFBQVEsQ0FBQ1YsSUFBdEIsRUFBNEJVLFFBQVEsQ0FBQ1QsTUFBckMsQ0FBbkI7O0FBQ0EsTUFBSSxDQUFDNEIsVUFBVSxDQUFDRSxLQUFoQixFQUF1QjtBQUNyQjtBQUNEOztBQUNEckIsVUFBUSxHQUFHc0IsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFDdkJWLFVBQU0sRUFBRSxHQURlO0FBRXZCQyxXQUFPLEVBQUVLLFVBQVUsQ0FBQ0UsS0FBWCxDQUFpQkcsT0FBakIsQ0FBeUIsQ0FBekIsRUFBNEJDO0FBRmQsR0FBZCxFQUdSekIsUUFIUSxDQUFYOztBQUlBLE1BQUlBLFFBQVEsQ0FBQ1IsS0FBYixFQUFvQjtBQUNsQlEsWUFBUSxDQUFDUixLQUFULENBQWVnQyxPQUFmLEdBQXlCTCxVQUFVLENBQUNFLEtBQVgsQ0FBaUJHLE9BQTFDO0FBQ0F4QixZQUFRLENBQUNSLEtBQVQsQ0FBZWtDLE9BQWYsR0FBeUJQLFVBQVUsQ0FBQ0UsS0FBWCxDQUFpQkssT0FBMUM7QUFDRDs7QUFDRDVELE9BQUssQ0FBQ2tDLFFBQVEsQ0FBQ2EsTUFBVixFQUFrQmIsUUFBUSxDQUFDYyxPQUEzQixFQUFvQ2QsUUFBUSxDQUFDUixLQUE3QyxDQUFMO0FBQ0QsQ0FkTSxDOzs7Ozs7Ozs7OztBQ1hQLElBQUltQyxPQUFKO0FBQVl0RyxNQUFNLENBQUNNLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUNxQyxTQUFPLENBQUNwQyxDQUFELEVBQUc7QUFBQytGLFdBQU8sR0FBQy9GLENBQVI7QUFBVTs7QUFBdEIsQ0FBdEIsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSWdHLElBQUo7QUFBU3ZHLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ2lHLE1BQUksQ0FBQ2hHLENBQUQsRUFBRztBQUFDZ0csUUFBSSxHQUFDaEcsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJQyxNQUFKO0FBQVdSLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlMLEtBQUosRUFBVUMsS0FBVjtBQUFnQkgsTUFBTSxDQUFDTSxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ0osT0FBSyxDQUFDSyxDQUFELEVBQUc7QUFBQ0wsU0FBSyxHQUFDSyxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CSixPQUFLLENBQUNJLENBQUQsRUFBRztBQUFDSixTQUFLLEdBQUNJLENBQU47QUFBUTs7QUFBcEMsQ0FBbEMsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSWlHLE1BQUo7QUFBV3hHLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ3FDLFNBQU8sQ0FBQ3BDLENBQUQsRUFBRztBQUFDaUcsVUFBTSxHQUFDakcsQ0FBUDtBQUFTOztBQUFyQixDQUFyQixFQUE0QyxDQUE1QztBQU0zUixNQUFNdUQsSUFBSSxHQUFHO0FBQ1gyQyxXQUFTLEVBQUU7QUFDVEMsaUJBQWEsQ0FBRTlDLEdBQUYsRUFBTztBQUNsQixZQUFNK0MsSUFBSSxHQUFHSixJQUFJLENBQUNLLEdBQUwsQ0FBU2hELEdBQVQsQ0FBYjtBQUNBLFlBQU1pRCxDQUFDLEdBQUdQLE9BQU8sQ0FBQ1EsSUFBUixDQUFhSCxJQUFJLENBQUNJLE9BQWxCLENBQVY7QUFDQSxhQUFPbkIsSUFBSSxDQUFDb0IsS0FBTCxDQUFXSCxDQUFDLENBQUMsb0NBQUQsQ0FBRCxDQUF3Q0YsSUFBeEMsRUFBWCxFQUEyRE0sb0JBQTNELENBQWdGQyxvQkFBdkY7QUFDRDs7QUFMUSxHQURBO0FBUVhDLFNBQU8sRUFBRTtBQUNQckYsU0FBSyxFQUFFLDBDQURBOztBQUVQNEUsaUJBQWEsQ0FBRTlDLEdBQUYsRUFBTztBQUNsQixZQUFNdUQsT0FBTyxHQUFHdkQsR0FBRyxDQUFDd0QsS0FBSixDQUFVdEQsSUFBSSxDQUFDcUQsT0FBTCxDQUFhckYsS0FBdkIsQ0FBaEI7O0FBQ0EsVUFBSSxDQUFDcUYsT0FBTCxFQUFjO0FBQ1o7QUFDRDs7QUFDRCxZQUFNbEQsSUFBSSxHQUFHMkIsSUFBSSxDQUFDb0IsS0FBTCxDQUFXVCxJQUFJLENBQUNLLEdBQUwsQ0FBVSxtREFBa0RPLE9BQU8sQ0FBQyxDQUFELENBQUksUUFBTzNHLE1BQU0sQ0FBQzZHLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCQyxVQUFXLGtCQUFqSCxFQUFvSVIsT0FBL0ksRUFBd0pTLEtBQXhKLENBQThKLENBQTlKLEVBQWlLQyxVQUE5SztBQUVBLGFBQU94RCxJQUFJLENBQUN5RCxTQUFMLEdBQWlCekQsSUFBSSxDQUFDMEQsWUFBN0I7QUFDRDs7QUFWTSxHQVJFO0FBb0JYQyxTQUFPLEVBQUU7QUFDUGxCLGlCQUFhLENBQUU5QyxHQUFGLEVBQU87QUFDbEIsWUFBTStDLElBQUksR0FBR0osSUFBSSxDQUFDSyxHQUFMLENBQVNoRCxHQUFULENBQWI7QUFDQSxZQUFNaUQsQ0FBQyxHQUFHUCxPQUFPLENBQUNRLElBQVIsQ0FBYUgsSUFBSSxDQUFDSSxPQUFsQixDQUFWO0FBQ0EsVUFBSWMsS0FBSyxHQUFHaEIsQ0FBQyxDQUFDLFVBQUQsQ0FBYjtBQUNBLFlBQU1pQixTQUFTLEdBQUcsQ0FBQ0QsS0FBSyxDQUFDNUYsSUFBTixDQUFXLDBCQUFYLEVBQXVDZ0MsSUFBdkMsTUFBaUQ7QUFBRThELHNCQUFjLEVBQUU7QUFBbEIsT0FBbEQsRUFBeUVBLGNBQXpFLEdBQTBGLENBQTVHO0FBQ0EsWUFBTUMsU0FBUyxHQUFHLENBQUNILEtBQUssQ0FBQzVGLElBQU4sQ0FBVywwQkFBWCxFQUF1Q2dDLElBQXZDLE1BQWlEO0FBQUU4RCxzQkFBYyxFQUFFO0FBQWxCLE9BQWxELEVBQXlFQSxjQUF6RSxHQUEwRixDQUE1RztBQUNBLGFBQU9ELFNBQVMsR0FBR0UsU0FBbkI7QUFDRDs7QUFSTSxHQXBCRTtBQThCWEMsVUFBUSxFQUFFO0FBQ1J2QixpQkFBYSxDQUFFOUMsR0FBRixFQUFPO0FBQ2xCLGFBQU8sQ0FBUDtBQUNEOztBQUhPO0FBOUJDLENBQWI7O0FBcUNBLE1BQU04QyxhQUFhLEdBQUcsU0FBU0EsYUFBVCxDQUF3QndCLElBQXhCLEVBQThCO0FBQ2xELFNBQU8sQ0FBQ3BFLElBQUksQ0FBQ29FLElBQUksQ0FBQ3BFLElBQU4sQ0FBSixDQUFnQjRDLGFBQWhCLENBQThCd0IsSUFBSSxDQUFDNUgsSUFBbkMsS0FBNEMsQ0FBN0MsSUFBa0QsQ0FBekQ7QUFDRCxDQUZEOztBQUlBRSxNQUFNLENBQUN1RCxPQUFQLENBQWU7QUFDYm9FLGtCQUFnQixDQUFFbkYsTUFBRixFQUFVb0YsTUFBVixFQUFrQjtBQUNoQyxRQUFJLENBQUNBLE1BQUQsSUFBV2xJLEtBQUssQ0FBQzJFLE9BQU4sQ0FBYztBQUMzQkUsU0FBRyxFQUFFL0IsTUFEc0I7QUFFM0JxRixtQkFBYSxFQUFFO0FBQ2JuRyxXQUFHLEVBQUVzRSxNQUFNLEdBQUc4QixRQUFULENBQWtCLENBQWxCLEVBQXFCLE1BQXJCLEVBQTZCQyxNQUE3QjtBQURRO0FBRlksS0FBZCxDQUFmLEVBS0k7QUFDRjtBQUNEOztBQUNELFFBQUluRyxNQUFNLEdBQUcsQ0FBYjtBQUNBakMsU0FBSyxDQUFDOEIsSUFBTixDQUFXO0FBQ1RlLFlBRFM7QUFFVFMsWUFBTSxFQUFFO0FBRkMsS0FBWCxFQUdHK0UsT0FISCxDQUdXTixJQUFJLElBQUk7QUFDakIsWUFBTU8sU0FBUyxHQUFHL0IsYUFBYSxDQUFDd0IsSUFBRCxDQUEvQjtBQUNBL0gsV0FBSyxDQUFDOEUsTUFBTixDQUFhO0FBQ1hGLFdBQUcsRUFBRW1ELElBQUksQ0FBQ25EO0FBREMsT0FBYixFQUVHO0FBQ0RLLFlBQUksRUFBRTtBQUNKaEQsZ0JBQU0sRUFBRXFHO0FBREo7QUFETCxPQUZIO0FBT0FyRyxZQUFNLElBQUlxRyxTQUFWO0FBQ0QsS0FiRDtBQWNBdkksU0FBSyxDQUFDK0UsTUFBTixDQUFhO0FBQ1hGLFNBQUcsRUFBRS9CO0FBRE0sS0FBYixFQUVHO0FBQ0RvQyxVQUFJLEVBQUU7QUFDSmhELGNBREk7QUFFSmlHLHFCQUFhLEVBQUUsSUFBSTNELElBQUo7QUFGWDtBQURMLEtBRkg7QUFRRDs7QUFqQ1ksQ0FBZixFOzs7Ozs7Ozs7OztBQy9DQSxJQUFJbEUsTUFBSjtBQUFXUixNQUFNLENBQUNNLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJTCxLQUFKLEVBQVVDLEtBQVY7QUFBZ0JILE1BQU0sQ0FBQ00sSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNKLE9BQUssQ0FBQ0ssQ0FBRCxFQUFHO0FBQUNMLFNBQUssR0FBQ0ssQ0FBTjtBQUFRLEdBQWxCOztBQUFtQkosT0FBSyxDQUFDSSxDQUFELEVBQUc7QUFBQ0osU0FBSyxHQUFDSSxDQUFOO0FBQVE7O0FBQXBDLENBQWxDLEVBQXdFLENBQXhFO0FBR2hGQyxNQUFNLENBQUNtQixPQUFQLENBQWUsU0FBZixFQUEwQixVQUFVRSxNQUFNLEdBQUcsQ0FBbkIsRUFBc0I7QUFDOUMsU0FBTzNCLEtBQUssQ0FBQytCLElBQU4sQ0FBVztBQUNoQjlCLFNBQUssRUFBRTtBQUNMK0IsU0FBRyxFQUFFO0FBREE7QUFEUyxHQUFYLEVBSUo7QUFDREMsUUFBSSxFQUFFO0FBQ0pDLFlBQU0sRUFBRSxDQUFDO0FBREwsS0FETDtBQUlEQyxRQUFJLEVBQUUsS0FBS1IsTUFKVjtBQUtEUyxTQUFLLEVBQUU7QUFMTixHQUpJLENBQVA7QUFXRCxDQVpEO0FBY0E5QixNQUFNLENBQUNtQixPQUFQLENBQWUsWUFBZixFQUE2QixVQUFVcUIsTUFBVixFQUFrQjtBQUM3QyxTQUFPN0MsS0FBSyxDQUFDOEIsSUFBTixDQUFXO0FBQ2hCZSxVQURnQjtBQUVoQlMsVUFBTSxFQUFFO0FBRlEsR0FBWCxFQUdKO0FBQ0R0QixRQUFJLEVBQUU7QUFDSjZDLGVBQVMsRUFBRSxDQUFDO0FBRFIsS0FETDtBQUlEMUMsU0FBSyxFQUFFO0FBSk4sR0FISSxDQUFQO0FBU0QsQ0FWRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5cbmV4cG9ydCBjb25zdCBjbGlwcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjbGlwcycpXG5leHBvcnQgY29uc3QgcG9zdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncG9zdHMnKVxuZXhwb3J0IHZhciBtaXNDbGlwc1xuXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KSB7XG4gIG1pc0NsaXBzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24obnVsbClcbiAgLyogZXNsaW50LWRpc2FibGUtbmV4dC1saW5lICovXG4gIG5ldyBQZXJzaXN0ZW50TWluaW1vbmdvMihtaXNDbGlwcywgJ21pc0NsaXBzJylcbn1cblxuaWYgKE1ldGVvci5pc0RldmVsb3BtZW50KSB7XG4gIGdsb2JhbC5taXNDbGlwcyA9IG1pc0NsaXBzXG4gIGdsb2JhbC5jbGlwcyA9IGNsaXBzXG4gIGdsb2JhbC5wb3N0cyA9IHBvc3RzXG59XG4iLCJjb25zdCBkaWFjcml0aWNhcyA9IHtcbiAgw6E6ICdhJyxcbiAgw6k6ICdlJyxcbiAgw606ICdpJyxcbiAgw7M6ICdvJyxcbiAgw7o6ICd1JyxcbiAgw7E6ICduJyxcbiAgw6c6ICdjJ1xufVxuXG5leHBvcnQgY29uc3QgdGl0dWxvQVVybCA9IGZ1bmN0aW9uIHRpdHVsb0FVcmwgKHRpdHVsbykge1xuICByZXR1cm4gKHRpdHVsbyB8fCAnJykudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bIF0vZywgJy0nKS5yZXBsYWNlKC9bw6HDqcOtw7rDs8O8w7FdL2csIGZ1bmN0aW9uIChsZXRyYSkge1xuICAgIHJldHVybiBkaWFjcml0aWNhc1tsZXRyYV1cbiAgfSkucmVwbGFjZSgvW15hLXowLTkgXy4tXS9nLCAnJylcbn1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBjbGlwcyB9IGZyb20gJy9jb21tb24vYmFzZURlRGF0b3MnXG5cbk1ldGVvci5wdWJsaXNoKCdidXNxdWVkYScsIGZ1bmN0aW9uIChidXNxdWVkYSwgcGFnaW5hID0gMCkge1xuICB2YXIgcmVnZXggPSAvKD86KS9cbiAgdHJ5IHtcbiAgICByZWdleCA9IG5ldyBSZWdFeHAoYnVzcXVlZGEpXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICByZWdleCA9IC8kXi9cbiAgfVxuICByZXR1cm4gY2xpcHMuZmluZCh7XG4gICAgdGl0dWxvOiByZWdleCxcbiAgICBwb3N0czoge1xuICAgICAgJGd0OiAwXG4gICAgfVxuICB9LCB7XG4gICAgc29ydDoge1xuICAgICAgYXBveW9zOiAtMVxuICAgIH0sXG4gICAgc2tpcDogMTAgKiBwYWdpbmEsXG4gICAgbGltaXQ6IDEwXG4gIH0pXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJhbmRvbSB9IGZyb20gJ21ldGVvci9yYW5kb20nXG5pbXBvcnQgeyBjbGlwcywgcG9zdHMgfSBmcm9tICcvY29tbW9uL2Jhc2VEZURhdG9zJ1xuaW1wb3J0IHsgc2FsaXJWYWxpZGFjaW9uLCBzYWxpciB9IGZyb20gJy9zZXJ2ZXIvY29tdW4nXG5pbXBvcnQgeyB0aXR1bG9BVXJsIH0gZnJvbSAnL2NvbW1vbi92YXJpb3MnXG5cbmltcG9ydCBKb2kgZnJvbSAnam9pJ1xuXG5jb25zdCB2YWxpZGFjaW9uZXMgPSB7XG4gIHJldm9jYXI6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICBjbGlwSWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlZ3VyaWRhZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgbGxhdmU6IEpvaS5zdHJpbmcoKS52YWxpZChbJ3NlZ3VyaWRhZCcsICdzZWNyZXRvJ10pLnJlcXVpcmVkKClcbiAgfSksXG4gIGVzdGFibGVjZXJTdGF0dXM6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICBjbGlwSWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHBvc3RJZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgc2VjcmV0bzogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgc3RhdHVzOiBKb2kuc3RyaW5nKCkudmFsaWQoWydSRUNIQVpBRE8nLCAnT0NVTFRPJywgJ1ZJU0lCTEUnXSkucmVxdWlyZWQoKVxuICB9KSxcbiAgZWxpbWluYXJQb3N0OiBKb2kub2JqZWN0KCkua2V5cyh7XG4gICAgY2xpcElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBwb3N0SWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlY3JldG86IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpXG4gIH0pLFxuICBjbGlwUHVibGlzaDogSm9pLm9iamVjdCgpLmtleXMoe1xuICAgIHVybDogSm9pLnN0cmluZygpLnJlZ2V4KC9eW2Etei1dKyQvKS5yZXF1aXJlZCgpLFxuICAgIHNlY3JldG86IEpvaS5zdHJpbmcoKVxuICB9KSxcbiAgYWdyZWdhclBvc3Q6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICB1cmw6IEpvaS5zdHJpbmcoKS5yZWdleCgvXlthLXotXSskLykucmVxdWlyZWQoKSxcbiAgICBsaW5rOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBycnNzOiBKb2kuc3RyaW5nKCkudmFsaWQoWydmYWNlYm9vaycsICdpbnN0YWdyYW0nLCAndHdpdHRlcicsICd5b3V0dWJlJ10pLnJlcXVpcmVkKCksXG4gICAgc2VjcmV0bzogSm9pLnN0cmluZygpXG4gIH0pLFxuICB0aXR1bG86IEpvaS5zdHJpbmcoKVxufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gIGNyZWFyQ2xpcCAodGl0dWxvKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IHRpdHVsbyxcbiAgICAgIHNjaGVtYTogdmFsaWRhY2lvbmVzLnRpdHVsbyxcbiAgICAgIGRlYnVnOiB7XG4gICAgICAgIGRvbmRlOiAnbWV0aG9kIGNyZWFyQ2xpcCdcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgaWYgKGNsaXBzLmZpbmQoe1xuICAgICAgdGl0dWxvXG4gICAgfSwge1xuICAgICAgbGltaXQ6IDFcbiAgICB9KS5jb3VudCgpKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMCwgJ3RpdHVsbyByZXBldGlkbycpXG4gICAgfVxuICAgIGNvbnN0IHVybCA9IHRpdHVsb0FVcmwodGl0dWxvKVxuICAgIGlmIChjbGlwcy5maW5kKHtcbiAgICAgIHVybFxuICAgIH0sIHtcbiAgICAgIGxpbWl0OiAxXG4gICAgfSkuY291bnQoKSkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsICd1cmwgcmVwZXRpZGEnKVxuICAgIH1cblxuICAgIGNvbnN0IHNlY3JldG8gPSBSYW5kb20uc2VjcmV0KClcbiAgICBjb25zdCBzZWd1cmlkYWQgPSBSYW5kb20uc2VjcmV0KClcbiAgICBjb25zdCBjbGlwSWQgPSBjbGlwcy5pbnNlcnQoe1xuICAgICAgY3JlYWNpb246IG5ldyBEYXRlKCksXG4gICAgICB0aXR1bG8sXG4gICAgICB1cmwsXG4gICAgICBzZWNyZXRvLFxuICAgICAgc2VndXJpZGFkXG4gICAgfSlcblxuICAgIHJldHVybiB7XG4gICAgICBjbGlwSWQsXG4gICAgICBzZWNyZXRvLFxuICAgICAgc2VndXJpZGFkXG4gICAgfVxuICB9LFxuICBhZ3JlZ2FyUG9zdCAob3BjaW9uZXMpIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogb3BjaW9uZXMsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5hZ3JlZ2FyUG9zdCxcbiAgICAgIGRlYnVnOiB7XG4gICAgICAgIGRvbmRlOiAnbWV0aG9kIGFncmVnYXJQb3N0J1xuICAgICAgfVxuICAgIH0pXG4gICAgY29uc3QgY2xpcCA9IGNsaXBzLmZpbmRPbmUoe1xuICAgICAgdXJsOiBvcGNpb25lcy51cmwsXG4gICAgICBzZWNyZXRvOiBvcGNpb25lcy5zZWNyZXRvIHx8IHtcbiAgICAgICAgJGV4aXN0czogMVxuICAgICAgfVxuICAgIH0pIHx8IHNhbGlyKDQwNCwgJ0NsaXAgbm8gZW5jb250cmFkbycsIHtcbiAgICAgIGRvbmRlOiAnbWV0aG9kIGFncmVnYXJQb3N0J1xuICAgIH0pXG5cbiAgICBpZiAocG9zdHMuZmluZE9uZSh7XG4gICAgICBjbGlwSWQ6IGNsaXAuX2lkLFxuICAgICAgbGluazogb3BjaW9uZXMubGlua1xuICAgIH0pKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgcG9zdHMuaW5zZXJ0KHtcbiAgICAgIGNsaXBJZDogY2xpcC5faWQsXG4gICAgICBycnNzOiBvcGNpb25lcy5ycnNzLFxuICAgICAgbGluazogb3BjaW9uZXMubGluayxcbiAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKSxcbiAgICAgIHN0YXR1czogb3BjaW9uZXMuc2VjcmV0byA/ICdWSVNJQkxFJyA6ICdQRU5ESUVOVEUnXG4gICAgfSlcbiAgICBpZiAob3BjaW9uZXMuc2VjcmV0bykge1xuICAgICAgY2xpcHMudXBkYXRlKHtcbiAgICAgICAgX2lkOiBjbGlwLl9pZFxuICAgICAgfSwge1xuICAgICAgICAkaW5jOiB7XG4gICAgICAgICAgcG9zdHM6IDFcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gIH0sXG4gIHRlc3RUaXR1bG8gKHRpdHVsbykge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiB0aXR1bG8sXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy50aXR1bG8sXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCB0ZXN0VGl0dWxvJ1xuICAgICAgfVxuICAgIH0pXG4gICAgLy8gaWYgKGNsaXBzLmZpbmQoe1xuICAgIC8vICAgdGl0dWxvXG4gICAgLy8gfSwge1xuICAgIC8vICAgbGltaXQ6IDFcbiAgICAvLyB9KS5jb3VudCgpKSB7XG4gICAgLy8gICBjb25zb2xlLmxvZygndGl0dWxvIHJlcGV0aWRvJylcbiAgICAvLyAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCAndGl0dWxvIHJlcGV0aWRvJylcbiAgICAvLyB9XG4gICAgY29uc3QgdXJsID0gdGl0dWxvQVVybCh0aXR1bG8pXG4gICAgaWYgKGNsaXBzLmZpbmQoe1xuICAgICAgdXJsXG4gICAgfSwge1xuICAgICAgbGltaXQ6IDFcbiAgICB9KS5jb3VudCgpKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMCwgJ3VybCByZXBldGlkYScpXG4gICAgfVxuICB9LFxuICBlc3RhYmxlY2VyU3RhdHVzIChvcGNpb25lcykge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiBvcGNpb25lcyxcbiAgICAgIHNjaGVtYTogdmFsaWRhY2lvbmVzLmVzdGFibGVjZXJTdGF0dXMsXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgICAgfVxuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkLFxuICAgICAgc2VjcmV0bzogb3BjaW9uZXMuc2VjcmV0b1xuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDAxLCAnTm8gdGllbmVzIHBlcm1pc28gcGFyYSBhZG1pbmlzdHJhciBlbCBjbGlwJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICB9KVxuXG4gICAgcG9zdHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLnBvc3RJZCxcbiAgICAgIGNsaXBJZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdQb3N0IG5vIGVuY29udHJhZG8nKVxuXG4gICAgcG9zdHMudXBkYXRlKG9wY2lvbmVzLnBvc3RJZCwge1xuICAgICAgJHNldDoge1xuICAgICAgICBzdGF0dXM6IG9wY2lvbmVzLnN0YXR1c1xuICAgICAgfVxuICAgIH0pXG4gIH0sXG4gIGVsaW1pbmFyUG9zdCAob3BjaW9uZXMpIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogb3BjaW9uZXMsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5lbGltaW5hclBvc3QsXG4gICAgICBkZWJ1Zzoge1xuICAgICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgICAgfVxuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkLFxuICAgICAgc2VjcmV0bzogb3BjaW9uZXMuc2VjcmV0b1xuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDAxLCAnTm8gdGllbmVzIHBlcm1pc28gcGFyYSBhZG1pbmlzdHJhciBlbCBjbGlwJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICB9KVxuXG4gICAgcG9zdHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLnBvc3RJZCxcbiAgICAgIGNsaXBJZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdQb3N0IG5vIGVuY29udHJhZG8nKVxuXG4gICAgcG9zdHMucmVtb3ZlKG9wY2lvbmVzLnBvc3RJZClcbiAgfSxcbiAgcmV2b2NhciAob3BjaW9uZXMpIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogb3BjaW9uZXMsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5yZXZvY2FyLFxuICAgICAgZGVidWc6IHtcbiAgICAgICAgZG9uZGU6ICdtZXRob2QgcmV2b2NhcidcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgY2xpcHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZFxuICAgIH0pLmNvdW50KCkgfHwgc2FsaXIoNDA0LCAnQ2xpcCBubyBlbmNvbnRyYWRvJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgcmV2b2NhcidcbiAgICB9KVxuXG4gICAgY2xpcHMuZmluZCh7XG4gICAgICBfaWQ6IG9wY2lvbmVzLmNsaXBJZCxcbiAgICAgIHNlZ3VyaWRhZDogb3BjaW9uZXMuc2VndXJpZGFkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDAsICdObyB0aWVuZXMgcGVybWlzbyBwYXJhIHJldm9jYXIgbGxhdmVzJywge1xuICAgICAgZG9uZGU6ICdtZXRob2QgcmV2b2NhcidcbiAgICB9KVxuXG4gICAgY29uc3QgbGxhdmUgPSBSYW5kb20uc2VjcmV0KClcblxuICAgIGNsaXBzLnVwZGF0ZShvcGNpb25lcy5jbGlwSWQsIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgW29wY2lvbmVzLmxsYXZlXTogbGxhdmVcbiAgICAgIH1cbiAgICB9KVxuICAgIHJldHVybiBsbGF2ZVxuICB9XG59KVxuXG5NZXRlb3IucHVibGlzaCgnY2xpcCcsIGZ1bmN0aW9uIChvcGNpb25lcykge1xuICBzYWxpclZhbGlkYWNpb24oe1xuICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgIHNjaGVtYTogdmFsaWRhY2lvbmVzLmNsaXBQdWJsaXNoLFxuICAgIGRlYnVnOiB7XG4gICAgICBkb25kZTogJ3B1Ymxpc2ggY2xpcCdcbiAgICB9XG4gIH0pXG4gIGNvbnN0IGNsaXAgPSBjbGlwcy5maW5kT25lKHtcbiAgICB1cmw6IG9wY2lvbmVzLnVybFxuICB9KSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgZG9uZGU6ICdtZXRob2QgYWdyZWdhclBvc3QnXG4gIH0pXG5cbiAgb3BjaW9uZXMuc2VjcmV0byAmJiBjbGlwLnNlY3JldG8gIT09IG9wY2lvbmVzLnNlY3JldG8gJiYgc2FsaXIoNDAxLCAnTm8gdGllbmVzIHBlcm1pc28nLCB7XG4gICAgZG9uZGU6ICdtZXRob2QgYWdyZWdhclBvc3QnXG4gIH0pXG5cbiAgY29uc3QgcG9zdHNRdWVyeSA9IHtcbiAgICBjbGlwSWQ6IGNsaXAuX2lkXG4gIH1cblxuICBpZiAoIW9wY2lvbmVzLnNlY3JldG8pIHtcbiAgICBwb3N0c1F1ZXJ5LnN0YXR1cyA9ICdWSVNJQkxFJ1xuICB9XG5cbiAgcmV0dXJuIFtcbiAgICBjbGlwcy5maW5kKGNsaXAuX2lkLCB7XG4gICAgICBmaWVsZHM6IHtcbiAgICAgICAgc2VndXJpZGFkOiAwLFxuICAgICAgICBzZWNyZXRvOiAwXG4gICAgICB9XG4gICAgfSksXG4gICAgcG9zdHMuZmluZChwb3N0c1F1ZXJ5KVxuICBdXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCBKb2kgZnJvbSAnam9pJ1xuXG5leHBvcnQgY29uc3Qgc2FsaXIgPSBmdW5jdGlvbiBzYWxpciAoY29kaWdvLCBtZW5zYWplLCBkZWJ1Zykge1xuICBpZiAoZGVidWcpIHtcbiAgICBjb25zb2xlLmxvZyhjb2RpZ28sIG1lbnNhamUpXG4gICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoZGVidWcsIG51bGwsIDIpKVxuICB9XG4gIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoY29kaWdvLCBtZW5zYWplKVxufVxuXG5leHBvcnQgY29uc3Qgc2FsaXJWYWxpZGFjaW9uID0gZnVuY3Rpb24gKG9wY2lvbmVzKSB7XG4gIGNvbnN0IHZhbGlkYWNpb24gPSBKb2kudmFsaWRhdGUob3BjaW9uZXMuZGF0YSwgb3BjaW9uZXMuc2NoZW1hKVxuICBpZiAoIXZhbGlkYWNpb24uZXJyb3IpIHtcbiAgICByZXR1cm5cbiAgfVxuICBvcGNpb25lcyA9IE9iamVjdC5hc3NpZ24oe1xuICAgIGNvZGlnbzogNDAwLFxuICAgIG1lbnNhamU6IHZhbGlkYWNpb24uZXJyb3IuZGV0YWlsc1swXS5tZXNzYWdlXG4gIH0sIG9wY2lvbmVzKVxuICBpZiAob3BjaW9uZXMuZGVidWcpIHtcbiAgICBvcGNpb25lcy5kZWJ1Zy5kZXRhaWxzID0gdmFsaWRhY2lvbi5lcnJvci5kZXRhaWxzXG4gICAgb3BjaW9uZXMuZGVidWcuX29iamVjdCA9IHZhbGlkYWNpb24uZXJyb3IuX29iamVjdFxuICB9XG4gIHNhbGlyKG9wY2lvbmVzLmNvZGlnbywgb3BjaW9uZXMubWVuc2FqZSwgb3BjaW9uZXMuZGVidWcpXG59XG4iLCJpbXBvcnQgY2hlZXJpbyBmcm9tICdjaGVlcmlvJ1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJ1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IGNsaXBzLCBwb3N0cyB9IGZyb20gJy9jb21tb24vYmFzZURlRGF0b3MnXG5pbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCdcblxuY29uc3QgcnJzcyA9IHtcbiAgaW5zdGFncmFtOiB7XG4gICAgb2J0ZW5lckFwb3lvcyAodXJsKSB7XG4gICAgICBjb25zdCBodG1sID0gSFRUUC5nZXQodXJsKVxuICAgICAgY29uc3QgJCA9IGNoZWVyaW8ubG9hZChodG1sLmNvbnRlbnQpXG4gICAgICByZXR1cm4gSlNPTi5wYXJzZSgkKCdzY3JpcHRbdHlwZT1cImFwcGxpY2F0aW9uL2xkK2pzb25cIl0nKS5odG1sKCkpLmludGVyYWN0aW9uU3RhdGlzdGljLnVzZXJJbnRlcmFjdGlvbkNvdW50XG4gICAgfVxuICB9LFxuICB5b3V0dWJlOiB7XG4gICAgcmVnZXg6IC8oXnw9fFxcLykoWzAtOUEtWmEtel8tXXsxMX0pKFxcL3wmfCR8XFw/fCMpLyxcbiAgICBvYnRlbmVyQXBveW9zICh1cmwpIHtcbiAgICAgIGNvbnN0IHlvdXR1YmUgPSB1cmwubWF0Y2gocnJzcy55b3V0dWJlLnJlZ2V4KVxuICAgICAgaWYgKCF5b3V0dWJlKSB7XG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UoSFRUUC5nZXQoYGh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL3lvdXR1YmUvdjMvdmlkZW9zP2lkPSR7eW91dHViZVsyXX0ma2V5PSR7TWV0ZW9yLnNldHRpbmdzLnByaXZhdGUueW91dHViZUFQSX0mcGFydD1zdGF0aXN0aWNzYCkuY29udGVudCkuaXRlbXNbMF0uc3RhdGlzdGljc1xuXG4gICAgICByZXR1cm4gZGF0YS5saWtlQ291bnQgLSBkYXRhLmRpc2xpa2VDb3VudFxuICAgIH1cbiAgfSxcbiAgdHdpdHRlcjoge1xuICAgIG9idGVuZXJBcG95b3MgKHVybCkge1xuICAgICAgY29uc3QgaHRtbCA9IEhUVFAuZ2V0KHVybClcbiAgICAgIGNvbnN0ICQgPSBjaGVlcmlvLmxvYWQoaHRtbC5jb250ZW50KVxuICAgICAgdmFyIHN0YXRzID0gJCgndWwuc3RhdHMnKVxuICAgICAgY29uc3QgcmV0d2VldGVkID0gKHN0YXRzLmZpbmQoJy5yZXF1ZXN0LXJldHdlZXRlZC1wb3B1cCcpLmRhdGEoKSB8fCB7IHR3ZWV0U3RhdENvdW50OiAwIH0pLnR3ZWV0U3RhdENvdW50ICogMVxuICAgICAgY29uc3QgZmF2b3JpdGVkID0gKHN0YXRzLmZpbmQoJy5yZXF1ZXN0LWZhdm9yaXRlZC1wb3B1cCcpLmRhdGEoKSB8fCB7IHR3ZWV0U3RhdENvdW50OiAwIH0pLnR3ZWV0U3RhdENvdW50ICogMVxuICAgICAgcmV0dXJuIHJldHdlZXRlZCArIGZhdm9yaXRlZFxuICAgIH1cbiAgfSxcbiAgZmFjZWJvb2s6IHtcbiAgICBvYnRlbmVyQXBveW9zICh1cmwpIHtcbiAgICAgIHJldHVybiAwXG4gICAgfVxuICB9XG59XG5cbmNvbnN0IG9idGVuZXJBcG95b3MgPSBmdW5jdGlvbiBvYnRlbmVyQXBveW9zIChwb3N0KSB7XG4gIHJldHVybiAocnJzc1twb3N0LnJyc3NdLm9idGVuZXJBcG95b3MocG9zdC5saW5rKSB8fCAwKSAqIDFcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBhY3R1YWxpemFyQXBveW9zIChjbGlwSWQsIGZvcnphcikge1xuICAgIGlmICghZm9yemFyICYmIGNsaXBzLmZpbmRPbmUoe1xuICAgICAgX2lkOiBjbGlwSWQsXG4gICAgICBhY3R1YWxpemFjaW9uOiB7XG4gICAgICAgICRndDogbW9tZW50KCkuc3VidHJhY3QoMSwgJ2hvdXInKS50b0RhdGUoKVxuICAgICAgfVxuICAgIH0pKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgdmFyIGFwb3lvcyA9IDBcbiAgICBwb3N0cy5maW5kKHtcbiAgICAgIGNsaXBJZCxcbiAgICAgIHN0YXR1czogJ1ZJU0lCTEUnXG4gICAgfSkuZm9yRWFjaChwb3N0ID0+IHtcbiAgICAgIGNvbnN0IG1pc0Fwb3lvcyA9IG9idGVuZXJBcG95b3MocG9zdClcbiAgICAgIHBvc3RzLnVwZGF0ZSh7XG4gICAgICAgIF9pZDogcG9zdC5faWRcbiAgICAgIH0sIHtcbiAgICAgICAgJHNldDoge1xuICAgICAgICAgIGFwb3lvczogbWlzQXBveW9zXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICBhcG95b3MgKz0gbWlzQXBveW9zXG4gICAgfSlcbiAgICBjbGlwcy51cGRhdGUoe1xuICAgICAgX2lkOiBjbGlwSWRcbiAgICB9LCB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIGFwb3lvcyxcbiAgICAgICAgYWN0dWFsaXphY2lvbjogbmV3IERhdGUoKVxuICAgICAgfVxuICAgIH0pXG4gIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgY2xpcHMsIHBvc3RzIH0gZnJvbSAnL2NvbW1vbi9iYXNlRGVEYXRvcydcblxuTWV0ZW9yLnB1Ymxpc2goJ3JhbmtpbmcnLCBmdW5jdGlvbiAocGFnaW5hID0gMCkge1xuICByZXR1cm4gY2xpcHMuZmluZCh7XG4gICAgcG9zdHM6IHtcbiAgICAgICRndDogMFxuICAgIH1cbiAgfSwge1xuICAgIHNvcnQ6IHtcbiAgICAgIGFwb3lvczogLTFcbiAgICB9LFxuICAgIHNraXA6IDEwICogcGFnaW5hLFxuICAgIGxpbWl0OiAxMFxuICB9KVxufSlcblxuTWV0ZW9yLnB1Ymxpc2goJ3ByaW1lclBvc3QnLCBmdW5jdGlvbiAoY2xpcElkKSB7XG4gIHJldHVybiBwb3N0cy5maW5kKHtcbiAgICBjbGlwSWQsXG4gICAgc3RhdHVzOiAnVklTSUJMRSdcbiAgfSwge1xuICAgIHNvcnQ6IHtcbiAgICAgIHRpbWVzdGFtcDogLTFcbiAgICB9LFxuICAgIGxpbWl0OiAxXG4gIH0pXG59KVxuIl19
