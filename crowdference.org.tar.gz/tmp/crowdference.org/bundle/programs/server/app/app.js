var require = meteorInstall({"common":{"baseDeDatos.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/baseDeDatos.js                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  clips: () => clips,
  posts: () => posts,
  links: () => links,
  localLinks: () => localLinks,
  favoritos: () => favoritos
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
const clips = new Mongo.Collection('clips');
const posts = new Mongo.Collection('posts');
const links = new Mongo.Collection('links');
var localLinks;
var favoritos;

if (Meteor.isClient) {
  module.runSetters(favoritos = new Mongo.Collection(null));
  /* eslint-disable-next-line */

  new PersistentMinimongo2(favoritos, 'favoritos');
  module.runSetters(localLinks = new Mongo.Collection(null));
  /* eslint-disable-next-line */

  new PersistentMinimongo2(localLinks, 'localLinks');
}

if (Meteor.isDevelopment) {
  global.favoritos = favoritos;
  global.clips = clips;
  global.posts = posts;
  global.links = links;
  global.localLinks = localLinks;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"traducciones.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/traducciones.js                                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  traducciones: () => traducciones,
  idiomas: () => idiomas
});
const traducciones = {
  "Aceptar": {
    "en": "Accept",
    "es": "Aceptar"
  },
  "Agrega enlaces al clip.": {
    "en": "Add links to clip.",
    "es": "Agrega enlaces al clip."
  },
  "Agregar": {
    "en": "Add",
    "es": "Agregar"
  },
  "Agregar enlace": {
    "en": "Add link",
    "es": "Agregar enlace"
  },
  "Aprobar": {
    "en": "Approve",
    "es": "Aprobar"
  },
  "Atrás": {
    "en": "Back",
    "es": "Atrás"
  },
  "Buscar clip": {
    "en": "Search clip",
    "es": "Buscar clip"
  },
  "Busqueda:": {
    "en": "Search",
    "es": "Busqueda:"
  },
  "Cancelar": {
    "en": "Cancel",
    "es": "Cancelar"
  },
  "Clip vacío": {
    "en": "Empty clip",
    "es": "Clip vacío"
  },
  "Compartir": {
    "en": "Share",
    "es": "Compartir"
  },
  "Con esta llave se puede administrar el clip": {
    "en": "This key allows to admin the clip",
    "es": "Con esta llave se puede administrar el clip"
  },
  "Con esta llave se pueden revocar las llaves de administración y seguridad.": {
    "en": "This key allows to revoke the keys",
    "es": "Con esta llave se pueden revocar las llaves de administración y seguridad."
  },
  "Crear": {
    "en": "Create",
    "es": "Crear"
  },
  "Crear clip": {
    "en": "Create clip",
    "es": "Crear clip"
  },
  "Eliminar": {
    "en": "Remove",
    "es": "Eliminar"
  },
  "Escribe un título para el clip": {
    "en": "Enter a title for the clip",
    "es": "Escribe un título para el clip"
  },
  "Favoritos": {
    "en": "Favorites",
    "es": "Favoritos"
  },
  "Hecho": {
    "en": "Done",
    "es": "Hecho"
  },
  "Idioma": {
    "en": "Language",
    "es": "Idioma"
  },
  "Llave de administración": {
    "en": "Admin key",
    "es": "Llave de administración"
  },
  "Llave de seguridad": {
    "en": "Safe key",
    "es": "Llave de seguridad"
  },
  "Llaves": {
    "en": "Keys",
    "es": "Llaves"
  },
  "Los enlaces se ordenan por su prioridad, de mayor a menor, y por la fecha en la que han sido agregados.": {
    "en": "The links are ordered by their priority and then by the addition date",
    "es": "Los enlaces se ordenan por su prioridad, de mayor a menor, y por la fecha en la que han sido agregados."
  },
  "Mostrar": {
    "en": "Show",
    "es": "Mostrar"
  },
  "Ocultar": {
    "en": "Hide",
    "es": "Ocultar"
  },
  "Olvidar": {
    "en": "Forget",
    "es": "Olvidar"
  },
  "organiza las": {
    "en": "organize the",
    "es": "organiza las"
  },
  "Prioridad": {
    "en": "Priority",
    "es": "Prioridad"
  },
  "Ranking": {
    "en": "Ranking",
    "es": "Ranking"
  },
  "Rechazar": {
    "en": "Refuse",
    "es": "Rechazar"
  },
  "Recordar": {
    "en": "Remember",
    "es": "Recordar"
  },
  "Siguiente": {
    "en": "Next",
    "es": "Siguiente"
  },
  "Tienes que indicar un título para poder continuar": {
    "en": "You need to add a title to continue",
    "es": "Tienes que indicar un título para poder continuar"
  },
  "Titulo": {
    "en": "Title",
    "es": "Titulo"
  },
  "Una vez creado el clip, no se podrá modificar su título ni su url.": {
    "en": "After created, the title cannot be altered",
    "es": "Una vez creado el clip, no se podrá modificar su título ni su url."
  },
  "Ver clip": {
    "en": "View clip",
    "es": "Ver clip"
  },
  "Ya hay un clip con esa url": {
    "en": "A clip exists with this url",
    "es": "Ya hay un clip con esa url"
  },
  "Ya hay un clip con ese título": {
    "en": "A clip exists with this title",
    "es": "Ya hay un clip con ese título"
  },
  "redes": {
    "en": "networks",
    "es": "redes"
  }
};
const idiomas = {
  "en": 1,
  "es": 1
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"varios.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/varios.js                                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  tituloAUrl: () => tituloAUrl
});
const diacriticas = {
  á: 'a',
  é: 'e',
  í: 'i',
  ó: 'o',
  ú: 'u',
  ñ: 'n',
  ç: 'c'
};

const tituloAUrl = function tituloAUrl(titulo) {
  return (titulo || '').toLowerCase().replace(/[ ]/g, '-').replace(/[áéíúóüñ]/g, function (letra) {
    return diacriticas[letra];
  }).replace(/[^a-z0-9 _.-]/g, '');
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"clip.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/clip.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 1);
let clips;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  }

}, 2);
let salirValidacion, salir;
module.link("/server/comun", {
  salirValidacion(v) {
    salirValidacion = v;
  },

  salir(v) {
    salir = v;
  }

}, 3);
let tituloAUrl;
module.link("/common/varios", {
  tituloAUrl(v) {
    tituloAUrl = v;
  }

}, 4);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 5);
const validaciones = {
  revocar: Joi.object().keys({
    clipId: Joi.string().required(),
    seguridad: Joi.string().required(),
    llave: Joi.string().valid(['seguridad', 'secreto']).required()
  }),
  obtenerSecreto: Joi.object().keys({
    clipId: Joi.string().required(),
    seguridad: Joi.string().required()
  }),
  url: Joi.string().regex(/^[a-z-]+$/).required(),
  clipIdPublish: Joi.object().keys({
    clipId: Joi.string().required(),
    secreto: Joi.string().required()
  }),
  titulo: Joi.string(),
  _id: Joi.string()
};
Meteor.methods({
  clipIdToUrl(_id) {
    salirValidacion({
      data: _id,
      schema: validaciones._id
    });
    const clip = clips.findOne(_id, {
      fields: {
        url: 1
      }
    }) || salir(404, 'Clip no encontrado');
    return clip.url;
  },

  crearClip(titulo) {
    salirValidacion({
      data: titulo,
      schema: validaciones.titulo
    });
    const url = tituloAUrl(titulo);
    clips.find({
      url
    }, {
      limit: 1
    }).count() && salir(400, 'url repetida');
    const secreto = Random.secret();
    const seguridad = Random.secret();
    const clipId = clips.insert({
      actualizacion: new Date(),
      titulo,
      url,
      secreto,
      seguridad,
      posts: 0
    });
    return {
      clipId,
      secreto,
      seguridad
    };
  },

  testTitulo(titulo) {
    salirValidacion({
      data: titulo,
      schema: validaciones.titulo
    });

    if (clips.find({
      titulo
    }, {
      limit: 1
    }).count()) {
      console.log('titulo repetido');
      throw new Meteor.Error(400, 'titulo repetido');
    }

    const url = tituloAUrl(titulo);

    if (clips.find({
      url
    }, {
      limit: 1
    }).count()) {
      throw new Meteor.Error(400, 'url repetida');
    }
  },

  revocar(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.revocar,
      debug: {
        donde: 'method revocar'
      }
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado');
    clips.find({
      _id: opciones.clipId,
      seguridad: opciones.seguridad
    }).count() || salir(400, 'No tienes permiso para revocar llaves');
    const llave = Random.secret();
    clips.update(opciones.clipId, {
      $set: {
        [opciones.llave]: llave
      }
    });
    return llave;
  },

  obtenerSecreto(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.obtenerSecreto
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado');
    const clip = clips.findOne({
      _id: opciones.clipId,
      seguridad: opciones.seguridad
    }) || salir(401, 'No tienes permiso para obtener la llave de administración');
    return clip.secreto;
  }

});
Meteor.publish('clipUrl', function (url) {
  salirValidacion({
    data: url,
    schema: validaciones.url
  });
  return clips.find({
    url
  }, {
    fields: {
      seguridad: 0,
      secreto: 0
    }
  });
});
Meteor.publish('clipId', function (_id) {
  salirValidacion({
    data: _id,
    schema: validaciones._id
  });
  return clips.find({
    _id
  }, {
    fields: {
      seguridad: 0,
      secreto: 0
    }
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comun.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/comun.js                                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  salir: () => salir,
  salirValidacion: () => salirValidacion
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 1);

const salir = function salir(codigo, mensaje, debug) {
  if (Meteor.isDevelopment) {
    console.log(codigo, mensaje);
    const err = new Error();
    console.log(err.stack);
    console.log(JSON.stringify(debug, null, 2));
  }

  throw new Meteor.Error(codigo, mensaje);
};

const salirValidacion = function (opciones) {
  const validacion = Joi.validate(opciones.data, opciones.schema);

  if (!validacion.error) {
    return;
  }

  opciones = Object.assign({
    codigo: 400,
    mensaje: validacion.error.details[0].message
  }, opciones);

  if (opciones.debug) {
    opciones.debug.details = validacion.error.details;
    opciones.debug._object = validacion.error._object;
  }

  salir(opciones.codigo, opciones.mensaje, opciones.debug);
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"link.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/link.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let links;
module.link("/common/baseDeDatos", {
  links(v) {
    links = v;
  }

}, 2);
let salirValidacion;
module.link("/server/comun", {
  salirValidacion(v) {
    salirValidacion = v;
  }

}, 3);
let ogs;
module.link("open-graph-scraper", {
  default(v) {
    ogs = v;
  }

}, 4);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 5);
const validaciones = {
  string: Joi.string()
};
const meteorOGS = Meteor.wrapAsync(function (opciones, callback) {
  ogs(opciones, function (e, r) {
    if (e) {
      return callback(null, []);
    }

    callback(null, r);
  });
});
const rrss = {
  Instagram(response) {
    response.description = response.title.replace(/^.*?on Instagram: /, '');
    response.title = response.title.replace(/on Instagram:.*$/, '');
    return response;
  },

  Twitter(response) {
    response.title = response.title.replace(/on Twitter$/, '');
    return response;
  },

  reddit(response) {
    response.description = response.title.replace(/^.*?- /, '');
    response.title = response.title.replace(/ - .*$/, '');
    return response;
  }

};

const siteNameFromUrl = function siteNameFromUrl(url) {
  url = url.match(siteNameFromUrl.regex);
  return url[2];
};

siteNameFromUrl.regex = /^http(?:s?):\/\/([0-9a-z-]*\.)?([0-9a-z-]+\.[0-9a-z-]+)(?:\/|$)/;

const actualizar = function actualizar(url) {
  var response;
  var opciones;

  if (url.match(/https:\/\/www.facebook/)) {
    opciones = {
      html: HTTP.get(url, {
        headers: {
          'User-Agent': 'FeedFetcher-Google; (+http://www.google.com/feedfetcher.html)'
        }
      }).content
    };
  } else {
    opciones = {
      url
    };
  }

  response = meteorOGS(opciones);

  if (!response) {
    return;
  }

  if (url.match(/https:\/\/www.facebook/)) {
    response.data.ogSiteName = 'Facebook';
  }

  if (response.data.ogUrl) {
    url = Array.from(new Set([response.data.ogUrl, url]));
  } else {
    url = [url];
  }

  response = {
    description: response.data.ogDescription,
    title: response.data.ogTitle,
    image: (response.data.ogImage || {}).url,
    type: response.data.ogType,
    url: url,
    siteName: response.data.ogSiteName || response.data.twitterSite || siteNameFromUrl(url[0])
  };

  if (rrss[response.siteName]) {
    return rrss[response.siteName](response);
  }

  return response;
};

const insertar = function insertar(link) {
  console.log('insertar');
  const l = links.findOne({
    url: {
      $in: link.url
    }
  });

  if (l) {
    links.update(l._id, {
      $addToSet: {
        url: {
          $each: link.url
        }
      }
    });
    return l;
  }

  link.actualizado = new Date();
  link._id = links.insert(link);
  return link;
};

Meteor.methods({
  link(url) {
    salirValidacion({
      data: url,
      schema: validaciones.string
    });
    return links.findOne({
      url
    }) || insertar(actualizar(url));
  },

  linkId(_id) {
    salirValidacion({
      data: _id,
      schema: validaciones.string
    });
    return links.findOne(_id);
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"listas.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/listas.js                                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 1);
let salirValidacion;
module.link("/server/comun", {
  salirValidacion(v) {
    salirValidacion = v;
  }

}, 2);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 3);
const validaciones = {
  primerPost: Joi.string(),
  link: Joi.string()
};
Meteor.publish('ranking', function () {
  return clips.find({
    posts: {
      $gt: 0
    }
  }, {
    fields: {
      secreto: 0,
      seguridad: 0
    },
    sort: {
      actualizacion: -1
    },
    limit: 100
  });
});
Meteor.publish('busqueda', function (busqueda) {
  var regex = /(?:)/;

  try {
    regex = new RegExp(busqueda);
  } catch (e) {
    regex = /$^/;
  }

  return clips.find({
    titulo: regex,
    posts: {
      $gt: 0
    }
  }, {
    fields: {
      secreto: 0,
      seguridad: 0
    },
    sort: {
      actualizacion: -1
    },
    limit: 100
  });
});
Meteor.publish('primerPost', function (clipId) {
  salirValidacion({
    data: clipId,
    schema: validaciones.primerPost,
    debug: {
      donde: 'publish clip'
    }
  });
  return posts.find({
    clipId,
    status: 'VISIBLE'
  }, {
    sort: {
      prioridad: -1,
      timestamp: -1
    },
    limit: 1
  });
});
Meteor.publish('link', function (link) {
  return posts.findOne({
    link
  }, {
    fields: {
      clipId: 1
    }
  });
});
Meteor.publish('linkPost', function (link) {
  return posts.find({
    link
  }, {
    limit: 1
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"post.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/post.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let clips, posts;
module.link("/common/baseDeDatos", {
  clips(v) {
    clips = v;
  },

  posts(v) {
    posts = v;
  }

}, 1);
let salirValidacion, salir;
module.link("/server/comun", {
  salirValidacion(v) {
    salirValidacion = v;
  },

  salir(v) {
    salir = v;
  }

}, 2);
let Joi;
module.link("joi", {
  default(v) {
    Joi = v;
  }

}, 3);
const validaciones = {
  agregarPost: Joi.object().keys({
    clipId: Joi.string().required(),
    linkId: Joi.string().required()
  }),
  cambiarPrioridad: Joi.object().keys({
    postId: Joi.string().required(),
    secreto: Joi.string().required(),
    prioridad: Joi.number().required()
  }),
  establecerStatus: Joi.object().keys({
    postId: Joi.string().required(),
    secreto: Joi.string().required(),
    status: Joi.string().valid(['RECHAZADO', 'OCULTO', 'VISIBLE']).required()
  }),
  eliminarPost: Joi.object().keys({
    postId: Joi.string().required(),
    secreto: Joi.string().required()
  }),
  postsVisibles: Joi.string(),
  postsNoVisibles: Joi.object().keys({
    clipId: Joi.string().required(),
    secreto: Joi.string().required()
  })
};

const testSecretoClip = function (opciones) {
  const post = posts.findOne({
    _id: opciones.postId
  }, {
    fields: {
      clipId: 1
    }
  }) || salir(404, 'Post no encontrado');
  const clip = clips.findOne({
    _id: post.clipId
  }, {
    fields: {
      secreto: 1,
      status: 1
    }
  }) || salir(404, 'Clip no encontrado', {
    donde: 'method establecerStatus'
  });
  clip.seguridad === opciones.seguridad || salir(401, 'No tienes permiso para administrar el clip', {
    donde: 'method establecerStatus'
  });
  return clip;
};

Meteor.methods({
  agregarPost(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.agregarPost
    });
    clips.find({
      _id: opciones.clipId
    }).count() || salir(404, 'Clip no encontrado');

    if (posts.findOne(opciones)) {
      return;
    }

    posts.insert({
      clipId: opciones.clipId,
      linkId: opciones.linkId,
      timestamp: new Date(),
      status: 'PENDIENTE',
      prioridad: 0
    });
  },

  cambiarPrioridad(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.cambiarPrioridad
    });
    testSecretoClip(opciones);
    posts.update(opciones.postId, {
      $set: {
        prioridad: opciones.prioridad
      }
    });
  },

  establecerStatus(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.establecerStatus
    });
    const clip = testSecretoClip(opciones);
    posts.update(opciones.postId, {
      $set: {
        status: opciones.status
      }
    });
    console.log(clip);

    if (clip.status !== 'VISIBLE' && opciones.status === 'VISIBLE') {
      console.log(+1);
      return clips.update(clip._id, {
        $inc: {
          posts: 1
        }
      });
    }

    if (clip.status === 'VISIBLE' && opciones.status !== 'VISIBLE') {
      console.log(-1);
      return clips.update(clip._id, {
        $inc: {
          posts: -1
        }
      });
    }
  },

  eliminarPost(opciones) {
    salirValidacion({
      data: opciones,
      schema: validaciones.eliminarPost,
      debug: {
        donde: 'method establecerStatus'
      }
    });
    testSecretoClip(opciones);
    posts.remove(opciones.postId);
  }

});
Meteor.publish('postsVisibles', function (clipId) {
  salirValidacion({
    data: clipId,
    schema: validaciones.postsVisibles
  });
  return posts.find({
    clipId,
    status: 'VISIBLE'
  });
});
Meteor.publish('postsNoVisibles', function (opciones) {
  salirValidacion({
    data: opciones,
    schema: validaciones.postsNoVisibles
  });
  const clip = clips.findOne({
    url: opciones.url
  }) || salir(404, 'Clip no encontrado');
  clip.secreto === opciones.secreto || salir(401, 'Clave de administración no válida');
  return posts.find({
    clipId: opciones.clipId,
    status: {
      $ne: 'VISIBLE'
    }
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/common/baseDeDatos.js");
require("/common/traducciones.js");
require("/common/varios.js");
require("/server/clip.js");
require("/server/comun.js");
require("/server/link.js");
require("/server/listas.js");
require("/server/post.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29tbW9uL2Jhc2VEZURhdG9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb21tb24vdHJhZHVjY2lvbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb21tb24vdmFyaW9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY2xpcC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbXVuLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbGluay5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2xpc3Rhcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3Bvc3QuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiY2xpcHMiLCJwb3N0cyIsImxpbmtzIiwibG9jYWxMaW5rcyIsImZhdm9yaXRvcyIsIk1vbmdvIiwibGluayIsInYiLCJNZXRlb3IiLCJDb2xsZWN0aW9uIiwiaXNDbGllbnQiLCJQZXJzaXN0ZW50TWluaW1vbmdvMiIsImlzRGV2ZWxvcG1lbnQiLCJnbG9iYWwiLCJ0cmFkdWNjaW9uZXMiLCJpZGlvbWFzIiwidGl0dWxvQVVybCIsImRpYWNyaXRpY2FzIiwiw6EiLCLDqSIsIsOtIiwiw7MiLCLDuiIsIsOxIiwiw6ciLCJ0aXR1bG8iLCJ0b0xvd2VyQ2FzZSIsInJlcGxhY2UiLCJsZXRyYSIsIlJhbmRvbSIsInNhbGlyVmFsaWRhY2lvbiIsInNhbGlyIiwiSm9pIiwiZGVmYXVsdCIsInZhbGlkYWNpb25lcyIsInJldm9jYXIiLCJvYmplY3QiLCJrZXlzIiwiY2xpcElkIiwic3RyaW5nIiwicmVxdWlyZWQiLCJzZWd1cmlkYWQiLCJsbGF2ZSIsInZhbGlkIiwib2J0ZW5lclNlY3JldG8iLCJ1cmwiLCJyZWdleCIsImNsaXBJZFB1Ymxpc2giLCJzZWNyZXRvIiwiX2lkIiwibWV0aG9kcyIsImNsaXBJZFRvVXJsIiwiZGF0YSIsInNjaGVtYSIsImNsaXAiLCJmaW5kT25lIiwiZmllbGRzIiwiY3JlYXJDbGlwIiwiZmluZCIsImxpbWl0IiwiY291bnQiLCJzZWNyZXQiLCJpbnNlcnQiLCJhY3R1YWxpemFjaW9uIiwiRGF0ZSIsInRlc3RUaXR1bG8iLCJjb25zb2xlIiwibG9nIiwiRXJyb3IiLCJvcGNpb25lcyIsImRlYnVnIiwiZG9uZGUiLCJ1cGRhdGUiLCIkc2V0IiwicHVibGlzaCIsImNvZGlnbyIsIm1lbnNhamUiLCJlcnIiLCJzdGFjayIsIkpTT04iLCJzdHJpbmdpZnkiLCJ2YWxpZGFjaW9uIiwidmFsaWRhdGUiLCJlcnJvciIsIk9iamVjdCIsImFzc2lnbiIsImRldGFpbHMiLCJtZXNzYWdlIiwiX29iamVjdCIsIkhUVFAiLCJvZ3MiLCJtZXRlb3JPR1MiLCJ3cmFwQXN5bmMiLCJjYWxsYmFjayIsImUiLCJyIiwicnJzcyIsIkluc3RhZ3JhbSIsInJlc3BvbnNlIiwiZGVzY3JpcHRpb24iLCJ0aXRsZSIsIlR3aXR0ZXIiLCJyZWRkaXQiLCJzaXRlTmFtZUZyb21VcmwiLCJtYXRjaCIsImFjdHVhbGl6YXIiLCJodG1sIiwiZ2V0IiwiaGVhZGVycyIsImNvbnRlbnQiLCJvZ1NpdGVOYW1lIiwib2dVcmwiLCJBcnJheSIsImZyb20iLCJTZXQiLCJvZ0Rlc2NyaXB0aW9uIiwib2dUaXRsZSIsImltYWdlIiwib2dJbWFnZSIsInR5cGUiLCJvZ1R5cGUiLCJzaXRlTmFtZSIsInR3aXR0ZXJTaXRlIiwiaW5zZXJ0YXIiLCJsIiwiJGluIiwiJGFkZFRvU2V0IiwiJGVhY2giLCJhY3R1YWxpemFkbyIsImxpbmtJZCIsInByaW1lclBvc3QiLCIkZ3QiLCJzb3J0IiwiYnVzcXVlZGEiLCJSZWdFeHAiLCJzdGF0dXMiLCJwcmlvcmlkYWQiLCJ0aW1lc3RhbXAiLCJhZ3JlZ2FyUG9zdCIsImNhbWJpYXJQcmlvcmlkYWQiLCJwb3N0SWQiLCJudW1iZXIiLCJlc3RhYmxlY2VyU3RhdHVzIiwiZWxpbWluYXJQb3N0IiwicG9zdHNWaXNpYmxlcyIsInBvc3RzTm9WaXNpYmxlcyIsInRlc3RTZWNyZXRvQ2xpcCIsInBvc3QiLCIkaW5jIiwicmVtb3ZlIiwiJG5lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxPQUFLLEVBQUMsTUFBSUEsS0FBWDtBQUFpQkMsT0FBSyxFQUFDLE1BQUlBLEtBQTNCO0FBQWlDQyxPQUFLLEVBQUMsTUFBSUEsS0FBM0M7QUFBaURDLFlBQVUsRUFBQyxNQUFJQSxVQUFoRTtBQUEyRUMsV0FBUyxFQUFDLE1BQUlBO0FBQXpGLENBQWQ7QUFBbUgsSUFBSUMsS0FBSjtBQUFVUCxNQUFNLENBQUNRLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNELE9BQUssQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFNBQUssR0FBQ0UsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJQyxNQUFKO0FBQVdWLE1BQU0sQ0FBQ1EsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBR25MLE1BQU1QLEtBQUssR0FBRyxJQUFJSyxLQUFLLENBQUNJLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUNBLE1BQU1SLEtBQUssR0FBRyxJQUFJSSxLQUFLLENBQUNJLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUNBLE1BQU1QLEtBQUssR0FBRyxJQUFJRyxLQUFLLENBQUNJLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUVBLElBQUlOLFVBQUo7QUFDQSxJQUFJQyxTQUFKOztBQUVQLElBQUlJLE1BQU0sQ0FBQ0UsUUFBWCxFQUFxQjtBQUNuQixvQkFBQU4sU0FBUyxHQUFHLElBQUlDLEtBQUssQ0FBQ0ksVUFBVixDQUFxQixJQUFyQixDQUFaO0FBQ0E7O0FBQ0EsTUFBSUUsb0JBQUosQ0FBeUJQLFNBQXpCLEVBQW9DLFdBQXBDO0FBRUEsb0JBQUFELFVBQVUsR0FBRyxJQUFJRSxLQUFLLENBQUNJLFVBQVYsQ0FBcUIsSUFBckIsQ0FBYjtBQUNBOztBQUNBLE1BQUlFLG9CQUFKLENBQXlCUixVQUF6QixFQUFxQyxZQUFyQztBQUNEOztBQUVELElBQUlLLE1BQU0sQ0FBQ0ksYUFBWCxFQUEwQjtBQUN4QkMsUUFBTSxDQUFDVCxTQUFQLEdBQW1CQSxTQUFuQjtBQUNBUyxRQUFNLENBQUNiLEtBQVAsR0FBZUEsS0FBZjtBQUNBYSxRQUFNLENBQUNaLEtBQVAsR0FBZUEsS0FBZjtBQUNBWSxRQUFNLENBQUNYLEtBQVAsR0FBZUEsS0FBZjtBQUNBVyxRQUFNLENBQUNWLFVBQVAsR0FBb0JBLFVBQXBCO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUMxQkRMLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNlLGNBQVksRUFBQyxNQUFJQSxZQUFsQjtBQUErQkMsU0FBTyxFQUFDLE1BQUlBO0FBQTNDLENBQWQ7QUFFTyxNQUFNRCxZQUFZLEdBQUc7QUFDMUIsYUFBVztBQUNULFVBQU0sUUFERztBQUVULFVBQU07QUFGRyxHQURlO0FBSzFCLDZCQUEyQjtBQUN6QixVQUFNLG9CQURtQjtBQUV6QixVQUFNO0FBRm1CLEdBTEQ7QUFTMUIsYUFBVztBQUNULFVBQU0sS0FERztBQUVULFVBQU07QUFGRyxHQVRlO0FBYTFCLG9CQUFrQjtBQUNoQixVQUFNLFVBRFU7QUFFaEIsVUFBTTtBQUZVLEdBYlE7QUFpQjFCLGFBQVc7QUFDVCxVQUFNLFNBREc7QUFFVCxVQUFNO0FBRkcsR0FqQmU7QUFxQjFCLFdBQVM7QUFDUCxVQUFNLE1BREM7QUFFUCxVQUFNO0FBRkMsR0FyQmlCO0FBeUIxQixpQkFBZTtBQUNiLFVBQU0sYUFETztBQUViLFVBQU07QUFGTyxHQXpCVztBQTZCMUIsZUFBYTtBQUNYLFVBQU0sUUFESztBQUVYLFVBQU07QUFGSyxHQTdCYTtBQWlDMUIsY0FBWTtBQUNWLFVBQU0sUUFESTtBQUVWLFVBQU07QUFGSSxHQWpDYztBQXFDMUIsZ0JBQWM7QUFDWixVQUFNLFlBRE07QUFFWixVQUFNO0FBRk0sR0FyQ1k7QUF5QzFCLGVBQWE7QUFDWCxVQUFNLE9BREs7QUFFWCxVQUFNO0FBRkssR0F6Q2E7QUE2QzFCLGlEQUErQztBQUM3QyxVQUFNLG1DQUR1QztBQUU3QyxVQUFNO0FBRnVDLEdBN0NyQjtBQWlEMUIsZ0ZBQThFO0FBQzVFLFVBQU0sb0NBRHNFO0FBRTVFLFVBQU07QUFGc0UsR0FqRHBEO0FBcUQxQixXQUFTO0FBQ1AsVUFBTSxRQURDO0FBRVAsVUFBTTtBQUZDLEdBckRpQjtBQXlEMUIsZ0JBQWM7QUFDWixVQUFNLGFBRE07QUFFWixVQUFNO0FBRk0sR0F6RFk7QUE2RDFCLGNBQVk7QUFDVixVQUFNLFFBREk7QUFFVixVQUFNO0FBRkksR0E3RGM7QUFpRTFCLG9DQUFrQztBQUNoQyxVQUFNLDRCQUQwQjtBQUVoQyxVQUFNO0FBRjBCLEdBakVSO0FBcUUxQixlQUFhO0FBQ1gsVUFBTSxXQURLO0FBRVgsVUFBTTtBQUZLLEdBckVhO0FBeUUxQixXQUFTO0FBQ1AsVUFBTSxNQURDO0FBRVAsVUFBTTtBQUZDLEdBekVpQjtBQTZFMUIsWUFBVTtBQUNSLFVBQU0sVUFERTtBQUVSLFVBQU07QUFGRSxHQTdFZ0I7QUFpRjFCLDZCQUEyQjtBQUN6QixVQUFNLFdBRG1CO0FBRXpCLFVBQU07QUFGbUIsR0FqRkQ7QUFxRjFCLHdCQUFzQjtBQUNwQixVQUFNLFVBRGM7QUFFcEIsVUFBTTtBQUZjLEdBckZJO0FBeUYxQixZQUFVO0FBQ1IsVUFBTSxNQURFO0FBRVIsVUFBTTtBQUZFLEdBekZnQjtBQTZGMUIsNkdBQTJHO0FBQ3pHLFVBQU0sdUVBRG1HO0FBRXpHLFVBQU07QUFGbUcsR0E3RmpGO0FBaUcxQixhQUFXO0FBQ1QsVUFBTSxNQURHO0FBRVQsVUFBTTtBQUZHLEdBakdlO0FBcUcxQixhQUFXO0FBQ1QsVUFBTSxNQURHO0FBRVQsVUFBTTtBQUZHLEdBckdlO0FBeUcxQixhQUFXO0FBQ1QsVUFBTSxRQURHO0FBRVQsVUFBTTtBQUZHLEdBekdlO0FBNkcxQixrQkFBZ0I7QUFDZCxVQUFNLGNBRFE7QUFFZCxVQUFNO0FBRlEsR0E3R1U7QUFpSDFCLGVBQWE7QUFDWCxVQUFNLFVBREs7QUFFWCxVQUFNO0FBRkssR0FqSGE7QUFxSDFCLGFBQVc7QUFDVCxVQUFNLFNBREc7QUFFVCxVQUFNO0FBRkcsR0FySGU7QUF5SDFCLGNBQVk7QUFDVixVQUFNLFFBREk7QUFFVixVQUFNO0FBRkksR0F6SGM7QUE2SDFCLGNBQVk7QUFDVixVQUFNLFVBREk7QUFFVixVQUFNO0FBRkksR0E3SGM7QUFpSTFCLGVBQWE7QUFDWCxVQUFNLE1BREs7QUFFWCxVQUFNO0FBRkssR0FqSWE7QUFxSTFCLHVEQUFxRDtBQUNuRCxVQUFNLHFDQUQ2QztBQUVuRCxVQUFNO0FBRjZDLEdBckkzQjtBQXlJMUIsWUFBVTtBQUNSLFVBQU0sT0FERTtBQUVSLFVBQU07QUFGRSxHQXpJZ0I7QUE2STFCLHdFQUFzRTtBQUNwRSxVQUFNLDRDQUQ4RDtBQUVwRSxVQUFNO0FBRjhELEdBN0k1QztBQWlKMUIsY0FBWTtBQUNWLFVBQU0sV0FESTtBQUVWLFVBQU07QUFGSSxHQWpKYztBQXFKMUIsZ0NBQThCO0FBQzVCLFVBQU0sNkJBRHNCO0FBRTVCLFVBQU07QUFGc0IsR0FySko7QUF5SjFCLG1DQUFpQztBQUMvQixVQUFNLCtCQUR5QjtBQUUvQixVQUFNO0FBRnlCLEdBekpQO0FBNkoxQixXQUFTO0FBQ1AsVUFBTSxVQURDO0FBRVAsVUFBTTtBQUZDO0FBN0ppQixDQUFyQjtBQW1LQSxNQUFNQyxPQUFPLEdBQUc7QUFDckIsUUFBTSxDQURlO0FBRXJCLFFBQU07QUFGZSxDQUFoQixDOzs7Ozs7Ozs7OztBQ3JLUGpCLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNpQixZQUFVLEVBQUMsTUFBSUE7QUFBaEIsQ0FBZDtBQUFBLE1BQU1DLFdBQVcsR0FBRztBQUNsQkMsR0FBQyxFQUFFLEdBRGU7QUFFbEJDLEdBQUMsRUFBRSxHQUZlO0FBR2xCQyxHQUFDLEVBQUUsR0FIZTtBQUlsQkMsR0FBQyxFQUFFLEdBSmU7QUFLbEJDLEdBQUMsRUFBRSxHQUxlO0FBTWxCQyxHQUFDLEVBQUUsR0FOZTtBQU9sQkMsR0FBQyxFQUFFO0FBUGUsQ0FBcEI7O0FBVU8sTUFBTVIsVUFBVSxHQUFHLFNBQVNBLFVBQVQsQ0FBcUJTLE1BQXJCLEVBQTZCO0FBQ3JELFNBQU8sQ0FBQ0EsTUFBTSxJQUFJLEVBQVgsRUFBZUMsV0FBZixHQUE2QkMsT0FBN0IsQ0FBcUMsTUFBckMsRUFBNkMsR0FBN0MsRUFBa0RBLE9BQWxELENBQTBELFlBQTFELEVBQXdFLFVBQVVDLEtBQVYsRUFBaUI7QUFDOUYsV0FBT1gsV0FBVyxDQUFDVyxLQUFELENBQWxCO0FBQ0QsR0FGTSxFQUVKRCxPQUZJLENBRUksZ0JBRkosRUFFc0IsRUFGdEIsQ0FBUDtBQUdELENBSk0sQzs7Ozs7Ozs7Ozs7QUNWUCxJQUFJbkIsTUFBSjtBQUFXVixNQUFNLENBQUNRLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJc0IsTUFBSjtBQUFXL0IsTUFBTSxDQUFDUSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDdUIsUUFBTSxDQUFDdEIsQ0FBRCxFQUFHO0FBQUNzQixVQUFNLEdBQUN0QixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlQLEtBQUo7QUFBVUYsTUFBTSxDQUFDUSxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ04sT0FBSyxDQUFDTyxDQUFELEVBQUc7QUFBQ1AsU0FBSyxHQUFDTyxDQUFOO0FBQVE7O0FBQWxCLENBQWxDLEVBQXNELENBQXREO0FBQXlELElBQUl1QixlQUFKLEVBQW9CQyxLQUFwQjtBQUEwQmpDLE1BQU0sQ0FBQ1EsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3dCLGlCQUFlLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLG1CQUFlLEdBQUN2QixDQUFoQjtBQUFrQixHQUF0Qzs7QUFBdUN3QixPQUFLLENBQUN4QixDQUFELEVBQUc7QUFBQ3dCLFNBQUssR0FBQ3hCLENBQU47QUFBUTs7QUFBeEQsQ0FBNUIsRUFBc0YsQ0FBdEY7QUFBeUYsSUFBSVMsVUFBSjtBQUFlbEIsTUFBTSxDQUFDUSxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ1UsWUFBVSxDQUFDVCxDQUFELEVBQUc7QUFBQ1MsY0FBVSxHQUFDVCxDQUFYO0FBQWE7O0FBQTVCLENBQTdCLEVBQTJELENBQTNEO0FBQThELElBQUl5QixHQUFKO0FBQVFsQyxNQUFNLENBQUNRLElBQVAsQ0FBWSxLQUFaLEVBQWtCO0FBQUMyQixTQUFPLENBQUMxQixDQUFELEVBQUc7QUFBQ3lCLE9BQUcsR0FBQ3pCLENBQUo7QUFBTTs7QUFBbEIsQ0FBbEIsRUFBc0MsQ0FBdEM7QUFRM1ksTUFBTTJCLFlBQVksR0FBRztBQUNuQkMsU0FBTyxFQUFFSCxHQUFHLENBQUNJLE1BQUosR0FBYUMsSUFBYixDQUFrQjtBQUN6QkMsVUFBTSxFQUFFTixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQURpQjtBQUV6QkMsYUFBUyxFQUFFVCxHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUZjO0FBR3pCRSxTQUFLLEVBQUVWLEdBQUcsQ0FBQ08sTUFBSixHQUFhSSxLQUFiLENBQW1CLENBQUMsV0FBRCxFQUFjLFNBQWQsQ0FBbkIsRUFBNkNILFFBQTdDO0FBSGtCLEdBQWxCLENBRFU7QUFNbkJJLGdCQUFjLEVBQUVaLEdBQUcsQ0FBQ0ksTUFBSixHQUFhQyxJQUFiLENBQWtCO0FBQ2hDQyxVQUFNLEVBQUVOLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRHdCO0FBRWhDQyxhQUFTLEVBQUVULEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiO0FBRnFCLEdBQWxCLENBTkc7QUFVbkJLLEtBQUcsRUFBRWIsR0FBRyxDQUFDTyxNQUFKLEdBQWFPLEtBQWIsQ0FBbUIsV0FBbkIsRUFBZ0NOLFFBQWhDLEVBVmM7QUFXbkJPLGVBQWEsRUFBRWYsR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDL0JDLFVBQU0sRUFBRU4sR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFEdUI7QUFFL0JRLFdBQU8sRUFBRWhCLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiO0FBRnNCLEdBQWxCLENBWEk7QUFlbkJmLFFBQU0sRUFBRU8sR0FBRyxDQUFDTyxNQUFKLEVBZlc7QUFnQm5CVSxLQUFHLEVBQUVqQixHQUFHLENBQUNPLE1BQUo7QUFoQmMsQ0FBckI7QUFtQkEvQixNQUFNLENBQUMwQyxPQUFQLENBQWU7QUFDYkMsYUFBVyxDQUFFRixHQUFGLEVBQU87QUFDaEJuQixtQkFBZSxDQUFDO0FBQ2RzQixVQUFJLEVBQUVILEdBRFE7QUFFZEksWUFBTSxFQUFFbkIsWUFBWSxDQUFDZTtBQUZQLEtBQUQsQ0FBZjtBQUlBLFVBQU1LLElBQUksR0FBR3RELEtBQUssQ0FBQ3VELE9BQU4sQ0FBY04sR0FBZCxFQUFtQjtBQUM5Qk8sWUFBTSxFQUFFO0FBQ05YLFdBQUcsRUFBRTtBQURDO0FBRHNCLEtBQW5CLEtBSVBkLEtBQUssQ0FBQyxHQUFELEVBQU0sb0JBQU4sQ0FKWDtBQUtBLFdBQU91QixJQUFJLENBQUNULEdBQVo7QUFDRCxHQVpZOztBQWFiWSxXQUFTLENBQUVoQyxNQUFGLEVBQVU7QUFDakJLLG1CQUFlLENBQUM7QUFDZHNCLFVBQUksRUFBRTNCLE1BRFE7QUFFZDRCLFlBQU0sRUFBRW5CLFlBQVksQ0FBQ1Q7QUFGUCxLQUFELENBQWY7QUFLQSxVQUFNb0IsR0FBRyxHQUFHN0IsVUFBVSxDQUFDUyxNQUFELENBQXRCO0FBQ0F6QixTQUFLLENBQUMwRCxJQUFOLENBQVc7QUFDVGI7QUFEUyxLQUFYLEVBRUc7QUFDRGMsV0FBSyxFQUFFO0FBRE4sS0FGSCxFQUlHQyxLQUpILE1BSWM3QixLQUFLLENBQUMsR0FBRCxFQUFNLGNBQU4sQ0FKbkI7QUFNQSxVQUFNaUIsT0FBTyxHQUFHbkIsTUFBTSxDQUFDZ0MsTUFBUCxFQUFoQjtBQUNBLFVBQU1wQixTQUFTLEdBQUdaLE1BQU0sQ0FBQ2dDLE1BQVAsRUFBbEI7QUFDQSxVQUFNdkIsTUFBTSxHQUFHdEMsS0FBSyxDQUFDOEQsTUFBTixDQUFhO0FBQzFCQyxtQkFBYSxFQUFFLElBQUlDLElBQUosRUFEVztBQUUxQnZDLFlBRjBCO0FBRzFCb0IsU0FIMEI7QUFJMUJHLGFBSjBCO0FBSzFCUCxlQUwwQjtBQU0xQnhDLFdBQUssRUFBRTtBQU5tQixLQUFiLENBQWY7QUFTQSxXQUFPO0FBQ0xxQyxZQURLO0FBRUxVLGFBRks7QUFHTFA7QUFISyxLQUFQO0FBS0QsR0ExQ1k7O0FBMkNid0IsWUFBVSxDQUFFeEMsTUFBRixFQUFVO0FBQ2xCSyxtQkFBZSxDQUFDO0FBQ2RzQixVQUFJLEVBQUUzQixNQURRO0FBRWQ0QixZQUFNLEVBQUVuQixZQUFZLENBQUNUO0FBRlAsS0FBRCxDQUFmOztBQUlBLFFBQUl6QixLQUFLLENBQUMwRCxJQUFOLENBQVc7QUFDYmpDO0FBRGEsS0FBWCxFQUVEO0FBQ0RrQyxXQUFLLEVBQUU7QUFETixLQUZDLEVBSURDLEtBSkMsRUFBSixFQUlZO0FBQ1ZNLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaO0FBQ0EsWUFBTSxJQUFJM0QsTUFBTSxDQUFDNEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixpQkFBdEIsQ0FBTjtBQUNEOztBQUNELFVBQU12QixHQUFHLEdBQUc3QixVQUFVLENBQUNTLE1BQUQsQ0FBdEI7O0FBQ0EsUUFBSXpCLEtBQUssQ0FBQzBELElBQU4sQ0FBVztBQUNiYjtBQURhLEtBQVgsRUFFRDtBQUNEYyxXQUFLLEVBQUU7QUFETixLQUZDLEVBSURDLEtBSkMsRUFBSixFQUlZO0FBQ1YsWUFBTSxJQUFJcEQsTUFBTSxDQUFDNEQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixjQUF0QixDQUFOO0FBQ0Q7QUFDRixHQWhFWTs7QUFpRWJqQyxTQUFPLENBQUVrQyxRQUFGLEVBQVk7QUFDakJ2QyxtQkFBZSxDQUFDO0FBQ2RzQixVQUFJLEVBQUVpQixRQURRO0FBRWRoQixZQUFNLEVBQUVuQixZQUFZLENBQUNDLE9BRlA7QUFHZG1DLFdBQUssRUFBRTtBQUNMQyxhQUFLLEVBQUU7QUFERjtBQUhPLEtBQUQsQ0FBZjtBQVFBdkUsU0FBSyxDQUFDMEQsSUFBTixDQUFXO0FBQ1RULFNBQUcsRUFBRW9CLFFBQVEsQ0FBQy9CO0FBREwsS0FBWCxFQUVHc0IsS0FGSCxNQUVjN0IsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixDQUZuQjtBQUlBL0IsU0FBSyxDQUFDMEQsSUFBTixDQUFXO0FBQ1RULFNBQUcsRUFBRW9CLFFBQVEsQ0FBQy9CLE1BREw7QUFFVEcsZUFBUyxFQUFFNEIsUUFBUSxDQUFDNUI7QUFGWCxLQUFYLEVBR0dtQixLQUhILE1BR2M3QixLQUFLLENBQUMsR0FBRCxFQUFNLHVDQUFOLENBSG5CO0FBS0EsVUFBTVcsS0FBSyxHQUFHYixNQUFNLENBQUNnQyxNQUFQLEVBQWQ7QUFFQTdELFNBQUssQ0FBQ3dFLE1BQU4sQ0FBYUgsUUFBUSxDQUFDL0IsTUFBdEIsRUFBOEI7QUFDNUJtQyxVQUFJLEVBQUU7QUFDSixTQUFDSixRQUFRLENBQUMzQixLQUFWLEdBQWtCQTtBQURkO0FBRHNCLEtBQTlCO0FBS0EsV0FBT0EsS0FBUDtBQUNELEdBM0ZZOztBQTRGYkUsZ0JBQWMsQ0FBRXlCLFFBQUYsRUFBWTtBQUN4QnZDLG1CQUFlLENBQUM7QUFDZHNCLFVBQUksRUFBRWlCLFFBRFE7QUFFZGhCLFlBQU0sRUFBRW5CLFlBQVksQ0FBQ1U7QUFGUCxLQUFELENBQWY7QUFLQTVDLFNBQUssQ0FBQzBELElBQU4sQ0FBVztBQUNUVCxTQUFHLEVBQUVvQixRQUFRLENBQUMvQjtBQURMLEtBQVgsRUFFR3NCLEtBRkgsTUFFYzdCLEtBQUssQ0FBQyxHQUFELEVBQU0sb0JBQU4sQ0FGbkI7QUFJQSxVQUFNdUIsSUFBSSxHQUFHdEQsS0FBSyxDQUFDdUQsT0FBTixDQUFjO0FBQ3pCTixTQUFHLEVBQUVvQixRQUFRLENBQUMvQixNQURXO0FBRXpCRyxlQUFTLEVBQUU0QixRQUFRLENBQUM1QjtBQUZLLEtBQWQsS0FHUFYsS0FBSyxDQUFDLEdBQUQsRUFBTSwyREFBTixDQUhYO0FBS0EsV0FBT3VCLElBQUksQ0FBQ04sT0FBWjtBQUNEOztBQTVHWSxDQUFmO0FBK0dBeEMsTUFBTSxDQUFDa0UsT0FBUCxDQUFlLFNBQWYsRUFBMEIsVUFBVTdCLEdBQVYsRUFBZTtBQUN2Q2YsaUJBQWUsQ0FBQztBQUNkc0IsUUFBSSxFQUFFUCxHQURRO0FBRWRRLFVBQU0sRUFBRW5CLFlBQVksQ0FBQ1c7QUFGUCxHQUFELENBQWY7QUFLQSxTQUFPN0MsS0FBSyxDQUFDMEQsSUFBTixDQUFXO0FBQ2hCYjtBQURnQixHQUFYLEVBRUo7QUFDRFcsVUFBTSxFQUFFO0FBQ05mLGVBQVMsRUFBRSxDQURMO0FBRU5PLGFBQU8sRUFBRTtBQUZIO0FBRFAsR0FGSSxDQUFQO0FBUUQsQ0FkRDtBQWVBeEMsTUFBTSxDQUFDa0UsT0FBUCxDQUFlLFFBQWYsRUFBeUIsVUFBVXpCLEdBQVYsRUFBZTtBQUN0Q25CLGlCQUFlLENBQUM7QUFDZHNCLFFBQUksRUFBRUgsR0FEUTtBQUVkSSxVQUFNLEVBQUVuQixZQUFZLENBQUNlO0FBRlAsR0FBRCxDQUFmO0FBS0EsU0FBT2pELEtBQUssQ0FBQzBELElBQU4sQ0FBVztBQUNoQlQ7QUFEZ0IsR0FBWCxFQUVKO0FBQ0RPLFVBQU0sRUFBRTtBQUNOZixlQUFTLEVBQUUsQ0FETDtBQUVOTyxhQUFPLEVBQUU7QUFGSDtBQURQLEdBRkksQ0FBUDtBQVFELENBZEQsRTs7Ozs7Ozs7Ozs7QUN6SkFsRCxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDZ0MsT0FBSyxFQUFDLE1BQUlBLEtBQVg7QUFBaUJELGlCQUFlLEVBQUMsTUFBSUE7QUFBckMsQ0FBZDtBQUFxRSxJQUFJdEIsTUFBSjtBQUFXVixNQUFNLENBQUNRLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeUIsR0FBSjtBQUFRbEMsTUFBTSxDQUFDUSxJQUFQLENBQVksS0FBWixFQUFrQjtBQUFDMkIsU0FBTyxDQUFDMUIsQ0FBRCxFQUFHO0FBQUN5QixPQUFHLEdBQUN6QixDQUFKO0FBQU07O0FBQWxCLENBQWxCLEVBQXNDLENBQXRDOztBQUd0SSxNQUFNd0IsS0FBSyxHQUFHLFNBQVNBLEtBQVQsQ0FBZ0I0QyxNQUFoQixFQUF3QkMsT0FBeEIsRUFBaUNOLEtBQWpDLEVBQXdDO0FBQzNELE1BQUk5RCxNQUFNLENBQUNJLGFBQVgsRUFBMEI7QUFDeEJzRCxXQUFPLENBQUNDLEdBQVIsQ0FBWVEsTUFBWixFQUFvQkMsT0FBcEI7QUFDQSxVQUFNQyxHQUFHLEdBQUcsSUFBSVQsS0FBSixFQUFaO0FBQ0FGLFdBQU8sQ0FBQ0MsR0FBUixDQUFZVSxHQUFHLENBQUNDLEtBQWhCO0FBQ0FaLFdBQU8sQ0FBQ0MsR0FBUixDQUFZWSxJQUFJLENBQUNDLFNBQUwsQ0FBZVYsS0FBZixFQUFzQixJQUF0QixFQUE0QixDQUE1QixDQUFaO0FBQ0Q7O0FBQ0QsUUFBTSxJQUFJOUQsTUFBTSxDQUFDNEQsS0FBWCxDQUFpQk8sTUFBakIsRUFBeUJDLE9BQXpCLENBQU47QUFDRCxDQVJNOztBQVVBLE1BQU05QyxlQUFlLEdBQUcsVUFBVXVDLFFBQVYsRUFBb0I7QUFDakQsUUFBTVksVUFBVSxHQUFHakQsR0FBRyxDQUFDa0QsUUFBSixDQUFhYixRQUFRLENBQUNqQixJQUF0QixFQUE0QmlCLFFBQVEsQ0FBQ2hCLE1BQXJDLENBQW5COztBQUNBLE1BQUksQ0FBQzRCLFVBQVUsQ0FBQ0UsS0FBaEIsRUFBdUI7QUFDckI7QUFDRDs7QUFDRGQsVUFBUSxHQUFHZSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUN2QlYsVUFBTSxFQUFFLEdBRGU7QUFFdkJDLFdBQU8sRUFBRUssVUFBVSxDQUFDRSxLQUFYLENBQWlCRyxPQUFqQixDQUF5QixDQUF6QixFQUE0QkM7QUFGZCxHQUFkLEVBR1JsQixRQUhRLENBQVg7O0FBSUEsTUFBSUEsUUFBUSxDQUFDQyxLQUFiLEVBQW9CO0FBQ2xCRCxZQUFRLENBQUNDLEtBQVQsQ0FBZWdCLE9BQWYsR0FBeUJMLFVBQVUsQ0FBQ0UsS0FBWCxDQUFpQkcsT0FBMUM7QUFDQWpCLFlBQVEsQ0FBQ0MsS0FBVCxDQUFla0IsT0FBZixHQUF5QlAsVUFBVSxDQUFDRSxLQUFYLENBQWlCSyxPQUExQztBQUNEOztBQUNEekQsT0FBSyxDQUFDc0MsUUFBUSxDQUFDTSxNQUFWLEVBQWtCTixRQUFRLENBQUNPLE9BQTNCLEVBQW9DUCxRQUFRLENBQUNDLEtBQTdDLENBQUw7QUFDRCxDQWRNLEM7Ozs7Ozs7Ozs7O0FDYlAsSUFBSW1CLElBQUo7QUFBUzNGLE1BQU0sQ0FBQ1EsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ21GLE1BQUksQ0FBQ2xGLENBQUQsRUFBRztBQUFDa0YsUUFBSSxHQUFDbEYsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJQyxNQUFKO0FBQVdWLE1BQU0sQ0FBQ1EsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlMLEtBQUo7QUFBVUosTUFBTSxDQUFDUSxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ0osT0FBSyxDQUFDSyxDQUFELEVBQUc7QUFBQ0wsU0FBSyxHQUFDSyxDQUFOO0FBQVE7O0FBQWxCLENBQWxDLEVBQXNELENBQXREO0FBQXlELElBQUl1QixlQUFKO0FBQW9CaEMsTUFBTSxDQUFDUSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDd0IsaUJBQWUsQ0FBQ3ZCLENBQUQsRUFBRztBQUFDdUIsbUJBQWUsR0FBQ3ZCLENBQWhCO0FBQWtCOztBQUF0QyxDQUE1QixFQUFvRSxDQUFwRTtBQUF1RSxJQUFJbUYsR0FBSjtBQUFRNUYsTUFBTSxDQUFDUSxJQUFQLENBQVksb0JBQVosRUFBaUM7QUFBQzJCLFNBQU8sQ0FBQzFCLENBQUQsRUFBRztBQUFDbUYsT0FBRyxHQUFDbkYsQ0FBSjtBQUFNOztBQUFsQixDQUFqQyxFQUFxRCxDQUFyRDtBQUF3RCxJQUFJeUIsR0FBSjtBQUFRbEMsTUFBTSxDQUFDUSxJQUFQLENBQVksS0FBWixFQUFrQjtBQUFDMkIsU0FBTyxDQUFDMUIsQ0FBRCxFQUFHO0FBQUN5QixPQUFHLEdBQUN6QixDQUFKO0FBQU07O0FBQWxCLENBQWxCLEVBQXNDLENBQXRDO0FBUTlWLE1BQU0yQixZQUFZLEdBQUc7QUFDbkJLLFFBQU0sRUFBRVAsR0FBRyxDQUFDTyxNQUFKO0FBRFcsQ0FBckI7QUFJQSxNQUFNb0QsU0FBUyxHQUFHbkYsTUFBTSxDQUFDb0YsU0FBUCxDQUFpQixVQUFVdkIsUUFBVixFQUFvQndCLFFBQXBCLEVBQThCO0FBQy9ESCxLQUFHLENBQUNyQixRQUFELEVBQVcsVUFBVXlCLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUM1QixRQUFJRCxDQUFKLEVBQU87QUFDTCxhQUFPRCxRQUFRLENBQUMsSUFBRCxFQUFPLEVBQVAsQ0FBZjtBQUNEOztBQUNEQSxZQUFRLENBQUMsSUFBRCxFQUFPRSxDQUFQLENBQVI7QUFDRCxHQUxFLENBQUg7QUFNRCxDQVBpQixDQUFsQjtBQVNBLE1BQU1DLElBQUksR0FBRztBQUNYQyxXQUFTLENBQUVDLFFBQUYsRUFBWTtBQUNuQkEsWUFBUSxDQUFDQyxXQUFULEdBQXVCRCxRQUFRLENBQUNFLEtBQVQsQ0FBZXpFLE9BQWYsQ0FBdUIsb0JBQXZCLEVBQTZDLEVBQTdDLENBQXZCO0FBQ0F1RSxZQUFRLENBQUNFLEtBQVQsR0FBaUJGLFFBQVEsQ0FBQ0UsS0FBVCxDQUFlekUsT0FBZixDQUF1QixrQkFBdkIsRUFBMkMsRUFBM0MsQ0FBakI7QUFDQSxXQUFPdUUsUUFBUDtBQUNELEdBTFU7O0FBTVhHLFNBQU8sQ0FBRUgsUUFBRixFQUFZO0FBQ2pCQSxZQUFRLENBQUNFLEtBQVQsR0FBaUJGLFFBQVEsQ0FBQ0UsS0FBVCxDQUFlekUsT0FBZixDQUF1QixhQUF2QixFQUFzQyxFQUF0QyxDQUFqQjtBQUNBLFdBQU91RSxRQUFQO0FBQ0QsR0FUVTs7QUFVWEksUUFBTSxDQUFFSixRQUFGLEVBQVk7QUFDaEJBLFlBQVEsQ0FBQ0MsV0FBVCxHQUF1QkQsUUFBUSxDQUFDRSxLQUFULENBQWV6RSxPQUFmLENBQXVCLFFBQXZCLEVBQWlDLEVBQWpDLENBQXZCO0FBQ0F1RSxZQUFRLENBQUNFLEtBQVQsR0FBaUJGLFFBQVEsQ0FBQ0UsS0FBVCxDQUFlekUsT0FBZixDQUF1QixRQUF2QixFQUFpQyxFQUFqQyxDQUFqQjtBQUNBLFdBQU91RSxRQUFQO0FBQ0Q7O0FBZFUsQ0FBYjs7QUFpQkEsTUFBTUssZUFBZSxHQUFHLFNBQVNBLGVBQVQsQ0FBMEIxRCxHQUExQixFQUErQjtBQUNyREEsS0FBRyxHQUFHQSxHQUFHLENBQUMyRCxLQUFKLENBQVVELGVBQWUsQ0FBQ3pELEtBQTFCLENBQU47QUFDQSxTQUFPRCxHQUFHLENBQUMsQ0FBRCxDQUFWO0FBQ0QsQ0FIRDs7QUFJQTBELGVBQWUsQ0FBQ3pELEtBQWhCLEdBQXdCLGlFQUF4Qjs7QUFDQSxNQUFNMkQsVUFBVSxHQUFHLFNBQVNBLFVBQVQsQ0FBcUI1RCxHQUFyQixFQUEwQjtBQUMzQyxNQUFJcUQsUUFBSjtBQUNBLE1BQUk3QixRQUFKOztBQUVBLE1BQUl4QixHQUFHLENBQUMyRCxLQUFKLENBQVUsd0JBQVYsQ0FBSixFQUF5QztBQUN2Q25DLFlBQVEsR0FBRztBQUNUcUMsVUFBSSxFQUFFakIsSUFBSSxDQUFDa0IsR0FBTCxDQUFTOUQsR0FBVCxFQUFjO0FBQ2xCK0QsZUFBTyxFQUFFO0FBQ1Asd0JBQWM7QUFEUDtBQURTLE9BQWQsRUFJSEM7QUFMTSxLQUFYO0FBT0QsR0FSRCxNQVFPO0FBQ0x4QyxZQUFRLEdBQUc7QUFDVHhCO0FBRFMsS0FBWDtBQUdEOztBQUVEcUQsVUFBUSxHQUFHUCxTQUFTLENBQUN0QixRQUFELENBQXBCOztBQUVBLE1BQUksQ0FBQzZCLFFBQUwsRUFBZTtBQUNiO0FBQ0Q7O0FBRUQsTUFBSXJELEdBQUcsQ0FBQzJELEtBQUosQ0FBVSx3QkFBVixDQUFKLEVBQXlDO0FBQ3ZDTixZQUFRLENBQUM5QyxJQUFULENBQWMwRCxVQUFkLEdBQTJCLFVBQTNCO0FBQ0Q7O0FBRUQsTUFBSVosUUFBUSxDQUFDOUMsSUFBVCxDQUFjMkQsS0FBbEIsRUFBeUI7QUFDdkJsRSxPQUFHLEdBQUdtRSxLQUFLLENBQUNDLElBQU4sQ0FBVyxJQUFJQyxHQUFKLENBQVEsQ0FBQ2hCLFFBQVEsQ0FBQzlDLElBQVQsQ0FBYzJELEtBQWYsRUFBc0JsRSxHQUF0QixDQUFSLENBQVgsQ0FBTjtBQUNELEdBRkQsTUFFTztBQUNMQSxPQUFHLEdBQUcsQ0FBQ0EsR0FBRCxDQUFOO0FBQ0Q7O0FBRURxRCxVQUFRLEdBQUc7QUFDVEMsZUFBVyxFQUFFRCxRQUFRLENBQUM5QyxJQUFULENBQWMrRCxhQURsQjtBQUVUZixTQUFLLEVBQUVGLFFBQVEsQ0FBQzlDLElBQVQsQ0FBY2dFLE9BRlo7QUFHVEMsU0FBSyxFQUFFLENBQUNuQixRQUFRLENBQUM5QyxJQUFULENBQWNrRSxPQUFkLElBQXlCLEVBQTFCLEVBQThCekUsR0FINUI7QUFJVDBFLFFBQUksRUFBRXJCLFFBQVEsQ0FBQzlDLElBQVQsQ0FBY29FLE1BSlg7QUFLVDNFLE9BQUcsRUFBRUEsR0FMSTtBQU1UNEUsWUFBUSxFQUFFdkIsUUFBUSxDQUFDOUMsSUFBVCxDQUFjMEQsVUFBZCxJQUE0QlosUUFBUSxDQUFDOUMsSUFBVCxDQUFjc0UsV0FBMUMsSUFBeURuQixlQUFlLENBQUMxRCxHQUFHLENBQUMsQ0FBRCxDQUFKO0FBTnpFLEdBQVg7O0FBU0EsTUFBSW1ELElBQUksQ0FBQ0UsUUFBUSxDQUFDdUIsUUFBVixDQUFSLEVBQTZCO0FBQzNCLFdBQU96QixJQUFJLENBQUNFLFFBQVEsQ0FBQ3VCLFFBQVYsQ0FBSixDQUF3QnZCLFFBQXhCLENBQVA7QUFDRDs7QUFDRCxTQUFPQSxRQUFQO0FBQ0QsQ0EvQ0Q7O0FBaURBLE1BQU15QixRQUFRLEdBQUcsU0FBU0EsUUFBVCxDQUFtQnJILElBQW5CLEVBQXlCO0FBQ3hDNEQsU0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWjtBQUNBLFFBQU15RCxDQUFDLEdBQUcxSCxLQUFLLENBQUNxRCxPQUFOLENBQWM7QUFDdEJWLE9BQUcsRUFBRTtBQUNIZ0YsU0FBRyxFQUFFdkgsSUFBSSxDQUFDdUM7QUFEUDtBQURpQixHQUFkLENBQVY7O0FBTUEsTUFBSStFLENBQUosRUFBTztBQUNMMUgsU0FBSyxDQUFDc0UsTUFBTixDQUFhb0QsQ0FBQyxDQUFDM0UsR0FBZixFQUFvQjtBQUNsQjZFLGVBQVMsRUFBRTtBQUNUakYsV0FBRyxFQUFFO0FBQ0hrRixlQUFLLEVBQUV6SCxJQUFJLENBQUN1QztBQURUO0FBREk7QUFETyxLQUFwQjtBQU9BLFdBQU8rRSxDQUFQO0FBQ0Q7O0FBQ0R0SCxNQUFJLENBQUMwSCxXQUFMLEdBQW1CLElBQUloRSxJQUFKLEVBQW5CO0FBQ0ExRCxNQUFJLENBQUMyQyxHQUFMLEdBQVcvQyxLQUFLLENBQUM0RCxNQUFOLENBQWF4RCxJQUFiLENBQVg7QUFDQSxTQUFPQSxJQUFQO0FBQ0QsQ0FyQkQ7O0FBdUJBRSxNQUFNLENBQUMwQyxPQUFQLENBQWU7QUFDYjVDLE1BQUksQ0FBRXVDLEdBQUYsRUFBTztBQUNUZixtQkFBZSxDQUFDO0FBQ2RzQixVQUFJLEVBQUVQLEdBRFE7QUFFZFEsWUFBTSxFQUFFbkIsWUFBWSxDQUFDSztBQUZQLEtBQUQsQ0FBZjtBQUtBLFdBQU9yQyxLQUFLLENBQUNxRCxPQUFOLENBQWM7QUFDbkJWO0FBRG1CLEtBQWQsS0FFRDhFLFFBQVEsQ0FBQ2xCLFVBQVUsQ0FBQzVELEdBQUQsQ0FBWCxDQUZkO0FBR0QsR0FWWTs7QUFXYm9GLFFBQU0sQ0FBRWhGLEdBQUYsRUFBTztBQUNYbkIsbUJBQWUsQ0FBQztBQUNkc0IsVUFBSSxFQUFFSCxHQURRO0FBRWRJLFlBQU0sRUFBRW5CLFlBQVksQ0FBQ0s7QUFGUCxLQUFELENBQWY7QUFLQSxXQUFPckMsS0FBSyxDQUFDcUQsT0FBTixDQUFjTixHQUFkLENBQVA7QUFDRDs7QUFsQlksQ0FBZixFOzs7Ozs7Ozs7OztBQ25IQSxJQUFJekMsTUFBSjtBQUFXVixNQUFNLENBQUNRLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJUCxLQUFKLEVBQVVDLEtBQVY7QUFBZ0JILE1BQU0sQ0FBQ1EsSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNOLE9BQUssQ0FBQ08sQ0FBRCxFQUFHO0FBQUNQLFNBQUssR0FBQ08sQ0FBTjtBQUFRLEdBQWxCOztBQUFtQk4sT0FBSyxDQUFDTSxDQUFELEVBQUc7QUFBQ04sU0FBSyxHQUFDTSxDQUFOO0FBQVE7O0FBQXBDLENBQWxDLEVBQXdFLENBQXhFO0FBQTJFLElBQUl1QixlQUFKO0FBQW9CaEMsTUFBTSxDQUFDUSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDd0IsaUJBQWUsQ0FBQ3ZCLENBQUQsRUFBRztBQUFDdUIsbUJBQWUsR0FBQ3ZCLENBQWhCO0FBQWtCOztBQUF0QyxDQUE1QixFQUFvRSxDQUFwRTtBQUF1RSxJQUFJeUIsR0FBSjtBQUFRbEMsTUFBTSxDQUFDUSxJQUFQLENBQVksS0FBWixFQUFrQjtBQUFDMkIsU0FBTyxDQUFDMUIsQ0FBRCxFQUFHO0FBQUN5QixPQUFHLEdBQUN6QixDQUFKO0FBQU07O0FBQWxCLENBQWxCLEVBQXNDLENBQXRDO0FBSzlQLE1BQU0yQixZQUFZLEdBQUc7QUFDbkJnRyxZQUFVLEVBQUVsRyxHQUFHLENBQUNPLE1BQUosRUFETztBQUVuQmpDLE1BQUksRUFBRTBCLEdBQUcsQ0FBQ08sTUFBSjtBQUZhLENBQXJCO0FBS0EvQixNQUFNLENBQUNrRSxPQUFQLENBQWUsU0FBZixFQUEwQixZQUFZO0FBQ3BDLFNBQU8xRSxLQUFLLENBQUMwRCxJQUFOLENBQVc7QUFDaEJ6RCxTQUFLLEVBQUU7QUFDTGtJLFNBQUcsRUFBRTtBQURBO0FBRFMsR0FBWCxFQUlKO0FBQ0QzRSxVQUFNLEVBQUU7QUFDTlIsYUFBTyxFQUFFLENBREg7QUFFTlAsZUFBUyxFQUFFO0FBRkwsS0FEUDtBQUtEMkYsUUFBSSxFQUFFO0FBQ0pyRSxtQkFBYSxFQUFFLENBQUM7QUFEWixLQUxMO0FBUURKLFNBQUssRUFBRTtBQVJOLEdBSkksQ0FBUDtBQWNELENBZkQ7QUFpQkFuRCxNQUFNLENBQUNrRSxPQUFQLENBQWUsVUFBZixFQUEyQixVQUFVMkQsUUFBVixFQUFvQjtBQUM3QyxNQUFJdkYsS0FBSyxHQUFHLE1BQVo7O0FBQ0EsTUFBSTtBQUNGQSxTQUFLLEdBQUcsSUFBSXdGLE1BQUosQ0FBV0QsUUFBWCxDQUFSO0FBQ0QsR0FGRCxDQUVFLE9BQU92QyxDQUFQLEVBQVU7QUFDVmhELFNBQUssR0FBRyxJQUFSO0FBQ0Q7O0FBQ0QsU0FBTzlDLEtBQUssQ0FBQzBELElBQU4sQ0FBVztBQUNoQmpDLFVBQU0sRUFBRXFCLEtBRFE7QUFFaEI3QyxTQUFLLEVBQUU7QUFDTGtJLFNBQUcsRUFBRTtBQURBO0FBRlMsR0FBWCxFQUtKO0FBQ0QzRSxVQUFNLEVBQUU7QUFDTlIsYUFBTyxFQUFFLENBREg7QUFFTlAsZUFBUyxFQUFFO0FBRkwsS0FEUDtBQUtEMkYsUUFBSSxFQUFFO0FBQ0pyRSxtQkFBYSxFQUFFLENBQUM7QUFEWixLQUxMO0FBUURKLFNBQUssRUFBRTtBQVJOLEdBTEksQ0FBUDtBQWVELENBdEJEO0FBd0JBbkQsTUFBTSxDQUFDa0UsT0FBUCxDQUFlLFlBQWYsRUFBNkIsVUFBVXBDLE1BQVYsRUFBa0I7QUFDN0NSLGlCQUFlLENBQUM7QUFDZHNCLFFBQUksRUFBRWQsTUFEUTtBQUVkZSxVQUFNLEVBQUVuQixZQUFZLENBQUNnRyxVQUZQO0FBR2Q1RCxTQUFLLEVBQUU7QUFDTEMsV0FBSyxFQUFFO0FBREY7QUFITyxHQUFELENBQWY7QUFRQSxTQUFPdEUsS0FBSyxDQUFDeUQsSUFBTixDQUFXO0FBQ2hCcEIsVUFEZ0I7QUFFaEJpRyxVQUFNLEVBQUU7QUFGUSxHQUFYLEVBR0o7QUFDREgsUUFBSSxFQUFFO0FBQ0pJLGVBQVMsRUFBRSxDQUFDLENBRFI7QUFFSkMsZUFBUyxFQUFFLENBQUM7QUFGUixLQURMO0FBS0Q5RSxTQUFLLEVBQUU7QUFMTixHQUhJLENBQVA7QUFVRCxDQW5CRDtBQXFCQW5ELE1BQU0sQ0FBQ2tFLE9BQVAsQ0FBZSxNQUFmLEVBQXVCLFVBQVVwRSxJQUFWLEVBQWdCO0FBQ3JDLFNBQU9MLEtBQUssQ0FBQ3NELE9BQU4sQ0FBYztBQUNuQmpEO0FBRG1CLEdBQWQsRUFFSjtBQUNEa0QsVUFBTSxFQUFFO0FBQ05sQixZQUFNLEVBQUU7QUFERjtBQURQLEdBRkksQ0FBUDtBQU9ELENBUkQ7QUFTQTlCLE1BQU0sQ0FBQ2tFLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLFVBQVVwRSxJQUFWLEVBQWdCO0FBQ3pDLFNBQU9MLEtBQUssQ0FBQ3lELElBQU4sQ0FBVztBQUNoQnBEO0FBRGdCLEdBQVgsRUFFSjtBQUNEcUQsU0FBSyxFQUFFO0FBRE4sR0FGSSxDQUFQO0FBS0QsQ0FORCxFOzs7Ozs7Ozs7OztBQ2pGQSxJQUFJbkQsTUFBSjtBQUFXVixNQUFNLENBQUNRLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJUCxLQUFKLEVBQVVDLEtBQVY7QUFBZ0JILE1BQU0sQ0FBQ1EsSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNOLE9BQUssQ0FBQ08sQ0FBRCxFQUFHO0FBQUNQLFNBQUssR0FBQ08sQ0FBTjtBQUFRLEdBQWxCOztBQUFtQk4sT0FBSyxDQUFDTSxDQUFELEVBQUc7QUFBQ04sU0FBSyxHQUFDTSxDQUFOO0FBQVE7O0FBQXBDLENBQWxDLEVBQXdFLENBQXhFO0FBQTJFLElBQUl1QixlQUFKLEVBQW9CQyxLQUFwQjtBQUEwQmpDLE1BQU0sQ0FBQ1EsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3dCLGlCQUFlLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLG1CQUFlLEdBQUN2QixDQUFoQjtBQUFrQixHQUF0Qzs7QUFBdUN3QixPQUFLLENBQUN4QixDQUFELEVBQUc7QUFBQ3dCLFNBQUssR0FBQ3hCLENBQU47QUFBUTs7QUFBeEQsQ0FBNUIsRUFBc0YsQ0FBdEY7QUFBeUYsSUFBSXlCLEdBQUo7QUFBUWxDLE1BQU0sQ0FBQ1EsSUFBUCxDQUFZLEtBQVosRUFBa0I7QUFBQzJCLFNBQU8sQ0FBQzFCLENBQUQsRUFBRztBQUFDeUIsT0FBRyxHQUFDekIsQ0FBSjtBQUFNOztBQUFsQixDQUFsQixFQUFzQyxDQUF0QztBQU10UixNQUFNMkIsWUFBWSxHQUFHO0FBQ25Cd0csYUFBVyxFQUFFMUcsR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDN0JDLFVBQU0sRUFBRU4sR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFEcUI7QUFFN0J5RixVQUFNLEVBQUVqRyxHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYjtBQUZxQixHQUFsQixDQURNO0FBS25CbUcsa0JBQWdCLEVBQUUzRyxHQUFHLENBQUNJLE1BQUosR0FBYUMsSUFBYixDQUFrQjtBQUNsQ3VHLFVBQU0sRUFBRTVHLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRDBCO0FBRWxDUSxXQUFPLEVBQUVoQixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUZ5QjtBQUdsQ2dHLGFBQVMsRUFBRXhHLEdBQUcsQ0FBQzZHLE1BQUosR0FBYXJHLFFBQWI7QUFIdUIsR0FBbEIsQ0FMQztBQVVuQnNHLGtCQUFnQixFQUFFOUcsR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDbEN1RyxVQUFNLEVBQUU1RyxHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQUQwQjtBQUVsQ1EsV0FBTyxFQUFFaEIsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWIsRUFGeUI7QUFHbEMrRixVQUFNLEVBQUV2RyxHQUFHLENBQUNPLE1BQUosR0FBYUksS0FBYixDQUFtQixDQUFDLFdBQUQsRUFBYyxRQUFkLEVBQXdCLFNBQXhCLENBQW5CLEVBQXVESCxRQUF2RDtBQUgwQixHQUFsQixDQVZDO0FBZW5CdUcsY0FBWSxFQUFFL0csR0FBRyxDQUFDSSxNQUFKLEdBQWFDLElBQWIsQ0FBa0I7QUFDOUJ1RyxVQUFNLEVBQUU1RyxHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYixFQURzQjtBQUU5QlEsV0FBTyxFQUFFaEIsR0FBRyxDQUFDTyxNQUFKLEdBQWFDLFFBQWI7QUFGcUIsR0FBbEIsQ0FmSztBQW1CbkJ3RyxlQUFhLEVBQUVoSCxHQUFHLENBQUNPLE1BQUosRUFuQkk7QUFvQm5CMEcsaUJBQWUsRUFBRWpILEdBQUcsQ0FBQ0ksTUFBSixHQUFhQyxJQUFiLENBQWtCO0FBQ2pDQyxVQUFNLEVBQUVOLEdBQUcsQ0FBQ08sTUFBSixHQUFhQyxRQUFiLEVBRHlCO0FBRWpDUSxXQUFPLEVBQUVoQixHQUFHLENBQUNPLE1BQUosR0FBYUMsUUFBYjtBQUZ3QixHQUFsQjtBQXBCRSxDQUFyQjs7QUEwQkEsTUFBTTBHLGVBQWUsR0FBRyxVQUFVN0UsUUFBVixFQUFvQjtBQUMxQyxRQUFNOEUsSUFBSSxHQUFHbEosS0FBSyxDQUFDc0QsT0FBTixDQUFjO0FBQ3pCTixPQUFHLEVBQUVvQixRQUFRLENBQUN1RTtBQURXLEdBQWQsRUFFVjtBQUNEcEYsVUFBTSxFQUFFO0FBQ05sQixZQUFNLEVBQUU7QUFERjtBQURQLEdBRlUsS0FNUFAsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixDQU5YO0FBUUEsUUFBTXVCLElBQUksR0FBR3RELEtBQUssQ0FBQ3VELE9BQU4sQ0FBYztBQUN6Qk4sT0FBRyxFQUFFa0csSUFBSSxDQUFDN0c7QUFEZSxHQUFkLEVBRVY7QUFDRGtCLFVBQU0sRUFBRTtBQUNOUixhQUFPLEVBQUUsQ0FESDtBQUVOdUYsWUFBTSxFQUFFO0FBRkY7QUFEUCxHQUZVLEtBT1B4RyxLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLEVBQTRCO0FBQ3JDd0MsU0FBSyxFQUFFO0FBRDhCLEdBQTVCLENBUFg7QUFXQWpCLE1BQUksQ0FBQ2IsU0FBTCxLQUFtQjRCLFFBQVEsQ0FBQzVCLFNBQTVCLElBQXlDVixLQUFLLENBQUMsR0FBRCxFQUFNLDRDQUFOLEVBQW9EO0FBQ2hHd0MsU0FBSyxFQUFFO0FBRHlGLEdBQXBELENBQTlDO0FBSUEsU0FBT2pCLElBQVA7QUFDRCxDQXpCRDs7QUEyQkE5QyxNQUFNLENBQUMwQyxPQUFQLENBQWU7QUFDYndGLGFBQVcsQ0FBRXJFLFFBQUYsRUFBWTtBQUNyQnZDLG1CQUFlLENBQUM7QUFDZHNCLFVBQUksRUFBRWlCLFFBRFE7QUFFZGhCLFlBQU0sRUFBRW5CLFlBQVksQ0FBQ3dHO0FBRlAsS0FBRCxDQUFmO0FBSUExSSxTQUFLLENBQUMwRCxJQUFOLENBQVc7QUFDVFQsU0FBRyxFQUFFb0IsUUFBUSxDQUFDL0I7QUFETCxLQUFYLEVBRUdzQixLQUZILE1BRWM3QixLQUFLLENBQUMsR0FBRCxFQUFNLG9CQUFOLENBRm5COztBQUlBLFFBQUk5QixLQUFLLENBQUNzRCxPQUFOLENBQWNjLFFBQWQsQ0FBSixFQUE2QjtBQUMzQjtBQUNEOztBQUVEcEUsU0FBSyxDQUFDNkQsTUFBTixDQUFhO0FBQ1h4QixZQUFNLEVBQUUrQixRQUFRLENBQUMvQixNQUROO0FBRVgyRixZQUFNLEVBQUU1RCxRQUFRLENBQUM0RCxNQUZOO0FBR1hRLGVBQVMsRUFBRSxJQUFJekUsSUFBSixFQUhBO0FBSVh1RSxZQUFNLEVBQUUsV0FKRztBQUtYQyxlQUFTLEVBQUU7QUFMQSxLQUFiO0FBT0QsR0FyQlk7O0FBc0JiRyxrQkFBZ0IsQ0FBRXRFLFFBQUYsRUFBWTtBQUMxQnZDLG1CQUFlLENBQUM7QUFDZHNCLFVBQUksRUFBRWlCLFFBRFE7QUFFZGhCLFlBQU0sRUFBRW5CLFlBQVksQ0FBQ3lHO0FBRlAsS0FBRCxDQUFmO0FBSUFPLG1CQUFlLENBQUM3RSxRQUFELENBQWY7QUFFQXBFLFNBQUssQ0FBQ3VFLE1BQU4sQ0FBYUgsUUFBUSxDQUFDdUUsTUFBdEIsRUFBOEI7QUFDNUJuRSxVQUFJLEVBQUU7QUFDSitELGlCQUFTLEVBQUVuRSxRQUFRLENBQUNtRTtBQURoQjtBQURzQixLQUE5QjtBQUtELEdBbENZOztBQW1DYk0sa0JBQWdCLENBQUV6RSxRQUFGLEVBQVk7QUFDMUJ2QyxtQkFBZSxDQUFDO0FBQ2RzQixVQUFJLEVBQUVpQixRQURRO0FBRWRoQixZQUFNLEVBQUVuQixZQUFZLENBQUM0RztBQUZQLEtBQUQsQ0FBZjtBQUlBLFVBQU14RixJQUFJLEdBQUc0RixlQUFlLENBQUM3RSxRQUFELENBQTVCO0FBRUFwRSxTQUFLLENBQUN1RSxNQUFOLENBQWFILFFBQVEsQ0FBQ3VFLE1BQXRCLEVBQThCO0FBQzVCbkUsVUFBSSxFQUFFO0FBQ0o4RCxjQUFNLEVBQUVsRSxRQUFRLENBQUNrRTtBQURiO0FBRHNCLEtBQTlCO0FBS0FyRSxXQUFPLENBQUNDLEdBQVIsQ0FBWWIsSUFBWjs7QUFDQSxRQUFJQSxJQUFJLENBQUNpRixNQUFMLEtBQWdCLFNBQWhCLElBQTZCbEUsUUFBUSxDQUFDa0UsTUFBVCxLQUFvQixTQUFyRCxFQUFnRTtBQUM5RHJFLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLENBQUMsQ0FBYjtBQUNBLGFBQU9uRSxLQUFLLENBQUN3RSxNQUFOLENBQWFsQixJQUFJLENBQUNMLEdBQWxCLEVBQXVCO0FBQzVCbUcsWUFBSSxFQUFFO0FBQ0puSixlQUFLLEVBQUU7QUFESDtBQURzQixPQUF2QixDQUFQO0FBS0Q7O0FBQ0QsUUFBSXFELElBQUksQ0FBQ2lGLE1BQUwsS0FBZ0IsU0FBaEIsSUFBNkJsRSxRQUFRLENBQUNrRSxNQUFULEtBQW9CLFNBQXJELEVBQWdFO0FBQzlEckUsYUFBTyxDQUFDQyxHQUFSLENBQVksQ0FBQyxDQUFiO0FBQ0EsYUFBT25FLEtBQUssQ0FBQ3dFLE1BQU4sQ0FBYWxCLElBQUksQ0FBQ0wsR0FBbEIsRUFBdUI7QUFDNUJtRyxZQUFJLEVBQUU7QUFDSm5KLGVBQUssRUFBRSxDQUFDO0FBREo7QUFEc0IsT0FBdkIsQ0FBUDtBQUtEO0FBQ0YsR0FoRVk7O0FBaUViOEksY0FBWSxDQUFFMUUsUUFBRixFQUFZO0FBQ3RCdkMsbUJBQWUsQ0FBQztBQUNkc0IsVUFBSSxFQUFFaUIsUUFEUTtBQUVkaEIsWUFBTSxFQUFFbkIsWUFBWSxDQUFDNkcsWUFGUDtBQUdkekUsV0FBSyxFQUFFO0FBQ0xDLGFBQUssRUFBRTtBQURGO0FBSE8sS0FBRCxDQUFmO0FBUUEyRSxtQkFBZSxDQUFDN0UsUUFBRCxDQUFmO0FBRUFwRSxTQUFLLENBQUNvSixNQUFOLENBQWFoRixRQUFRLENBQUN1RSxNQUF0QjtBQUNEOztBQTdFWSxDQUFmO0FBZ0ZBcEksTUFBTSxDQUFDa0UsT0FBUCxDQUFlLGVBQWYsRUFBZ0MsVUFBVXBDLE1BQVYsRUFBa0I7QUFDaERSLGlCQUFlLENBQUM7QUFDZHNCLFFBQUksRUFBRWQsTUFEUTtBQUVkZSxVQUFNLEVBQUVuQixZQUFZLENBQUM4RztBQUZQLEdBQUQsQ0FBZjtBQUtBLFNBQU8vSSxLQUFLLENBQUN5RCxJQUFOLENBQVc7QUFDaEJwQixVQURnQjtBQUVoQmlHLFVBQU0sRUFBRTtBQUZRLEdBQVgsQ0FBUDtBQUlELENBVkQ7QUFXQS9ILE1BQU0sQ0FBQ2tFLE9BQVAsQ0FBZSxpQkFBZixFQUFrQyxVQUFVTCxRQUFWLEVBQW9CO0FBQ3BEdkMsaUJBQWUsQ0FBQztBQUNkc0IsUUFBSSxFQUFFaUIsUUFEUTtBQUVkaEIsVUFBTSxFQUFFbkIsWUFBWSxDQUFDK0c7QUFGUCxHQUFELENBQWY7QUFJQSxRQUFNM0YsSUFBSSxHQUFHdEQsS0FBSyxDQUFDdUQsT0FBTixDQUFjO0FBQ3pCVixPQUFHLEVBQUV3QixRQUFRLENBQUN4QjtBQURXLEdBQWQsS0FFUGQsS0FBSyxDQUFDLEdBQUQsRUFBTSxvQkFBTixDQUZYO0FBSUF1QixNQUFJLENBQUNOLE9BQUwsS0FBaUJxQixRQUFRLENBQUNyQixPQUExQixJQUFxQ2pCLEtBQUssQ0FBQyxHQUFELEVBQU0sbUNBQU4sQ0FBMUM7QUFFQSxTQUFPOUIsS0FBSyxDQUFDeUQsSUFBTixDQUFXO0FBQ2hCcEIsVUFBTSxFQUFFK0IsUUFBUSxDQUFDL0IsTUFERDtBQUVoQmlHLFVBQU0sRUFBRTtBQUNOZSxTQUFHLEVBQUU7QUFEQztBQUZRLEdBQVgsQ0FBUDtBQU1ELENBakJELEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJ1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcblxuZXhwb3J0IGNvbnN0IGNsaXBzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NsaXBzJylcbmV4cG9ydCBjb25zdCBwb3N0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdwb3N0cycpXG5leHBvcnQgY29uc3QgbGlua3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbGlua3MnKVxuXG5leHBvcnQgdmFyIGxvY2FsTGlua3NcbmV4cG9ydCB2YXIgZmF2b3JpdG9zXG5cbmlmIChNZXRlb3IuaXNDbGllbnQpIHtcbiAgZmF2b3JpdG9zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24obnVsbClcbiAgLyogZXNsaW50LWRpc2FibGUtbmV4dC1saW5lICovXG4gIG5ldyBQZXJzaXN0ZW50TWluaW1vbmdvMihmYXZvcml0b3MsICdmYXZvcml0b3MnKVxuXG4gIGxvY2FsTGlua3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihudWxsKVxuICAvKiBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgKi9cbiAgbmV3IFBlcnNpc3RlbnRNaW5pbW9uZ28yKGxvY2FsTGlua3MsICdsb2NhbExpbmtzJylcbn1cblxuaWYgKE1ldGVvci5pc0RldmVsb3BtZW50KSB7XG4gIGdsb2JhbC5mYXZvcml0b3MgPSBmYXZvcml0b3NcbiAgZ2xvYmFsLmNsaXBzID0gY2xpcHNcbiAgZ2xvYmFsLnBvc3RzID0gcG9zdHNcbiAgZ2xvYmFsLmxpbmtzID0gbGlua3NcbiAgZ2xvYmFsLmxvY2FsTGlua3MgPSBsb2NhbExpbmtzXG59XG4iLCJcblxuZXhwb3J0IGNvbnN0IHRyYWR1Y2Npb25lcyA9IHtcbiAgXCJBY2VwdGFyXCI6IHtcbiAgICBcImVuXCI6IFwiQWNjZXB0XCIsXG4gICAgXCJlc1wiOiBcIkFjZXB0YXJcIlxuICB9LFxuICBcIkFncmVnYSBlbmxhY2VzIGFsIGNsaXAuXCI6IHtcbiAgICBcImVuXCI6IFwiQWRkIGxpbmtzIHRvIGNsaXAuXCIsXG4gICAgXCJlc1wiOiBcIkFncmVnYSBlbmxhY2VzIGFsIGNsaXAuXCJcbiAgfSxcbiAgXCJBZ3JlZ2FyXCI6IHtcbiAgICBcImVuXCI6IFwiQWRkXCIsXG4gICAgXCJlc1wiOiBcIkFncmVnYXJcIlxuICB9LFxuICBcIkFncmVnYXIgZW5sYWNlXCI6IHtcbiAgICBcImVuXCI6IFwiQWRkIGxpbmtcIixcbiAgICBcImVzXCI6IFwiQWdyZWdhciBlbmxhY2VcIlxuICB9LFxuICBcIkFwcm9iYXJcIjoge1xuICAgIFwiZW5cIjogXCJBcHByb3ZlXCIsXG4gICAgXCJlc1wiOiBcIkFwcm9iYXJcIlxuICB9LFxuICBcIkF0csOhc1wiOiB7XG4gICAgXCJlblwiOiBcIkJhY2tcIixcbiAgICBcImVzXCI6IFwiQXRyw6FzXCJcbiAgfSxcbiAgXCJCdXNjYXIgY2xpcFwiOiB7XG4gICAgXCJlblwiOiBcIlNlYXJjaCBjbGlwXCIsXG4gICAgXCJlc1wiOiBcIkJ1c2NhciBjbGlwXCJcbiAgfSxcbiAgXCJCdXNxdWVkYTpcIjoge1xuICAgIFwiZW5cIjogXCJTZWFyY2hcIixcbiAgICBcImVzXCI6IFwiQnVzcXVlZGE6XCJcbiAgfSxcbiAgXCJDYW5jZWxhclwiOiB7XG4gICAgXCJlblwiOiBcIkNhbmNlbFwiLFxuICAgIFwiZXNcIjogXCJDYW5jZWxhclwiXG4gIH0sXG4gIFwiQ2xpcCB2YWPDrW9cIjoge1xuICAgIFwiZW5cIjogXCJFbXB0eSBjbGlwXCIsXG4gICAgXCJlc1wiOiBcIkNsaXAgdmFjw61vXCJcbiAgfSxcbiAgXCJDb21wYXJ0aXJcIjoge1xuICAgIFwiZW5cIjogXCJTaGFyZVwiLFxuICAgIFwiZXNcIjogXCJDb21wYXJ0aXJcIlxuICB9LFxuICBcIkNvbiBlc3RhIGxsYXZlIHNlIHB1ZWRlIGFkbWluaXN0cmFyIGVsIGNsaXBcIjoge1xuICAgIFwiZW5cIjogXCJUaGlzIGtleSBhbGxvd3MgdG8gYWRtaW4gdGhlIGNsaXBcIixcbiAgICBcImVzXCI6IFwiQ29uIGVzdGEgbGxhdmUgc2UgcHVlZGUgYWRtaW5pc3RyYXIgZWwgY2xpcFwiXG4gIH0sXG4gIFwiQ29uIGVzdGEgbGxhdmUgc2UgcHVlZGVuIHJldm9jYXIgbGFzIGxsYXZlcyBkZSBhZG1pbmlzdHJhY2nDs24geSBzZWd1cmlkYWQuXCI6IHtcbiAgICBcImVuXCI6IFwiVGhpcyBrZXkgYWxsb3dzIHRvIHJldm9rZSB0aGUga2V5c1wiLFxuICAgIFwiZXNcIjogXCJDb24gZXN0YSBsbGF2ZSBzZSBwdWVkZW4gcmV2b2NhciBsYXMgbGxhdmVzIGRlIGFkbWluaXN0cmFjacOzbiB5IHNlZ3VyaWRhZC5cIlxuICB9LFxuICBcIkNyZWFyXCI6IHtcbiAgICBcImVuXCI6IFwiQ3JlYXRlXCIsXG4gICAgXCJlc1wiOiBcIkNyZWFyXCJcbiAgfSxcbiAgXCJDcmVhciBjbGlwXCI6IHtcbiAgICBcImVuXCI6IFwiQ3JlYXRlIGNsaXBcIixcbiAgICBcImVzXCI6IFwiQ3JlYXIgY2xpcFwiXG4gIH0sXG4gIFwiRWxpbWluYXJcIjoge1xuICAgIFwiZW5cIjogXCJSZW1vdmVcIixcbiAgICBcImVzXCI6IFwiRWxpbWluYXJcIlxuICB9LFxuICBcIkVzY3JpYmUgdW4gdMOtdHVsbyBwYXJhIGVsIGNsaXBcIjoge1xuICAgIFwiZW5cIjogXCJFbnRlciBhIHRpdGxlIGZvciB0aGUgY2xpcFwiLFxuICAgIFwiZXNcIjogXCJFc2NyaWJlIHVuIHTDrXR1bG8gcGFyYSBlbCBjbGlwXCJcbiAgfSxcbiAgXCJGYXZvcml0b3NcIjoge1xuICAgIFwiZW5cIjogXCJGYXZvcml0ZXNcIixcbiAgICBcImVzXCI6IFwiRmF2b3JpdG9zXCJcbiAgfSxcbiAgXCJIZWNob1wiOiB7XG4gICAgXCJlblwiOiBcIkRvbmVcIixcbiAgICBcImVzXCI6IFwiSGVjaG9cIlxuICB9LFxuICBcIklkaW9tYVwiOiB7XG4gICAgXCJlblwiOiBcIkxhbmd1YWdlXCIsXG4gICAgXCJlc1wiOiBcIklkaW9tYVwiXG4gIH0sXG4gIFwiTGxhdmUgZGUgYWRtaW5pc3RyYWNpw7NuXCI6IHtcbiAgICBcImVuXCI6IFwiQWRtaW4ga2V5XCIsXG4gICAgXCJlc1wiOiBcIkxsYXZlIGRlIGFkbWluaXN0cmFjacOzblwiXG4gIH0sXG4gIFwiTGxhdmUgZGUgc2VndXJpZGFkXCI6IHtcbiAgICBcImVuXCI6IFwiU2FmZSBrZXlcIixcbiAgICBcImVzXCI6IFwiTGxhdmUgZGUgc2VndXJpZGFkXCJcbiAgfSxcbiAgXCJMbGF2ZXNcIjoge1xuICAgIFwiZW5cIjogXCJLZXlzXCIsXG4gICAgXCJlc1wiOiBcIkxsYXZlc1wiXG4gIH0sXG4gIFwiTG9zIGVubGFjZXMgc2Ugb3JkZW5hbiBwb3Igc3UgcHJpb3JpZGFkLCBkZSBtYXlvciBhIG1lbm9yLCB5IHBvciBsYSBmZWNoYSBlbiBsYSBxdWUgaGFuIHNpZG8gYWdyZWdhZG9zLlwiOiB7XG4gICAgXCJlblwiOiBcIlRoZSBsaW5rcyBhcmUgb3JkZXJlZCBieSB0aGVpciBwcmlvcml0eSBhbmQgdGhlbiBieSB0aGUgYWRkaXRpb24gZGF0ZVwiLFxuICAgIFwiZXNcIjogXCJMb3MgZW5sYWNlcyBzZSBvcmRlbmFuIHBvciBzdSBwcmlvcmlkYWQsIGRlIG1heW9yIGEgbWVub3IsIHkgcG9yIGxhIGZlY2hhIGVuIGxhIHF1ZSBoYW4gc2lkbyBhZ3JlZ2Fkb3MuXCJcbiAgfSxcbiAgXCJNb3N0cmFyXCI6IHtcbiAgICBcImVuXCI6IFwiU2hvd1wiLFxuICAgIFwiZXNcIjogXCJNb3N0cmFyXCJcbiAgfSxcbiAgXCJPY3VsdGFyXCI6IHtcbiAgICBcImVuXCI6IFwiSGlkZVwiLFxuICAgIFwiZXNcIjogXCJPY3VsdGFyXCJcbiAgfSxcbiAgXCJPbHZpZGFyXCI6IHtcbiAgICBcImVuXCI6IFwiRm9yZ2V0XCIsXG4gICAgXCJlc1wiOiBcIk9sdmlkYXJcIlxuICB9LFxuICBcIm9yZ2FuaXphIGxhc1wiOiB7XG4gICAgXCJlblwiOiBcIm9yZ2FuaXplIHRoZVwiLFxuICAgIFwiZXNcIjogXCJvcmdhbml6YSBsYXNcIlxuICB9LFxuICBcIlByaW9yaWRhZFwiOiB7XG4gICAgXCJlblwiOiBcIlByaW9yaXR5XCIsXG4gICAgXCJlc1wiOiBcIlByaW9yaWRhZFwiXG4gIH0sXG4gIFwiUmFua2luZ1wiOiB7XG4gICAgXCJlblwiOiBcIlJhbmtpbmdcIixcbiAgICBcImVzXCI6IFwiUmFua2luZ1wiXG4gIH0sXG4gIFwiUmVjaGF6YXJcIjoge1xuICAgIFwiZW5cIjogXCJSZWZ1c2VcIixcbiAgICBcImVzXCI6IFwiUmVjaGF6YXJcIlxuICB9LFxuICBcIlJlY29yZGFyXCI6IHtcbiAgICBcImVuXCI6IFwiUmVtZW1iZXJcIixcbiAgICBcImVzXCI6IFwiUmVjb3JkYXJcIlxuICB9LFxuICBcIlNpZ3VpZW50ZVwiOiB7XG4gICAgXCJlblwiOiBcIk5leHRcIixcbiAgICBcImVzXCI6IFwiU2lndWllbnRlXCJcbiAgfSxcbiAgXCJUaWVuZXMgcXVlIGluZGljYXIgdW4gdMOtdHVsbyBwYXJhIHBvZGVyIGNvbnRpbnVhclwiOiB7XG4gICAgXCJlblwiOiBcIllvdSBuZWVkIHRvIGFkZCBhIHRpdGxlIHRvIGNvbnRpbnVlXCIsXG4gICAgXCJlc1wiOiBcIlRpZW5lcyBxdWUgaW5kaWNhciB1biB0w610dWxvIHBhcmEgcG9kZXIgY29udGludWFyXCJcbiAgfSxcbiAgXCJUaXR1bG9cIjoge1xuICAgIFwiZW5cIjogXCJUaXRsZVwiLFxuICAgIFwiZXNcIjogXCJUaXR1bG9cIlxuICB9LFxuICBcIlVuYSB2ZXogY3JlYWRvIGVsIGNsaXAsIG5vIHNlIHBvZHLDoSBtb2RpZmljYXIgc3UgdMOtdHVsbyBuaSBzdSB1cmwuXCI6IHtcbiAgICBcImVuXCI6IFwiQWZ0ZXIgY3JlYXRlZCwgdGhlIHRpdGxlIGNhbm5vdCBiZSBhbHRlcmVkXCIsXG4gICAgXCJlc1wiOiBcIlVuYSB2ZXogY3JlYWRvIGVsIGNsaXAsIG5vIHNlIHBvZHLDoSBtb2RpZmljYXIgc3UgdMOtdHVsbyBuaSBzdSB1cmwuXCJcbiAgfSxcbiAgXCJWZXIgY2xpcFwiOiB7XG4gICAgXCJlblwiOiBcIlZpZXcgY2xpcFwiLFxuICAgIFwiZXNcIjogXCJWZXIgY2xpcFwiXG4gIH0sXG4gIFwiWWEgaGF5IHVuIGNsaXAgY29uIGVzYSB1cmxcIjoge1xuICAgIFwiZW5cIjogXCJBIGNsaXAgZXhpc3RzIHdpdGggdGhpcyB1cmxcIixcbiAgICBcImVzXCI6IFwiWWEgaGF5IHVuIGNsaXAgY29uIGVzYSB1cmxcIlxuICB9LFxuICBcIllhIGhheSB1biBjbGlwIGNvbiBlc2UgdMOtdHVsb1wiOiB7XG4gICAgXCJlblwiOiBcIkEgY2xpcCBleGlzdHMgd2l0aCB0aGlzIHRpdGxlXCIsXG4gICAgXCJlc1wiOiBcIllhIGhheSB1biBjbGlwIGNvbiBlc2UgdMOtdHVsb1wiXG4gIH0sXG4gIFwicmVkZXNcIjoge1xuICAgIFwiZW5cIjogXCJuZXR3b3Jrc1wiLFxuICAgIFwiZXNcIjogXCJyZWRlc1wiXG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IGlkaW9tYXMgPSB7XG4gIFwiZW5cIjogMSxcbiAgXCJlc1wiOiAxXG59XG5cbiIsImNvbnN0IGRpYWNyaXRpY2FzID0ge1xuICDDoTogJ2EnLFxuICDDqTogJ2UnLFxuICDDrTogJ2knLFxuICDDszogJ28nLFxuICDDujogJ3UnLFxuICDDsTogJ24nLFxuICDDpzogJ2MnXG59XG5cbmV4cG9ydCBjb25zdCB0aXR1bG9BVXJsID0gZnVuY3Rpb24gdGl0dWxvQVVybCAodGl0dWxvKSB7XG4gIHJldHVybiAodGl0dWxvIHx8ICcnKS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1sgXS9nLCAnLScpLnJlcGxhY2UoL1vDocOpw63DusOzw7zDsV0vZywgZnVuY3Rpb24gKGxldHJhKSB7XG4gICAgcmV0dXJuIGRpYWNyaXRpY2FzW2xldHJhXVxuICB9KS5yZXBsYWNlKC9bXmEtejAtOSBfLi1dL2csICcnKVxufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJhbmRvbSB9IGZyb20gJ21ldGVvci9yYW5kb20nXG5pbXBvcnQgeyBjbGlwcyB9IGZyb20gJy9jb21tb24vYmFzZURlRGF0b3MnXG5pbXBvcnQgeyBzYWxpclZhbGlkYWNpb24sIHNhbGlyIH0gZnJvbSAnL3NlcnZlci9jb211bidcbmltcG9ydCB7IHRpdHVsb0FVcmwgfSBmcm9tICcvY29tbW9uL3ZhcmlvcydcblxuaW1wb3J0IEpvaSBmcm9tICdqb2knXG5cbmNvbnN0IHZhbGlkYWNpb25lcyA9IHtcbiAgcmV2b2NhcjogSm9pLm9iamVjdCgpLmtleXMoe1xuICAgIGNsaXBJZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgc2VndXJpZGFkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBsbGF2ZTogSm9pLnN0cmluZygpLnZhbGlkKFsnc2VndXJpZGFkJywgJ3NlY3JldG8nXSkucmVxdWlyZWQoKVxuICB9KSxcbiAgb2J0ZW5lclNlY3JldG86IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICBjbGlwSWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlZ3VyaWRhZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKClcbiAgfSksXG4gIHVybDogSm9pLnN0cmluZygpLnJlZ2V4KC9eW2Etei1dKyQvKS5yZXF1aXJlZCgpLFxuICBjbGlwSWRQdWJsaXNoOiBKb2kub2JqZWN0KCkua2V5cyh7XG4gICAgY2xpcElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBzZWNyZXRvOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKVxuICB9KSxcbiAgdGl0dWxvOiBKb2kuc3RyaW5nKCksXG4gIF9pZDogSm9pLnN0cmluZygpXG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgY2xpcElkVG9VcmwgKF9pZCkge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiBfaWQsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5faWRcbiAgICB9KVxuICAgIGNvbnN0IGNsaXAgPSBjbGlwcy5maW5kT25lKF9pZCwge1xuICAgICAgZmllbGRzOiB7XG4gICAgICAgIHVybDogMVxuICAgICAgfVxuICAgIH0pIHx8IHNhbGlyKDQwNCwgJ0NsaXAgbm8gZW5jb250cmFkbycpXG4gICAgcmV0dXJuIGNsaXAudXJsXG4gIH0sXG4gIGNyZWFyQ2xpcCAodGl0dWxvKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IHRpdHVsbyxcbiAgICAgIHNjaGVtYTogdmFsaWRhY2lvbmVzLnRpdHVsb1xuICAgIH0pXG5cbiAgICBjb25zdCB1cmwgPSB0aXR1bG9BVXJsKHRpdHVsbylcbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIHVybFxuICAgIH0sIHtcbiAgICAgIGxpbWl0OiAxXG4gICAgfSkuY291bnQoKSAmJiBzYWxpcig0MDAsICd1cmwgcmVwZXRpZGEnKVxuXG4gICAgY29uc3Qgc2VjcmV0byA9IFJhbmRvbS5zZWNyZXQoKVxuICAgIGNvbnN0IHNlZ3VyaWRhZCA9IFJhbmRvbS5zZWNyZXQoKVxuICAgIGNvbnN0IGNsaXBJZCA9IGNsaXBzLmluc2VydCh7XG4gICAgICBhY3R1YWxpemFjaW9uOiBuZXcgRGF0ZSgpLFxuICAgICAgdGl0dWxvLFxuICAgICAgdXJsLFxuICAgICAgc2VjcmV0byxcbiAgICAgIHNlZ3VyaWRhZCxcbiAgICAgIHBvc3RzOiAwXG4gICAgfSlcblxuICAgIHJldHVybiB7XG4gICAgICBjbGlwSWQsXG4gICAgICBzZWNyZXRvLFxuICAgICAgc2VndXJpZGFkXG4gICAgfVxuICB9LFxuICB0ZXN0VGl0dWxvICh0aXR1bG8pIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogdGl0dWxvLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMudGl0dWxvXG4gICAgfSlcbiAgICBpZiAoY2xpcHMuZmluZCh7XG4gICAgICB0aXR1bG9cbiAgICB9LCB7XG4gICAgICBsaW1pdDogMVxuICAgIH0pLmNvdW50KCkpIHtcbiAgICAgIGNvbnNvbGUubG9nKCd0aXR1bG8gcmVwZXRpZG8nKVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsICd0aXR1bG8gcmVwZXRpZG8nKVxuICAgIH1cbiAgICBjb25zdCB1cmwgPSB0aXR1bG9BVXJsKHRpdHVsbylcbiAgICBpZiAoY2xpcHMuZmluZCh7XG4gICAgICB1cmxcbiAgICB9LCB7XG4gICAgICBsaW1pdDogMVxuICAgIH0pLmNvdW50KCkpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAwLCAndXJsIHJlcGV0aWRhJylcbiAgICB9XG4gIH0sXG4gIHJldm9jYXIgKG9wY2lvbmVzKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMucmV2b2NhcixcbiAgICAgIGRlYnVnOiB7XG4gICAgICAgIGRvbmRlOiAnbWV0aG9kIHJldm9jYXInXG4gICAgICB9XG4gICAgfSlcblxuICAgIGNsaXBzLmZpbmQoe1xuICAgICAgX2lkOiBvcGNpb25lcy5jbGlwSWRcbiAgICB9KS5jb3VudCgpIHx8IHNhbGlyKDQwNCwgJ0NsaXAgbm8gZW5jb250cmFkbycpXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkLFxuICAgICAgc2VndXJpZGFkOiBvcGNpb25lcy5zZWd1cmlkYWRcbiAgICB9KS5jb3VudCgpIHx8IHNhbGlyKDQwMCwgJ05vIHRpZW5lcyBwZXJtaXNvIHBhcmEgcmV2b2NhciBsbGF2ZXMnKVxuXG4gICAgY29uc3QgbGxhdmUgPSBSYW5kb20uc2VjcmV0KClcblxuICAgIGNsaXBzLnVwZGF0ZShvcGNpb25lcy5jbGlwSWQsIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgW29wY2lvbmVzLmxsYXZlXTogbGxhdmVcbiAgICAgIH1cbiAgICB9KVxuICAgIHJldHVybiBsbGF2ZVxuICB9LFxuICBvYnRlbmVyU2VjcmV0byAob3BjaW9uZXMpIHtcbiAgICBzYWxpclZhbGlkYWNpb24oe1xuICAgICAgZGF0YTogb3BjaW9uZXMsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5vYnRlbmVyU2VjcmV0b1xuICAgIH0pXG5cbiAgICBjbGlwcy5maW5kKHtcbiAgICAgIF9pZDogb3BjaW9uZXMuY2xpcElkXG4gICAgfSkuY291bnQoKSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nKVxuXG4gICAgY29uc3QgY2xpcCA9IGNsaXBzLmZpbmRPbmUoe1xuICAgICAgX2lkOiBvcGNpb25lcy5jbGlwSWQsXG4gICAgICBzZWd1cmlkYWQ6IG9wY2lvbmVzLnNlZ3VyaWRhZFxuICAgIH0pIHx8IHNhbGlyKDQwMSwgJ05vIHRpZW5lcyBwZXJtaXNvIHBhcmEgb2J0ZW5lciBsYSBsbGF2ZSBkZSBhZG1pbmlzdHJhY2nDs24nKVxuXG4gICAgcmV0dXJuIGNsaXAuc2VjcmV0b1xuICB9XG59KVxuXG5NZXRlb3IucHVibGlzaCgnY2xpcFVybCcsIGZ1bmN0aW9uICh1cmwpIHtcbiAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICBkYXRhOiB1cmwsXG4gICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMudXJsXG4gIH0pXG5cbiAgcmV0dXJuIGNsaXBzLmZpbmQoe1xuICAgIHVybFxuICB9LCB7XG4gICAgZmllbGRzOiB7XG4gICAgICBzZWd1cmlkYWQ6IDAsXG4gICAgICBzZWNyZXRvOiAwXG4gICAgfVxuICB9KVxufSlcbk1ldGVvci5wdWJsaXNoKCdjbGlwSWQnLCBmdW5jdGlvbiAoX2lkKSB7XG4gIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgZGF0YTogX2lkLFxuICAgIHNjaGVtYTogdmFsaWRhY2lvbmVzLl9pZFxuICB9KVxuXG4gIHJldHVybiBjbGlwcy5maW5kKHtcbiAgICBfaWRcbiAgfSwge1xuICAgIGZpZWxkczoge1xuICAgICAgc2VndXJpZGFkOiAwLFxuICAgICAgc2VjcmV0bzogMFxuICAgIH1cbiAgfSlcbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IEpvaSBmcm9tICdqb2knXG5cbmV4cG9ydCBjb25zdCBzYWxpciA9IGZ1bmN0aW9uIHNhbGlyIChjb2RpZ28sIG1lbnNhamUsIGRlYnVnKSB7XG4gIGlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCkge1xuICAgIGNvbnNvbGUubG9nKGNvZGlnbywgbWVuc2FqZSlcbiAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IoKVxuICAgIGNvbnNvbGUubG9nKGVyci5zdGFjaylcbiAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShkZWJ1ZywgbnVsbCwgMikpXG4gIH1cbiAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihjb2RpZ28sIG1lbnNhamUpXG59XG5cbmV4cG9ydCBjb25zdCBzYWxpclZhbGlkYWNpb24gPSBmdW5jdGlvbiAob3BjaW9uZXMpIHtcbiAgY29uc3QgdmFsaWRhY2lvbiA9IEpvaS52YWxpZGF0ZShvcGNpb25lcy5kYXRhLCBvcGNpb25lcy5zY2hlbWEpXG4gIGlmICghdmFsaWRhY2lvbi5lcnJvcikge1xuICAgIHJldHVyblxuICB9XG4gIG9wY2lvbmVzID0gT2JqZWN0LmFzc2lnbih7XG4gICAgY29kaWdvOiA0MDAsXG4gICAgbWVuc2FqZTogdmFsaWRhY2lvbi5lcnJvci5kZXRhaWxzWzBdLm1lc3NhZ2VcbiAgfSwgb3BjaW9uZXMpXG4gIGlmIChvcGNpb25lcy5kZWJ1Zykge1xuICAgIG9wY2lvbmVzLmRlYnVnLmRldGFpbHMgPSB2YWxpZGFjaW9uLmVycm9yLmRldGFpbHNcbiAgICBvcGNpb25lcy5kZWJ1Zy5fb2JqZWN0ID0gdmFsaWRhY2lvbi5lcnJvci5fb2JqZWN0XG4gIH1cbiAgc2FsaXIob3BjaW9uZXMuY29kaWdvLCBvcGNpb25lcy5tZW5zYWplLCBvcGNpb25lcy5kZWJ1Zylcbn1cbiIsImltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCdcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBsaW5rcyB9IGZyb20gJy9jb21tb24vYmFzZURlRGF0b3MnXG5pbXBvcnQgeyBzYWxpclZhbGlkYWNpb24gfSBmcm9tICcvc2VydmVyL2NvbXVuJ1xuXG5pbXBvcnQgb2dzIGZyb20gJ29wZW4tZ3JhcGgtc2NyYXBlcidcbmltcG9ydCBKb2kgZnJvbSAnam9pJ1xuXG5jb25zdCB2YWxpZGFjaW9uZXMgPSB7XG4gIHN0cmluZzogSm9pLnN0cmluZygpXG59XG5cbmNvbnN0IG1ldGVvck9HUyA9IE1ldGVvci53cmFwQXN5bmMoZnVuY3Rpb24gKG9wY2lvbmVzLCBjYWxsYmFjaykge1xuICBvZ3Mob3BjaW9uZXMsIGZ1bmN0aW9uIChlLCByKSB7XG4gICAgaWYgKGUpIHtcbiAgICAgIHJldHVybiBjYWxsYmFjayhudWxsLCBbXSlcbiAgICB9XG4gICAgY2FsbGJhY2sobnVsbCwgcilcbiAgfSlcbn0pXG5cbmNvbnN0IHJyc3MgPSB7XG4gIEluc3RhZ3JhbSAocmVzcG9uc2UpIHtcbiAgICByZXNwb25zZS5kZXNjcmlwdGlvbiA9IHJlc3BvbnNlLnRpdGxlLnJlcGxhY2UoL14uKj9vbiBJbnN0YWdyYW06IC8sICcnKVxuICAgIHJlc3BvbnNlLnRpdGxlID0gcmVzcG9uc2UudGl0bGUucmVwbGFjZSgvb24gSW5zdGFncmFtOi4qJC8sICcnKVxuICAgIHJldHVybiByZXNwb25zZVxuICB9LFxuICBUd2l0dGVyIChyZXNwb25zZSkge1xuICAgIHJlc3BvbnNlLnRpdGxlID0gcmVzcG9uc2UudGl0bGUucmVwbGFjZSgvb24gVHdpdHRlciQvLCAnJylcbiAgICByZXR1cm4gcmVzcG9uc2VcbiAgfSxcbiAgcmVkZGl0IChyZXNwb25zZSkge1xuICAgIHJlc3BvbnNlLmRlc2NyaXB0aW9uID0gcmVzcG9uc2UudGl0bGUucmVwbGFjZSgvXi4qPy0gLywgJycpXG4gICAgcmVzcG9uc2UudGl0bGUgPSByZXNwb25zZS50aXRsZS5yZXBsYWNlKC8gLSAuKiQvLCAnJylcbiAgICByZXR1cm4gcmVzcG9uc2VcbiAgfVxufVxuXG5jb25zdCBzaXRlTmFtZUZyb21VcmwgPSBmdW5jdGlvbiBzaXRlTmFtZUZyb21VcmwgKHVybCkge1xuICB1cmwgPSB1cmwubWF0Y2goc2l0ZU5hbWVGcm9tVXJsLnJlZ2V4KVxuICByZXR1cm4gdXJsWzJdXG59XG5zaXRlTmFtZUZyb21VcmwucmVnZXggPSAvXmh0dHAoPzpzPyk6XFwvXFwvKFswLTlhLXotXSpcXC4pPyhbMC05YS16LV0rXFwuWzAtOWEtei1dKykoPzpcXC98JCkvXG5jb25zdCBhY3R1YWxpemFyID0gZnVuY3Rpb24gYWN0dWFsaXphciAodXJsKSB7XG4gIHZhciByZXNwb25zZVxuICB2YXIgb3BjaW9uZXNcblxuICBpZiAodXJsLm1hdGNoKC9odHRwczpcXC9cXC93d3cuZmFjZWJvb2svKSkge1xuICAgIG9wY2lvbmVzID0ge1xuICAgICAgaHRtbDogSFRUUC5nZXQodXJsLCB7XG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAnVXNlci1BZ2VudCc6ICdGZWVkRmV0Y2hlci1Hb29nbGU7ICgraHR0cDovL3d3dy5nb29nbGUuY29tL2ZlZWRmZXRjaGVyLmh0bWwpJ1xuICAgICAgICB9XG4gICAgICB9KS5jb250ZW50XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIG9wY2lvbmVzID0ge1xuICAgICAgdXJsXG4gICAgfVxuICB9XG5cbiAgcmVzcG9uc2UgPSBtZXRlb3JPR1Mob3BjaW9uZXMpXG5cbiAgaWYgKCFyZXNwb25zZSkge1xuICAgIHJldHVyblxuICB9XG5cbiAgaWYgKHVybC5tYXRjaCgvaHR0cHM6XFwvXFwvd3d3LmZhY2Vib29rLykpIHtcbiAgICByZXNwb25zZS5kYXRhLm9nU2l0ZU5hbWUgPSAnRmFjZWJvb2snXG4gIH1cblxuICBpZiAocmVzcG9uc2UuZGF0YS5vZ1VybCkge1xuICAgIHVybCA9IEFycmF5LmZyb20obmV3IFNldChbcmVzcG9uc2UuZGF0YS5vZ1VybCwgdXJsXSkpXG4gIH0gZWxzZSB7XG4gICAgdXJsID0gW3VybF1cbiAgfVxuXG4gIHJlc3BvbnNlID0ge1xuICAgIGRlc2NyaXB0aW9uOiByZXNwb25zZS5kYXRhLm9nRGVzY3JpcHRpb24sXG4gICAgdGl0bGU6IHJlc3BvbnNlLmRhdGEub2dUaXRsZSxcbiAgICBpbWFnZTogKHJlc3BvbnNlLmRhdGEub2dJbWFnZSB8fCB7fSkudXJsLFxuICAgIHR5cGU6IHJlc3BvbnNlLmRhdGEub2dUeXBlLFxuICAgIHVybDogdXJsLFxuICAgIHNpdGVOYW1lOiByZXNwb25zZS5kYXRhLm9nU2l0ZU5hbWUgfHwgcmVzcG9uc2UuZGF0YS50d2l0dGVyU2l0ZSB8fCBzaXRlTmFtZUZyb21VcmwodXJsWzBdKVxuICB9XG5cbiAgaWYgKHJyc3NbcmVzcG9uc2Uuc2l0ZU5hbWVdKSB7XG4gICAgcmV0dXJuIHJyc3NbcmVzcG9uc2Uuc2l0ZU5hbWVdKHJlc3BvbnNlKVxuICB9XG4gIHJldHVybiByZXNwb25zZVxufVxuXG5jb25zdCBpbnNlcnRhciA9IGZ1bmN0aW9uIGluc2VydGFyIChsaW5rKSB7XG4gIGNvbnNvbGUubG9nKCdpbnNlcnRhcicpXG4gIGNvbnN0IGwgPSBsaW5rcy5maW5kT25lKHtcbiAgICB1cmw6IHtcbiAgICAgICRpbjogbGluay51cmxcbiAgICB9XG4gIH0pXG5cbiAgaWYgKGwpIHtcbiAgICBsaW5rcy51cGRhdGUobC5faWQsIHtcbiAgICAgICRhZGRUb1NldDoge1xuICAgICAgICB1cmw6IHtcbiAgICAgICAgICAkZWFjaDogbGluay51cmxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG4gICAgcmV0dXJuIGxcbiAgfVxuICBsaW5rLmFjdHVhbGl6YWRvID0gbmV3IERhdGUoKVxuICBsaW5rLl9pZCA9IGxpbmtzLmluc2VydChsaW5rKVxuICByZXR1cm4gbGlua1xufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gIGxpbmsgKHVybCkge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiB1cmwsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5zdHJpbmdcbiAgICB9KVxuXG4gICAgcmV0dXJuIGxpbmtzLmZpbmRPbmUoe1xuICAgICAgdXJsXG4gICAgfSkgfHwgaW5zZXJ0YXIoYWN0dWFsaXphcih1cmwpKVxuICB9LFxuICBsaW5rSWQgKF9pZCkge1xuICAgIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgICBkYXRhOiBfaWQsXG4gICAgICBzY2hlbWE6IHZhbGlkYWNpb25lcy5zdHJpbmdcbiAgICB9KVxuXG4gICAgcmV0dXJuIGxpbmtzLmZpbmRPbmUoX2lkKVxuICB9XG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IGNsaXBzLCBwb3N0cyB9IGZyb20gJy9jb21tb24vYmFzZURlRGF0b3MnXG5pbXBvcnQgeyBzYWxpclZhbGlkYWNpb24gfSBmcm9tICcvc2VydmVyL2NvbXVuJ1xuaW1wb3J0IEpvaSBmcm9tICdqb2knXG5cbmNvbnN0IHZhbGlkYWNpb25lcyA9IHtcbiAgcHJpbWVyUG9zdDogSm9pLnN0cmluZygpLFxuICBsaW5rOiBKb2kuc3RyaW5nKClcbn1cblxuTWV0ZW9yLnB1Ymxpc2goJ3JhbmtpbmcnLCBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBjbGlwcy5maW5kKHtcbiAgICBwb3N0czoge1xuICAgICAgJGd0OiAwXG4gICAgfVxuICB9LCB7XG4gICAgZmllbGRzOiB7XG4gICAgICBzZWNyZXRvOiAwLFxuICAgICAgc2VndXJpZGFkOiAwXG4gICAgfSxcbiAgICBzb3J0OiB7XG4gICAgICBhY3R1YWxpemFjaW9uOiAtMVxuICAgIH0sXG4gICAgbGltaXQ6IDEwMFxuICB9KVxufSlcblxuTWV0ZW9yLnB1Ymxpc2goJ2J1c3F1ZWRhJywgZnVuY3Rpb24gKGJ1c3F1ZWRhKSB7XG4gIHZhciByZWdleCA9IC8oPzopL1xuICB0cnkge1xuICAgIHJlZ2V4ID0gbmV3IFJlZ0V4cChidXNxdWVkYSlcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJlZ2V4ID0gLyReL1xuICB9XG4gIHJldHVybiBjbGlwcy5maW5kKHtcbiAgICB0aXR1bG86IHJlZ2V4LFxuICAgIHBvc3RzOiB7XG4gICAgICAkZ3Q6IDBcbiAgICB9XG4gIH0sIHtcbiAgICBmaWVsZHM6IHtcbiAgICAgIHNlY3JldG86IDAsXG4gICAgICBzZWd1cmlkYWQ6IDBcbiAgICB9LFxuICAgIHNvcnQ6IHtcbiAgICAgIGFjdHVhbGl6YWNpb246IC0xXG4gICAgfSxcbiAgICBsaW1pdDogMTAwXG4gIH0pXG59KVxuXG5NZXRlb3IucHVibGlzaCgncHJpbWVyUG9zdCcsIGZ1bmN0aW9uIChjbGlwSWQpIHtcbiAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICBkYXRhOiBjbGlwSWQsXG4gICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMucHJpbWVyUG9zdCxcbiAgICBkZWJ1Zzoge1xuICAgICAgZG9uZGU6ICdwdWJsaXNoIGNsaXAnXG4gICAgfVxuICB9KVxuXG4gIHJldHVybiBwb3N0cy5maW5kKHtcbiAgICBjbGlwSWQsXG4gICAgc3RhdHVzOiAnVklTSUJMRSdcbiAgfSwge1xuICAgIHNvcnQ6IHtcbiAgICAgIHByaW9yaWRhZDogLTEsXG4gICAgICB0aW1lc3RhbXA6IC0xXG4gICAgfSxcbiAgICBsaW1pdDogMVxuICB9KVxufSlcblxuTWV0ZW9yLnB1Ymxpc2goJ2xpbmsnLCBmdW5jdGlvbiAobGluaykge1xuICByZXR1cm4gcG9zdHMuZmluZE9uZSh7XG4gICAgbGlua1xuICB9LCB7XG4gICAgZmllbGRzOiB7XG4gICAgICBjbGlwSWQ6IDFcbiAgICB9XG4gIH0pXG59KVxuTWV0ZW9yLnB1Ymxpc2goJ2xpbmtQb3N0JywgZnVuY3Rpb24gKGxpbmspIHtcbiAgcmV0dXJuIHBvc3RzLmZpbmQoe1xuICAgIGxpbmtcbiAgfSwge1xuICAgIGxpbWl0OiAxXG4gIH0pXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IGNsaXBzLCBwb3N0cyB9IGZyb20gJy9jb21tb24vYmFzZURlRGF0b3MnXG5pbXBvcnQgeyBzYWxpclZhbGlkYWNpb24sIHNhbGlyIH0gZnJvbSAnL3NlcnZlci9jb211bidcblxuaW1wb3J0IEpvaSBmcm9tICdqb2knXG5cbmNvbnN0IHZhbGlkYWNpb25lcyA9IHtcbiAgYWdyZWdhclBvc3Q6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICBjbGlwSWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIGxpbmtJZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKClcbiAgfSksXG4gIGNhbWJpYXJQcmlvcmlkYWQ6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICBwb3N0SWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlY3JldG86IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHByaW9yaWRhZDogSm9pLm51bWJlcigpLnJlcXVpcmVkKClcbiAgfSksXG4gIGVzdGFibGVjZXJTdGF0dXM6IEpvaS5vYmplY3QoKS5rZXlzKHtcbiAgICBwb3N0SWQ6IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHNlY3JldG86IEpvaS5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICAgIHN0YXR1czogSm9pLnN0cmluZygpLnZhbGlkKFsnUkVDSEFaQURPJywgJ09DVUxUTycsICdWSVNJQkxFJ10pLnJlcXVpcmVkKClcbiAgfSksXG4gIGVsaW1pbmFyUG9zdDogSm9pLm9iamVjdCgpLmtleXMoe1xuICAgIHBvc3RJZDogSm9pLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgc2VjcmV0bzogSm9pLnN0cmluZygpLnJlcXVpcmVkKClcbiAgfSksXG4gIHBvc3RzVmlzaWJsZXM6IEpvaS5zdHJpbmcoKSxcbiAgcG9zdHNOb1Zpc2libGVzOiBKb2kub2JqZWN0KCkua2V5cyh7XG4gICAgY2xpcElkOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBzZWNyZXRvOiBKb2kuc3RyaW5nKCkucmVxdWlyZWQoKVxuICB9KVxufVxuXG5jb25zdCB0ZXN0U2VjcmV0b0NsaXAgPSBmdW5jdGlvbiAob3BjaW9uZXMpIHtcbiAgY29uc3QgcG9zdCA9IHBvc3RzLmZpbmRPbmUoe1xuICAgIF9pZDogb3BjaW9uZXMucG9zdElkXG4gIH0sIHtcbiAgICBmaWVsZHM6IHtcbiAgICAgIGNsaXBJZDogMVxuICAgIH1cbiAgfSkgfHwgc2FsaXIoNDA0LCAnUG9zdCBubyBlbmNvbnRyYWRvJylcblxuICBjb25zdCBjbGlwID0gY2xpcHMuZmluZE9uZSh7XG4gICAgX2lkOiBwb3N0LmNsaXBJZFxuICB9LCB7XG4gICAgZmllbGRzOiB7XG4gICAgICBzZWNyZXRvOiAxLFxuICAgICAgc3RhdHVzOiAxXG4gICAgfVxuICB9KSB8fCBzYWxpcig0MDQsICdDbGlwIG5vIGVuY29udHJhZG8nLCB7XG4gICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgfSlcblxuICBjbGlwLnNlZ3VyaWRhZCA9PT0gb3BjaW9uZXMuc2VndXJpZGFkIHx8IHNhbGlyKDQwMSwgJ05vIHRpZW5lcyBwZXJtaXNvIHBhcmEgYWRtaW5pc3RyYXIgZWwgY2xpcCcsIHtcbiAgICBkb25kZTogJ21ldGhvZCBlc3RhYmxlY2VyU3RhdHVzJ1xuICB9KVxuXG4gIHJldHVybiBjbGlwXG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgYWdyZWdhclBvc3QgKG9wY2lvbmVzKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMuYWdyZWdhclBvc3RcbiAgICB9KVxuICAgIGNsaXBzLmZpbmQoe1xuICAgICAgX2lkOiBvcGNpb25lcy5jbGlwSWRcbiAgICB9KS5jb3VudCgpIHx8IHNhbGlyKDQwNCwgJ0NsaXAgbm8gZW5jb250cmFkbycpXG5cbiAgICBpZiAocG9zdHMuZmluZE9uZShvcGNpb25lcykpIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHBvc3RzLmluc2VydCh7XG4gICAgICBjbGlwSWQ6IG9wY2lvbmVzLmNsaXBJZCxcbiAgICAgIGxpbmtJZDogb3BjaW9uZXMubGlua0lkLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLFxuICAgICAgc3RhdHVzOiAnUEVORElFTlRFJyxcbiAgICAgIHByaW9yaWRhZDogMFxuICAgIH0pXG4gIH0sXG4gIGNhbWJpYXJQcmlvcmlkYWQgKG9wY2lvbmVzKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMuY2FtYmlhclByaW9yaWRhZFxuICAgIH0pXG4gICAgdGVzdFNlY3JldG9DbGlwKG9wY2lvbmVzKVxuXG4gICAgcG9zdHMudXBkYXRlKG9wY2lvbmVzLnBvc3RJZCwge1xuICAgICAgJHNldDoge1xuICAgICAgICBwcmlvcmlkYWQ6IG9wY2lvbmVzLnByaW9yaWRhZFxuICAgICAgfVxuICAgIH0pXG4gIH0sXG4gIGVzdGFibGVjZXJTdGF0dXMgKG9wY2lvbmVzKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMuZXN0YWJsZWNlclN0YXR1c1xuICAgIH0pXG4gICAgY29uc3QgY2xpcCA9IHRlc3RTZWNyZXRvQ2xpcChvcGNpb25lcylcblxuICAgIHBvc3RzLnVwZGF0ZShvcGNpb25lcy5wb3N0SWQsIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgc3RhdHVzOiBvcGNpb25lcy5zdGF0dXNcbiAgICAgIH1cbiAgICB9KVxuICAgIGNvbnNvbGUubG9nKGNsaXApXG4gICAgaWYgKGNsaXAuc3RhdHVzICE9PSAnVklTSUJMRScgJiYgb3BjaW9uZXMuc3RhdHVzID09PSAnVklTSUJMRScpIHtcbiAgICAgIGNvbnNvbGUubG9nKCsxKVxuICAgICAgcmV0dXJuIGNsaXBzLnVwZGF0ZShjbGlwLl9pZCwge1xuICAgICAgICAkaW5jOiB7XG4gICAgICAgICAgcG9zdHM6IDFcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gICAgaWYgKGNsaXAuc3RhdHVzID09PSAnVklTSUJMRScgJiYgb3BjaW9uZXMuc3RhdHVzICE9PSAnVklTSUJMRScpIHtcbiAgICAgIGNvbnNvbGUubG9nKC0xKVxuICAgICAgcmV0dXJuIGNsaXBzLnVwZGF0ZShjbGlwLl9pZCwge1xuICAgICAgICAkaW5jOiB7XG4gICAgICAgICAgcG9zdHM6IC0xXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuICB9LFxuICBlbGltaW5hclBvc3QgKG9wY2lvbmVzKSB7XG4gICAgc2FsaXJWYWxpZGFjaW9uKHtcbiAgICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgICAgc2NoZW1hOiB2YWxpZGFjaW9uZXMuZWxpbWluYXJQb3N0LFxuICAgICAgZGVidWc6IHtcbiAgICAgICAgZG9uZGU6ICdtZXRob2QgZXN0YWJsZWNlclN0YXR1cydcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgdGVzdFNlY3JldG9DbGlwKG9wY2lvbmVzKVxuXG4gICAgcG9zdHMucmVtb3ZlKG9wY2lvbmVzLnBvc3RJZClcbiAgfVxufSlcblxuTWV0ZW9yLnB1Ymxpc2goJ3Bvc3RzVmlzaWJsZXMnLCBmdW5jdGlvbiAoY2xpcElkKSB7XG4gIHNhbGlyVmFsaWRhY2lvbih7XG4gICAgZGF0YTogY2xpcElkLFxuICAgIHNjaGVtYTogdmFsaWRhY2lvbmVzLnBvc3RzVmlzaWJsZXNcbiAgfSlcblxuICByZXR1cm4gcG9zdHMuZmluZCh7XG4gICAgY2xpcElkLFxuICAgIHN0YXR1czogJ1ZJU0lCTEUnXG4gIH0pXG59KVxuTWV0ZW9yLnB1Ymxpc2goJ3Bvc3RzTm9WaXNpYmxlcycsIGZ1bmN0aW9uIChvcGNpb25lcykge1xuICBzYWxpclZhbGlkYWNpb24oe1xuICAgIGRhdGE6IG9wY2lvbmVzLFxuICAgIHNjaGVtYTogdmFsaWRhY2lvbmVzLnBvc3RzTm9WaXNpYmxlc1xuICB9KVxuICBjb25zdCBjbGlwID0gY2xpcHMuZmluZE9uZSh7XG4gICAgdXJsOiBvcGNpb25lcy51cmxcbiAgfSkgfHwgc2FsaXIoNDA0LCAnQ2xpcCBubyBlbmNvbnRyYWRvJylcblxuICBjbGlwLnNlY3JldG8gPT09IG9wY2lvbmVzLnNlY3JldG8gfHwgc2FsaXIoNDAxLCAnQ2xhdmUgZGUgYWRtaW5pc3RyYWNpw7NuIG5vIHbDoWxpZGEnKVxuXG4gIHJldHVybiBwb3N0cy5maW5kKHtcbiAgICBjbGlwSWQ6IG9wY2lvbmVzLmNsaXBJZCxcbiAgICBzdGF0dXM6IHtcbiAgICAgICRuZTogJ1ZJU0lCTEUnXG4gICAgfVxuICB9KVxufSlcbiJdfQ==
